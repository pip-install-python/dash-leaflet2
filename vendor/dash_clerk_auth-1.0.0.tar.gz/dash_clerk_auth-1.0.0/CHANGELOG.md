# Changelog

All notable changes to dash-clerk-auth will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-08-03

First stable release. The 0.9.x surface — the signed identity cookie,
satellite mode, Dash 4.2 WebSocket auth, billing gates — is the stable
public API from here on; breaking changes now mean a major version.

### Changed

- `requires-python` is now `>=3.10` (was `>=3.9`). The 3.9 claim was never
  installable: `clerk-backend-api>=5.0.0,<6` publishes no Python 3.9 build,
  so pip could not resolve the dependency set on 3.9. Python 3.9 has been
  EOL since October 2025.
- README: retired links to the legacy documentation domain; project links
  now point at the GitHub organization.
- Test fixtures use generic `example.clerk.accounts.dev` / `user_TEST…`
  values throughout.
- `_identity_cookie.py` module docstring: the sign-out helper is
  `clear_cookie_header` (the docstring said `clear_header`).
- Changelog copy-edit: security fixes state the fix and the version to
  upgrade to, without reproducing the pre-fix failure mechanics.
- Repository: a documentation-site shell now lives alongside the package
  (`run.py`, `lib/`, `pages/`, `components/`, `templates/`). It never ships
  in the package artifact — `MANIFEST.in` remains the allowlist.

## [0.9.2] - 2026-08-03

### Fixed — satellite Sign In no longer calls the forbidden modal

On a satellite domain the header Sign In button called
`Clerk.openSignIn()`, which ClerkJS rejects with *"This operation is not
allowed on a satellite domain. Try again using the primary domain of your
instance."* — a signed-out visitor on a satellite simply could not
authenticate. The button now branches: on satellites it navigates to the
configured `satellite_sign_in_redirect` (see below), falling back to
`Clerk.redirectToSignIn()` — the Clerk-native hop to the primary's
`sign_in_url` — when none is set. Primary/single-domain apps keep the
modal exactly as before.

### Added

- `register_clerk_auth(satellite_sign_in_redirect=...)` (env fallback
  `CLERK_SATELLITE_SIGN_IN_REDIRECT`): an absolute URL on the PRIMARY
  application that satellite Sign In buttons navigate to, carrying the
  current page in `?returnTo=<url>` so the primary can send the user
  straight back after sign-in.
- `window.dashClerkAuth` page-JS surface (`isSatellite`, `signInUrl`,
  `signUpUrl`, `satelliteSignInRedirect`, `buildSatelliteRedirect(opts)`)
  so host apps with their own sign-in/sign-up buttons can reuse the same
  satellite-safe navigation (`buildSatelliteRedirect({mode: 'signup'})`
  appends `&mode=signup` for the primary to open its sign-up flow).

## [0.9.1] - 2026-07-31

### Fixed — satellite mode: the domain now rides on the ClerkJS script tag

On a satellite domain, ClerkJS v5 threw
`ClerkJS: Missing domain and proxyUrl. A satellite application needs to
specify a domain or a proxyUrl.` even though `Clerk.load()` received
`isSatellite: true` and a non-empty `domain`. With the script-tag
installation, ClerkJS **auto-instantiates from the tag's data attributes**,
and its satellite check reads the *instance* domain — the one handed to
`load()` is ignored. The result was a half-broken auth state that is easy to
misread: the user button never mounted (avatar rendered but dead, fallback
image shown) while server-side session verification kept working, so the
site simultaneously greeted the user by name and refused to open the menu.

The generated script tag now carries `data-clerk-domain="<satellite_domain>"`
whenever `is_satellite=True`. `Clerk.load()` keeps receiving the same
options as before — the tag attribute is what ClerkJS actually consumes.

Observed and verified on a production satellite deployment, 2026-07-31.

## [0.9.0] - 2026-06-11

Upstream fixes from a downstream production debugging report (Dash 4.2.0,
flask dev + fastapi/uvicorn prod). Every issue below was reproduced against
a real app before landing here.

### Fixed — verified identities now carry an email (HIGH)

Clerk session JWTs carry **no email claim** by default — just
`{azp, exp, iat, iss, sid, sts, sub, v}`. `ClerkUser.from_jwt_payload`
therefore produced `email=None` for every verified user, that email-less
user was jti-cached and minted into `__dca_identity` for the cookie's whole
lifetime, and email-keyed gates (`user.email == OWNER_EMAIL`) denied users
Clerk had verified successfully.

Both verify paths (`averify_request`, `verify_user_sync`) now enrich an
email-less verdict via the users API **before** caching or minting —
`aget_user_by_id` on the async path, `get_user_by_id_sync` on the sync path,
both backed by a process-sticky per-`user_id` store, so the lookup costs one
backend-API call per user per process (not per request). The flask
`/api/auth/session` route (which has its own verification path) enriches
explicitly. New public helpers: `enrich_user_sync(user)` / `aenrich_user(user)`.
Alternative that skips the lookup entirely: customise the instance's session
token with `{{user.primary_email_address}}` — the package works either way.

### Fixed — flask backend establishes server-side identity again (HIGH)

A v0.5→v0.7 regression by omission: the flask path's only identity *writers*
lived in `POST /api/auth/session`, and the injected client script stopped
calling that route in v0.6 — so on `backend="flask"` a fully signed-in
browser stayed anonymous to every server-side check, forever.

The flask `before_request` hook now mirrors the ASGI middleware: when
`__dca_identity` is absent/invalid but a `__session` cookie (or bearer token)
is present, it runs `verify_user_sync` (TTL-cached, thread-safe) and mints
`__dca_identity` on the response via `after_this_request`. Static-asset and
renderer-housekeeping paths are skipped (same list as the ASGI middleware).
`/api/auth/session` keeps working for clients that still POST tokens.

### Changed — Dash 4.2 WebSocket auth registers automatically (MEDIUM)

`configure_app` on an ASGI backend now calls `register_websocket_auth()`
itself. Without the hooks, identity did not reach WS-served callbacks on
Dash 4.2 — a security-relevant gap on earlier releases; upgrade to ≥ 0.9.
Registration is idempotent and degrades gracefully on Dash
versions without the hooks; opt out with
`register_clerk_auth(websocket_auth=False)`. When the app runs with
`websocket_callbacks=True` and WS auth is NOT registered, a WARNING names
the symptom. `on_anonymous="allow"` remains the default. New accessor:
`ws_auth_registered()` for health endpoints.

### Changed — identity resolution is observable (LOW)

DEBUG logs on every resolve path: flask fast-path/session/slow-path/anonymous
outcomes per request, WS connect resolution with its source
(`state`/`cookie`/`jwt`/`idle`/`anonymous`), and the first bind of each
renderer in the WS message hook (not every refresh).

### Changed — idle requests no longer log like failures (LOW)

Clerk session JWTs rotate every ~60s; between rotations requests legitimately
arrive with `__client_uat`/`__refresh_*` but no `__session`. That state
previously triggered a guaranteed-reject Clerk verify plus two INFO lines per
request ("verify rejected: SESSION_TOKEN_MISSING", "slow-path FAILED") — noise
that reads like an outage. All three resolve paths (ASGI, WS, flask) now skip
the roundtrip and log `no session token (rotated/idle)` at DEBUG; the
`SESSION_TOKEN_MISSING` reject family logs at DEBUG everywhere else too.
Genuine rejects (expired, KID mismatch, etc.) still log at INFO, and the
misleading "FAILED (cookie present but rejected)" wording is now
"rejected (session token present)".

### Docs

- `SESSION_SECRET` must be fixed across replicas and deploys (a per-deploy
  secret invalidates every `__dca_identity` each release).
- Prefer per-callback `@callback(websocket=True)` over the global
  `websocket_callbacks=True` flag — ordinary callbacks ride HTTP where
  cookies and middleware exist.
- Callable page layouts must accept `**kwargs`: Dash Pages forwards query
  params as kwargs and Clerk handshake redirects carry `?__clerk_handshake=`.
- Documented the known Dash 4.2.0 upstream bug (`dictionary changed size
  during iteration` in `dash/backends/_fastapi.py` disconnect cleanup).

## [0.8.1] - 2026-06-02

### Fixed — Clerk modals now track the DMC theme on toggle (dark + light)

0.8.0 fixed light mode but the dark UserProfile/SignIn modals could render
dark-on-dark (washed-out, low-contrast text; a stray light header bar; SignIn
input placeholder not legible). Root cause: Clerk's `appearance` colours were
baked **once** at `Clerk.load()` from the theme active at that moment, and the
theme-toggle observer only swapped background CSS vars — not Clerk's text
colours — so after a light→dark toggle the text stayed dark.

The fix follows Clerk's "bring your own CSS" guidance and DMC's CSS-variable
system: every theme-dependent colour in the Clerk `appearance` (`variables` and
`elements`) now resolves from Mantine's **own scheme-aware** custom properties —
`--mantine-color-body`, `--mantine-color-text`, `--mantine-color-default`,
`--mantine-color-default-border`, `--mantine-color-dimmed`,
`--mantine-color-placeholder`, `--mantine-primary-color-*` — with light-mode
literals as fallbacks. Because Mantine flips those variables on the
`data-mantine-color-scheme` attribute, the modals re-theme **instantly** on a
DMC light/dark toggle (no Clerk re-render) and match the rest of the app,
including Clerk's hashed `cl-internal-*` elements. Added a dark-mode CSS
override block (mirroring the v0.8.0 light block) and a scheme-neutral
`::placeholder` rule, in both the injected `<style>` and `assets/style.css`.

## [0.8.0] - 2026-06-02

Hardening pass for the **Dash 4.2.0 (final)** release with `backend="fastapi"`
and `websocket_callbacks=True`. v0.7 made `current_user()` resolve across HTTP
and WS; v0.8 makes the WS path safe to lean on **at scale** and adds the
loop-free Clerk API that WS callback bodies actually need.

### Compatibility note — the WS registry and Dash 4.2.x

`current_user()` inside a WS-served callback resolves via the renderer
registry, which reads `callback_context.websocket._renderer_id`. That
accessor landed as the **`websocket` property in 4.2.0rc3** and is **identical
in 4.2.0 final** (verified by diffing the rc3 and final wheels:
`_callback_context.py` and `_hooks.py` are byte-for-byte the same, and
`run_callback_in_executor` — the thread-pool + per-callback `asyncio.run()`
model — is unchanged). On the **rc1/rc2** pin the accessor was a
`get_websocket()` *method*, so the registry was silently inert and
`current_user()` returned `None` in every WS callback. v0.8 now resolves
**both** spellings, so the registry works on any 4.2.x — but the recommended
fix is simply to run 4.2.0 final.

### Added — loop-free synchronous Clerk API (safe in WS callback bodies)

Dash 4.2 runs each async WS callback via `asyncio.run()` in a rotating
thread-pool worker, creating and tearing down a fresh event loop per call. A
process-cached `httpx.AsyncClient` binds its pool to the first loop that
touches it, so **awaiting the async client from a callback body raises
`RuntimeError: Event loop is closed`** (reproduced on httpx 0.28.1 /
httpcore 1.0.9). The fix is a sync API whose `httpx.Client` is never
loop-bound:

- **`verify_user_sync(...)`** — synchronous twin of `averify_request`.
- **`get_user_by_id_sync(...)`** / **`list_users_sync(...)`** — sync twins of
  `aget_user_by_id` / `alist_users_cached`.
- **`set_user_role_sync(user_id, role)`** — merge-patches `public_metadata.role`
  (the exact "admin saves a role" WS-callback case that breaks under the async
  client) and invalidates the sync caches.
- **`get_sync_client()`** — the shared loop-free `Clerk` instance, for any
  other sync SDK call from a worker/job thread.

These use a thread-safe TTL cache (`threading.Lock`), separate from the
asyncio-locked async caches. Reach for them from WS callback bodies, `jobs.py`
daemon threads and APScheduler jobs; keep using the `a*` async helpers on the
main event loop (ASGI middleware, WS connect/message hooks).

### Fixed — registry concurrency (the scale bug)

`_ws_registry` is written from the main uvicorn loop (`attach` in the
`websocket_message` hook) **and** read + TTL-touched from callback worker
threads (`lookup` via `current_user()`). The eviction sweep iterated the dict
while another thread mutated it, which raises
`RuntimeError: dictionary changed size during iteration` under concurrent WS
load. All registry mutations and the eviction sweep are now guarded by a
`threading.Lock` (iteration over a snapshot). The lock is held only for O(1)
dict ops, so contention is negligible at any realistic WS scale.

### Fixed — async client self-heals on a closed loop

`averify_request` / `aget_user_by_id` / `alist_users_cached` now detect the
cross-loop `RuntimeError` family — `"event loop is closed"`, `"attached to a
different loop"` **and** `"is bound to a different event loop"` (the phrasing
asyncio `Lock`/`Event`/`Semaphore` raise, including the anyio primitives
httpcore wraps inside httpx's pool) — rebuild the cached client and retry
**once**. This is a safety net for the cross-loop hazard above; the *correct*
answer for callback bodies is still the sync API.

The async TTL cache's single-flight machinery (`asyncio.Lock` + `Future`) binds
to one event loop, so calling the `a*` user helpers from a second loop (a WS
worker) used to crash. `_TTLCache.get_or_load` now **degrades gracefully**: on a
cross-loop error it drops the shared single-flight and runs the loader directly
on the current loop (a rare duplicate Clerk call) instead of raising.
`aget_user_by_id` / `alist_users_cached` are documented main-event-loop-only,
steering worker-thread callers to the sync twins. The single-flight future is
also created with `asyncio.get_running_loop()` instead of the deprecated
`get_event_loop()`.

### Fixed — light-mode rendering of the Clerk modals

The SignIn and UserProfile modals washed out in light mode: the liquid-glass
tiers use translucent shells with a `z-index:-1 ::before` backing plus Clerk's
own semi-transparent `colorBackground`, so the page bled through (dark mode was
fine). Added a light-scoped override block (`html[data-mantine-color-scheme="light"]`)
that forces solid, high-contrast surfaces and explicit text colours on Clerk's
**stable** semantic classes (`cl-card`, `cl-modalContent`, `cl-navbar`,
`cl-profileSection`, …; never the hashed `cl-internal-*`). Dark mode is
untouched. Mirrored in both the injected `<style>` (what ships to consumers)
and `assets/style.css` (the example apps). Theme switching follows DMC's
`data-mantine-color-scheme` attribute.

### Changed — WS connect hook no longer seeds the ContextVar

The `websocket_connect` hook used to call `set_request_user(user)` without ever
resetting it. The callback worker can't see that ContextVar anyway (that's what
the registry is for), and the ASGI middleware already binds + resets it for the
WS scope — so the call was dead weight that leaked an unreset value onto the
connection's handler task. Removed. Identity on connect is still recorded on
`websocket.state.clerk_user` for the message hook. Reconnection (#3797) and the
message hook are documented inline: bindings self-heal on reconnect and are not
detached on disconnect (a `renderer_id` is a per-tab UUID, so auto-restarted
persistent callbacks keep resolving `current_user()`).

### Compatibility

- `dash >= 3.0.3`, validated through **4.2.0 final**. No API removals; the
  v0.5/v0.6/v0.7 surface is unchanged.

## [0.7.0] - 2026-05-14

### Fixed — Dash 4.2 WebSocket reliability (the downstream outage report)

An outage report filed against v0.6 by a production deployment names a
specific symptom: under Dash 4.2 with `websocket_callbacks=True`, page
layouts and `@admin_required` decorators see `current_user() is None`
on first paint, then settle to the right state after a 50–300 ms
client-side hydration race. The user-visible behaviour is "I'm signed
in but the page locks me out — I refresh a few times and eventually it
lets me in." This release closes the gap end-to-end.

### Added

- **`__dca_identity` signed cookie** — verified-positive cache for the
  Clerk verdict. Minted on every successful Clerk verify, signed against
  `session_secret` with `itsdangerous.URLSafeTimedSerializer`, with a
  deployer-controlled TTL (defaults to `session_lifetime_days * 86400`,
  default 7d). Subsequent HTTP and WebSocket requests verify it locally
  (microsecond HMAC, no Clerk roundtrip). Lives in
  `dash_clerk_auth/_identity_cookie.py`. Cookie attributes: `Path=/`,
  `HttpOnly`, `SameSite=Lax`, `Secure` when `X-Forwarded-Proto: https`.
- **WebSocket-aware ASGI middleware.** `ClerkASGIMiddleware` now handles
  `scope["type"] == "websocket"` in addition to `"http"`. WS handshakes
  resolve identity through the same fast path as HTTP requests and stash
  the verdict on `scope["state"]["clerk_user"]` so the WS hooks can read
  it without re-verifying.
- **Per-renderer WebSocket identity registry.** Dash 4.2 dispatches WS
  callbacks through a `ThreadPoolExecutor`; Python's
  `concurrent.futures` does not propagate `ContextVar` state from the
  asyncio task to the worker thread. The new `_ws_registry` module bridges
  this gap with a bounded TTL map from `renderer_id` (the Dash-issued WS
  connection UUID) to the verified user, populated in the
  `websocket_message` hook before each callback dispatch and read from
  `current_user()` via `ctx.websocket._renderer_id`.
- **`current_user()` precedence chain.** Now reads (in order): ContextVar
  → WS renderer registry → Flask `g.clerk_user` → Flask `session` →
  `None`. Same call site works on every supported backend and transport.
- **`@hooks.layout()` pre-hydrates `clerk-auth-store`.** The store starts
  populated from `current_user()` at layout build time. Layout decorators
  see the right verdict synchronously even inside a WS-served
  `_pages_content.children` callback, so they no longer need the dual-div
  fallback. Eliminates the first-paint flash documented in the outage report.
- **Multi-Clerk-app cookie hygiene.** Per-app suffixed Clerk cookies
  (`__session_<suffix>`, `__client_uat_<suffix>`, `__refresh_<suffix>`,
  `__clerk_db_jwt_<suffix>`) are now stripped from the `Cookie:` header
  before being passed to Clerk's SDK. Clerk's frontend SDK uses the suffix
  scheme so multiple Clerk apps can coexist on the same hostname (essential
  for `localhost`/`127.0.0.1` development), but Clerk's backend SDK reads
  the FIRST matching `__session*` cookie in declaration order — which can
  be from a different app, returning `JWK_KID_MISMATCH` even when the
  canonical `__session` is valid. Stripping suffixed variants forces the
  SDK to use the canonical no-suffix cookie which always belongs to the
  active app. Lives in
  `dash_clerk_auth/_clerk_client.py::_filter_other_app_clerk_cookies`.
- **Diagnostic logging on Clerk verify rejections.**
  `averify_request` now logs the Clerk reject reason at INFO when
  verification fails (previously returned `None` silently). On
  `JWK_KID_MISMATCH`, the log line decodes the JWT header from the cookie
  and prints the offending `kid` so the multi-app vs. wrong-secret-key
  cause is diagnosable in one log line.

### Changed

- **`register_websocket_auth(on_anonymous="allow"|"close")`** — defaults
  to `"allow"`, the mixed-traffic-safe behaviour that the outage report
  asks for as "Option A". Anonymous visitors keep their WS open;
  authentication is enforced at the layout-decorator and callback level
  rather than at the WS transport. Pass `on_anonymous="close"` to revert
  to v0.6's fail-closed behaviour (close anonymous handshakes with code
  4401). The wrapper auto-passes `session_secret` from `register_clerk_auth()`
  so the connect hook can verify the local cookie before the slow path.
- **`_ws.py` rewritten against the actual Dash 4.2.0rc3 hook surface.**
  Uses `dash.hooks.websocket_connect` and `dash.hooks.websocket_message`
  (the names actually shipped); the v0.6 implementation looked up
  guessed names like `on_websocket_connect` and silently no-op'd. Stays
  importable on Dash 3 / 4.0 / 4.1 — the registration call returns
  `False` with an info log when the hooks are absent.
- **`ClerkASGIMiddleware.__init__`** gains `session_secret` and
  `identity_cookie_max_age` kwargs so the middleware can mint cookies on
  successful HTTP verifies. `configure_app(app)` passes both through
  automatically; existing callers don't need to change anything.
- **Cookie TTL no longer bounded by JWT `exp`.** First internal v0.7 draft
  used `bounded_max_age(jwt_exp, cap)` which returned ~0 near the JWT's
  expiry edge (Clerk dev JWTs rotate every ~60s), silently skipping the
  mint and leaving users perpetually on the slow path. The cookie now uses
  `session_lifetime_days * 86400` directly, with itsdangerous's signed
  timestamp providing the freshness guarantee independent of any one JWT.
  The cookie's purpose is to cache *identity* across many JWT refreshes;
  decoupling its lifetime from the JWT's lifetime is correct.
- **`_clerk_client._build_httpx_request` no longer passes `cookies=` to
  `httpx.Request`.** When httpx receives both an explicit `cookies={...}`
  dict AND a pre-existing `Cookie:` header in `headers`, it overwrites the
  header from the dict — losing any cookies the dict didn't enumerate.
  The fix: pass the original `Cookie:` header through unmodified (after
  filtering per the multi-app hygiene above), so cookies Clerk's
  handshake state machine reads (like `__client_uat`) survive.

### Tests

- 94 passing tests (was 57 in v0.6).
- New: `tests/test_identity_cookie.py` — cookie sign/verify round-trip,
  tamper rejection, expiry, max-age bounds.
- New: `tests/test_identity_cookie_middleware.py` — middleware fast-path
  cookie verify, slow-path mint on response, WS scope handling,
  X-Forwarded-Proto secure-flag escalation.
- New: `tests/test_ws_registry.py` — attach/lookup/detach, size cap
  eviction, anonymous attach, callback-context-renderer-id helper.
- New: `tests/test_cookie_filter.py` — multi-Clerk-app cookie collision
  filter (the §Changed item above).

### Documentation

- Full architectural write-up at
  `.claude/planning/0.7-architecture-and-bug-postmortem.md` covering the
  three-layer architecture, the cookie design choices, the `current_user()`
  precedence chain, and the multi-app cookie collision postmortem.
- README.md, SKILLS.md, and QUICKSTART.md updated for v0.7.

### Migration

Drop-in for v0.6 deployments. No code changes required. After upgrading,
the cookie path bootstraps itself the next time Clerk JS calls
`/api/auth/session`.

To enable WebSocket auth on Dash 4.2.0rc1+ apps:

```python
from dash_clerk_auth import register_clerk_auth, configure_app, register_websocket_auth

register_clerk_auth(...)
configure_app(app)
register_websocket_auth()  # on_anonymous="allow" by default
```

The `dual-div` admin gate pattern in downstream apps keeps working as
defense in depth — but
`current_user()` is now reliable enough that the inconclusive branch
should rarely fire.

## [0.6.0] - 2026-04-30

### Added — FastAPI / async port (the main story)

- **First-class Dash 4 `backend="fastapi"` support.** v0.5 imported on
  FastAPI but every server-side helper (`get_current_user_id`, `has_plan`,
  `try_admin_from_request`) returned `None` because they read
  `flask.session` / `flask.request` — and the ASGI stack has neither.
  v0.6 replaces that with a backend-neutral identity layer:
  - **`ClerkASGIMiddleware`** verifies a Clerk session once per HTTP
    request via the async Clerk SDK (`authenticate_request_async`) and
    binds a `ClerkUser` to a `contextvars.ContextVar` for the lifetime
    of the request. Static asset paths (`/_dash-component-suites/...`,
    `/assets/...`, `/health`) skip verification. Verified-positive
    verdicts cache by JWT `jti` for up to 5 min (or until JWT `exp`,
    whichever sooner).
  - **`current_user()` / `callback_user()` / `is_authenticated()`** —
    backend-neutral helpers that read from the ContextVar on FastAPI
    and from `flask.g` (then `flask.session`) on Flask. Same return
    shape on both backends; downstream code never branches.
  - **`@require_auth_layout` / `@require_role_layout` /
    `@require_plan_layout` / `@require_feature_layout`** — server-side
    gating decorators that commit to ONE branch before any callback or
    layout body runs. Default policy is **fail-closed** — anonymous
    visitors get the placeholder, never the protected layout. Closes a
    v0.5 layout-gating security weakness — upgrade to ≥ 0.6.
    `on_inconclusive="passthrough"` keeps the old behaviour available
    for explicit opt-in.
  - **`ClerkUser` dataclass** — the single shape every backend produces,
    populated eagerly at request boundary from the JWT payload. Resolves
    `role` from `public_metadata.role` → `org_role` (strips `org:` prefix)
    → top-level `role`, lowercased.
- **Async Clerk SDK wrapper** with shared connection pool and TTL caches:
  - `get_async_client()` — process-wide singleton `Clerk(...)` reusing
    the SDK's internal `httpx.AsyncClient` pool.
  - `averify_request(...)` — async verify with timeout, JTI cache, and
    a fail-closed default.
  - `aget_user_by_id(user_id, *, ttl_seconds=60)` and
    `alist_users_cached(*, force=False, ttl_seconds=60)` — single-flight
    TTL caches so 50 concurrent admin reads collapse to 1 Clerk call.
    `force=True` bypasses the cache for explicit refresh-button paths.
- **`backend="auto"` parameter on `register_clerk_auth()`** —
  autodetects Flask vs FastAPI/Starlette/Quart from `app.server` and
  installs the right middleware. Explicit `backend="flask"` or
  `backend="fastapi"` overrides.
- **`on_unverified="forbidden"|"allow"|"passthrough"` knob** — drives
  the layout decorators when Clerk can't verify the request. Default
  `"forbidden"`.
- **`session_secret=` keyword** — canonical replacement for
  `flask_secret_key=` (works for both backends; FastAPI uses Starlette
  `SessionMiddleware`'s signed cookie). `flask_secret_key=` keeps
  working as a deprecated alias through v0.x with a `DeprecationWarning`.
- **Opt-in Dash 4.2 WebSocket auth** — `register_websocket_auth()`
  wires `on_websocket_connect` / `before_websocket_callback` so a WS
  connection is verified once at handshake and the verdict is reused
  across every callback fired on that socket. Defensive against the
  hook names still moving between Dash 4.2 rc1 → final; logs a
  one-shot info line and no-ops on Dash < 4.2.
- **`tests/`** — 57-test suite covering the dataclass projection,
  backend dispatch (Flask + ASGI), middleware behaviour, decorator
  policies, async cache + single-flight, and v0.5 backwards-compat.
- **`examples/app_fastapi.py`** — runnable FastAPI demo with one
  `@require_role_layout("admin")` page and an `async def` callback
  awaiting `alist_users_cached()` — the exact shape the downstream
  upgrade doc names as the production-correct pattern.

### Changed

- `__version__` bumped to `0.6.0`.
- `clerk-backend-api>=5.0.0,<6` is now the floor (we use
  `authenticate_request_async`, only present in 5.x). Drops the 4.x
  legacy import-path tower from `_clerk_client.py`.
- `configure_app(app)` is now a thin **dispatcher** — detects Flask vs
  ASGI from `app.server` and calls `_configure_flask_app` or
  `_configure_fastapi_app`. The Flask code path is the *exact* v0.5
  body, plus a new `before_request` hook that populates
  `flask.g.clerk_user` so `current_user()` has a fast read path on
  Flask too.
- All v0.5 helpers (`get_current_user_id`, `get_current_user_plan`,
  `has_plan`, `has_feature`, `require_auth`, `get_user_info`) now read
  via `current_user()` first and fall back to the legacy
  `flask.session` dict — they work identically on FastAPI without any
  caller changes.
- `pyproject.toml`: added `[project.optional-dependencies]`
  `fastapi` (`starlette`, `itsdangerous`, `fastapi`, `uvicorn`) and
  `quart`. Install with `pip install 'dash-clerk-auth[fastapi]'`.

### Compatibility

- v0.5 imports keep working unchanged. Flask deployments don't need to
  install `starlette` — all ASGI imports are lazy.
- Verified on Dash 4.1.0 (Flask) and confirmed against the Dash
  4.2.0rc1 WebSocket-callbacks PR (#3742) for the opt-in WS path.
- Verified on `clerk-backend-api` 5.0.6.
- `dash==4.2.0rc1` smoke-test passes (`/health`, `/api/capabilities`,
  `/_dash-layout`, `/` all 200 on `backend="fastapi"`).

### Migration from v0.5

```python
# v0.5 — Flask only
from dash_clerk_auth import register_clerk_auth, configure_app
register_clerk_auth(
    clerk_secret_key=...,
    clerk_publishable_key=...,
    clerk_sign_in_url=...,
    flask_secret_key=os.environ["FLASK_SECRET_KEY"],
)
configure_app(app)
```

```python
# v0.6 — works on Flask AND FastAPI without code changes downstream
from dash_clerk_auth import register_clerk_auth, configure_app
register_clerk_auth(
    clerk_secret_key=...,
    clerk_publishable_key=...,
    clerk_sign_in_url=...,
    session_secret=os.environ["SESSION_SECRET"],   # was flask_secret_key=
    backend="auto",                                # NEW (default)
    on_unverified="forbidden",                     # NEW (default)
)
configure_app(app)

# Replace ad-hoc gate_admin() helpers with the package-shipped decorator:
from dash_clerk_auth import require_role_layout

@require_role_layout("admin")
def layout():
    return _heavy_admin_content()    # not built for non-admins
```

## [0.5.0] - 2026-04-22

### Fixed
- **Clerk profile modal legibility in light mode** — the modal's glass
  backdrop was at 50% opacity, letting page content bleed through and
  washing out the Clerk-rendered text. Split the glass-backdrop variables
  into two tiers: `--clerk-glass-bg*` (unchanged, 50–70% for the header
  dropdown and debug panel) and a new `--clerk-modal-bg*` tier
  (90–96% opaque) used by the profile modal and its nested sections.
  Also: added `position: relative` to `.cl-modalContent` / `.cl-cardBox`
  so the `::before` backing layer anchors correctly, and added a soft
  `.cl-modalBackdrop` scrim so the modal has visible context over the
  page in both schemes.
- **`clerk-backend-api` SDK compatibility** — import path for
  `AuthenticateRequestOptions` now walks the SDK version chain:
  top-level (5.x) → `security.authenticaterequest` (4.x) →
  `security.types` (4.x) → legacy `jwks_helpers` (≤ 3.x). Previously a hard
  import of `clerk_backend_api.jwks_helpers` broke the package on SDK ≥ 4.0
  (reported by a downstream team).
- Minimum pinned `clerk-backend-api` raised from `>=1.0.0` to
  `>=4.0.0,<6`. `httpx>=0.28.0` is now declared explicitly.

### Added
- **`create_clerk_menu()` public helper** — embed the liquid-glass avatar
  and dropdown anywhere in your layout (typically inside a
  `dmc.AppShellHeader`) instead of the fixed top-right corner. Use with
  `register_clerk_auth(headless=True)`. Optional args:
  - `show_dropdown=False` — render just the bare avatar div, for wrapping
    in your own `dmc.Menu` / `dmc.Popover`.
  - `dropdown_align="left"` — flip the dropdown anchor when the avatar
    lives on the left side of a header. Emits a warning (preventing a
    duplicate-id Dash error) if called while the hook is also injecting
    its fixed-position avatar.
- **First-class Clerk satellite-domain support** — new kwargs on
  `register_clerk_auth()`:
  - `is_satellite` / `satellite_domain` — drive `Clerk.load({isSatellite, domain, signInUrl, signUpUrl})`.
  - `sign_up_url` — satellite's link to the primary's sign-up page.
  - `clerk_frontend_api` — explicit Clerk-hosted Frontend API origin,
    decoupled from `clerk_sign_in_url` (which in satellite mode points at
    *your* primary app, not Clerk). The hook prefers this when set.
  - `allowed_redirect_origins` — on the primary, the whitelist of satellite
    origins Clerk is allowed to redirect back to.
  - `sign_in_url` — Clerk-JS-friendly alias for `clerk_sign_in_url`.
  - `headless` — suppress the fixed-position avatar/dropdown UI so the
    host app can render its own user controls (the stores / trigger
    components are still injected).
- **Soft Flask detection** — Flask, Flask-Session and Werkzeug are now
  imported with a try/except so `import dash_clerk_auth` no longer crashes
  on non-Flask Dash 4 backends. `configure_app()` raises a clear
  `RuntimeError` when called against a FastAPI/Quart `app.server`, pointing
  at the planned ASGI port. The decorators (`require_auth`, `require_plan`,
  `require_feature`) and helpers (`get_current_user_id`, `get_user_info`,
  `has_plan`, `has_feature`) degrade gracefully outside a Flask request
  context instead of crashing with a `RuntimeError: Working outside of
  request context`.
- **Structured demo app** — `example_app.py` replaced by a multi-page
  Dash demo (`app.py` + `pages/`) modeled on
  [`dash-mui-charts`](https://github.com/pip-install-python/dash-mui-charts).
  Each page is a limited-working-example focused on a single aspect of the
  hook (home, quickstart, register props, auth store, `@require_auth`,
  `@require_plan`, `@require_feature`, utility functions, debug panel,
  billing, changelog).

### Changed
- `__version__` bumped to `0.5.0` (dropped the `-liquid-glass` tag from the
  version string — glass styling is now the baseline, not a flag).
- `pyproject.toml`: author/URLs filled in, `requires-python = ">=3.9"`
  (Python 3.8 is EOL), `dash-mantine-components>=2.3.0` floor (known-good
  on 2.3, 2.4 and 2.6).
- `requirements.txt` regenerated — no more editable git install pin.

### Compatibility
- Verified on Dash 3.0.3 and Dash 4.1.0.
- Verified on dmc 2.3.0, 2.4.0 and 2.6.1.
- Verified on `clerk-backend-api` 4.2.0 and 5.0.6.
- Dash 4 `backend="fastapi"` is **not yet supported** — `configure_app()`
  raises a descriptive error. Use the default WSGI Flask backend for now.

## [0.2.0] - 2025-06-04

### Added
- **Billing & Subscription Support**
  - New `enable_billing` parameter in `register_clerk_auth()` to activate billing features
  - Automatic extraction of plan and features from Clerk JWT tokens
  - `@require_plan()` decorator for protecting callbacks by subscription plan
  - `@require_feature()` decorator for feature-based access control
  - Support for multiple plans in decorators (e.g., `@require_plan(["pro", "enterprise"])`)
  - New utility functions:
    - `get_current_user_plan()` - Get the user's current subscription plan
    - `get_current_user_features()` - Get list of features available to the user
    - `has_plan(plan_name)` - Check if user has a specific plan
    - `has_feature(feature_name)` - Check if user has a specific feature
  - `create_upgrade_prompt()` function for customizable upgrade UI components
  - Built-in support for Clerk's `PricingTable` component
  - Plan badge display in user dropdown menu (when billing enabled)

### Enhanced
- Debug panel now displays user's plan information when billing is enabled
- Auth store now includes `plan` and `features` fields when billing is enabled
- Improved JWT token parsing for billing data extraction
- Enhanced documentation with comprehensive billing guide and examples

### Security
- Secure handling of billing data from JWT tokens
- Plan and feature validation in decorators with proper error handling

## [0.1.0] - 2025-06-02

### Added
- Initial release for Plotly Dash Plugin Challenge
- Complete Clerk authentication integration using Dash Hooks
- Pre-built UI components (login/logout menu with avatar)
- Automatic client-server state synchronization
- `@require_auth` decorator for protecting callbacks
- `get_current_user_id()` and `get_user_info()` utility functions
- Optional debug panel for development
- Support for Flask sessions with configurable lifetime
- ProxyFix middleware support for reverse proxy deployments
- Comprehensive error handling and logging
- Full support for user switching without stale data
- Clientside callbacks for responsive UI updates
- Auto-discovery via dash_hooks entry point

### Security
- Secure session management with signed cookies
- HTTPS support in production mode
- CSRF protection via Flask-Session
- Proper logout flow clearing all auth states

### Documentation
- Comprehensive README with examples
- API reference documentation
- Troubleshooting guide
- Competition submission documentation

## Roadmap (unscheduled)

### Planned
- Role-based access control (RBAC) support
- Team/organization management features
- Custom UI theme support
- Additional authentication providers
- Webhook support for auth events
- Rate limiting for auth endpoints
- Session activity tracking
- Remember me functionality
- Subscription webhook handlers
- Usage-based billing support

---

[1.0.0]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v1.0.0
[0.9.2]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.9.2
[0.9.1]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.9.1
[0.9.0]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.9.0
[0.8.1]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.8.1
[0.8.0]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.8.0
[0.7.0]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.7.0
[0.6.0]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.6.0
[0.5.0]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.5.0
[0.2.0]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.2.0
[0.1.0]: https://github.com/pip-install-python/dash-clerk-auth/releases/tag/v0.1.0