"""ClerkUser dataclass — the single shape every backend produces.

Pure-python, no I/O, no framework imports. Both the Flask ``before_request``
hook and the FastAPI ASGI middleware project a verified Clerk JWT payload
through :meth:`ClerkUser.from_jwt_payload` so downstream code (decorators,
``current_user()``, callback bodies) never branches on backend.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping, Tuple


def _coerce_role(payload: Mapping[str, Any]) -> str | None:
    """Resolve a role string from a Clerk JWT payload, lowercased.

    Clerk doesn't have a single canonical claim for "role" — apps put it in
    ``public_metadata.role``, sometimes ``org_role``, sometimes a top-level
    ``role`` claim. We check in that order and return the first match.
    """
    public_meta = payload.get("public_metadata") or payload.get("pmd") or {}
    if isinstance(public_meta, Mapping):
        role = public_meta.get("role")
        if isinstance(role, str) and role:
            return role.lower()

    role = payload.get("org_role") or payload.get("role")
    if isinstance(role, str) and role:
        # Clerk org roles are namespaced like "org:admin" — strip the prefix
        # so callers can compare against a bare "admin".
        return role.split(":", 1)[-1].lower()

    return None


def _coerce_features(payload: Mapping[str, Any]) -> Tuple[str, ...]:
    raw = payload.get("features") or payload.get("fea") or ()
    if isinstance(raw, str):
        # Clerk billing sometimes serialises features as a comma-string.
        return tuple(f.strip() for f in raw.split(",") if f.strip())
    if isinstance(raw, (list, tuple)):
        return tuple(str(f) for f in raw if f)
    return ()


@dataclass
class ClerkUser:
    """A verified Clerk session, projected to a stable shape.

    Populated once at request boundary (Flask ``before_request`` /
    FastAPI middleware) so callbacks and layouts can read it without
    a Clerk SDK roundtrip.
    """

    user_id: str
    email: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    image_url: str | None = None
    role: str | None = None
    plan: str | None = None
    features: Tuple[str, ...] = ()
    session_id: str | None = None
    raw: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))

    @classmethod
    def from_jwt_payload(
        cls,
        payload: Mapping[str, Any],
        *,
        billing_enabled: bool = False,
    ) -> "ClerkUser":
        if not payload or not payload.get("sub"):
            raise ValueError("Clerk JWT payload missing 'sub' (user id)")

        plan = None
        features: Tuple[str, ...] = ()
        if billing_enabled:
            plan = payload.get("plan") or "free"
            features = _coerce_features(payload)

        return cls(
            user_id=str(payload["sub"]),
            email=payload.get("email") or None,
            first_name=payload.get("first_name") or None,
            last_name=payload.get("last_name") or None,
            image_url=payload.get("image_url") or None,
            role=_coerce_role(payload),
            plan=plan,
            features=features,
            session_id=payload.get("sid") or None,
            raw=MappingProxyType(dict(payload)),
        )

    def to_session_dict(self) -> dict:
        """Serialise to the v0.5-compatible Flask session dict shape."""
        d = {
            "user_id": self.user_id,
            "email": self.email or "",
            "first_name": self.first_name or "",
            "last_name": self.last_name or "",
            "image_url": self.image_url or "",
            "session_id": self.session_id or "",
        }
        if self.plan is not None:
            d["plan"] = self.plan
        if self.features:
            d["features"] = list(self.features)
        if self.role is not None:
            d["role"] = self.role
        return d

    @classmethod
    def from_session_dict(cls, sess: Mapping[str, Any]) -> "ClerkUser | None":
        """Reconstruct from a v0.5-style Flask session dict.

        Returns None if the session has no ``user_id`` (anonymous).
        """
        user_id = sess.get("user_id")
        if not user_id:
            return None
        return cls(
            user_id=str(user_id),
            email=sess.get("email") or None,
            first_name=sess.get("first_name") or None,
            last_name=sess.get("last_name") or None,
            image_url=sess.get("image_url") or None,
            role=(sess.get("role") or "").lower() or None,
            plan=sess.get("plan"),
            features=tuple(sess.get("features") or ()),
            session_id=sess.get("session_id") or None,
            raw=MappingProxyType(dict(sess)),
        )

    def has_role(self, role: str) -> bool:
        return self.role is not None and self.role == role.lower()

    def has_plan(self, plans) -> bool:
        if isinstance(plans, str):
            plans = [plans]
        if not self.plan:
            return False
        wanted = {p.lower() for p in plans}
        return self.plan.lower() in wanted

    def has_feature(self, feature: str) -> bool:
        return feature in self.features
