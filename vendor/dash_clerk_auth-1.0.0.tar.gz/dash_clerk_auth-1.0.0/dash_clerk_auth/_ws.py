"""Dash 4.2+ WebSocket auth glue.

Dash 4.2 (PR #3742, finalised in 4.2.0rc3) ships two WebSocket lifecycle
hooks on ``dash.hooks``:

- ``websocket_connect(websocket)`` — runs **before** ``websocket.accept()``.
  If the hook returns a truthy ``(close_code, close_reason)`` tuple, Dash
  closes the connection without accepting it.
- ``websocket_message(websocket, message)`` — runs on every inbound JSON
  message, including ``callback_request`` messages (which dispatch a
  callback to a thread pool). Same close-on-truthy semantics.

This module wires three behaviours when those hooks are available:

1. On connect: read ``__dca_identity`` (fast path) or ``__session`` (slow
   path) and stash the verified user on ``websocket.state.clerk_user``.
   Anonymous connections are kept open by default so mixed-traffic apps
   aren't locked out — pass ``on_anonymous="close"`` to revert to the
   v0.6 fail-closed behaviour.
2. On every message that carries a ``rendererId``: bind the verified
   user to the renderer in :mod:`._ws_registry`. The registry is the
   workaround for Dash 4.2's threadpool-based callback dispatch losing
   the asyncio task's :class:`ContextVar` state.
3. ``current_user()`` (in :mod:`._backend`) reads the registry via the
   active callback's ``ctx.websocket._renderer_id`` whenever the
   ContextVar is empty — see :func:`._ws_registry.lookup`.

If the running Dash version doesn't expose the hooks (e.g. Dash 3.x or
4.0/4.1), :func:`register_websocket_auth` logs an info line and returns
``False`` without raising. The package stays importable on every
supported Dash version.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Literal, Optional

from dash import hooks

from ._clerk_client import averify_request
from ._identity_cookie import COOKIE_NAME as _IDENTITY_COOKIE, verify as _verify_identity
from ._user import ClerkUser
from ._ws_registry import attach as _attach_user, contains as _registry_contains

logger = logging.getLogger(__name__)


_WS_AUTH_REGISTERED = False


def ws_auth_registered() -> bool:
    """``True`` once the Dash 4.2 WebSocket auth hooks are attached.

    Exposed so apps and health endpoints can assert WS auth is actually
    active — the registration info-log usually fires before most apps
    configure logging, so it's easy to miss.
    """
    return _WS_AUTH_REGISTERED


def register_websocket_auth(
    *,
    session_secret: Optional[str] = None,
    identity_cookie_max_age: int = 7 * 24 * 3600,
    authorized_parties: Optional[list] = None,
    billing_enabled: bool = False,
    on_anonymous: Literal["allow", "close"] = "allow",
    close_code: int = 4401,
    close_reason: str = "unauthenticated",
) -> bool:
    """Wire Clerk verification into Dash 4.2+ WebSocket lifecycle hooks.

    Returns ``True`` when the hooks were attached; ``False`` (with an
    info log) when the running Dash version doesn't expose them.

    :param session_secret: Same secret that signs the ``__dca_identity``
        cookie in :class:`._asgi.ClerkASGIMiddleware`. When set, the
        connect hook tries the cookie before the slow Clerk roundtrip.
    :param on_anonymous: ``"allow"`` (default, mixed-traffic safe) keeps
        anonymous connections open; ``"close"`` closes them with
        ``close_code`` / ``close_reason`` (the v0.6 fail-closed default).
    :param close_code: WebSocket close code used when ``on_anonymous="close"``.
    :param close_reason: WebSocket close reason used when ``on_anonymous="close"``.

    Idempotent — safe to call multiple times.
    """
    global _WS_AUTH_REGISTERED
    if _WS_AUTH_REGISTERED:
        return True

    connect_decorator = _resolve_hook("websocket_connect", "on_websocket_connect")
    message_decorator = _resolve_hook("websocket_message", "on_websocket_message")

    if connect_decorator is None:
        logger.info(
            "dash-clerk-auth: WebSocket auth not registered — Dash %s has no "
            "websocket_connect hook. Upgrade to Dash >= 4.2.0rc1 to opt in.",
            _dash_version(),
        )
        return False

    @connect_decorator()
    async def _verify_socket(websocket) -> Optional[tuple]:  # signature per Dash 4.2
        user, source = await _resolve_user_for_socket(
            websocket,
            session_secret=session_secret,
            identity_cookie_max_age=identity_cookie_max_age,
            authorized_parties=authorized_parties,
            billing_enabled=billing_enabled,
        )
        logger.debug(
            "dash-clerk-auth WS connect: %s (source=%s)",
            f"user={user.user_id}" if user else "anonymous", source,
        )

        # Stash on websocket.state so the message hook (and any custom
        # downstream code) can read without re-verifying. This is the ONLY
        # place identity is recorded on connect: we deliberately do NOT touch
        # the ContextVar here. The ASGI middleware already binds it for the
        # whole WS scope (and resets it), and the actual callback runs in a
        # thread-pool worker that can't see this task's ContextVar anyway —
        # that's what the renderer_id registry (populated by the message hook)
        # is for. Setting it here would only leak an unreset value onto the
        # connection's handler task.
        state = getattr(websocket, "state", None)
        if state is not None:
            try:
                state.clerk_user = user
            except Exception:  # pragma: no cover — Starlette's state is a dict-like
                pass

        if user is None and on_anonymous == "close":
            return (close_code, close_reason)
        return None

    if message_decorator is not None:

        @message_decorator()
        async def _attach_per_message(websocket, message) -> None:
            # Re-bind ``renderer_id -> user`` on every message that carries a
            # ``rendererId`` (``callback_request`` and ``get_props_response``;
            # ``heartbeat`` has none and is skipped). Idempotent and cheap, and
            # it refreshes the registry TTL so a long-lived socket never
            # expires mid-session.
            #
            # On a Dash 4.2-final reconnect (#3797) a fresh ``websocket_connect``
            # re-resolves identity onto the new ``websocket.state``, and this
            # hook re-stamps the registry on the next frame — so the binding
            # self-heals. We intentionally do NOT detach on disconnect: a
            # renderer_id is a per-tab UUID (no cross-user reuse), and keeping
            # it lets auto-restarted persistent callbacks keep resolving
            # ``current_user()`` across the reconnect gap.
            try:
                renderer_id = (message or {}).get("rendererId")
            except AttributeError:
                renderer_id = None
            if not renderer_id:
                return
            user = _user_from_socket(websocket)
            first_bind = not _registry_contains(renderer_id)
            _attach_user(renderer_id, user)
            if first_bind:
                logger.debug(
                    "dash-clerk-auth WS: renderer %s bound to %s",
                    renderer_id,
                    f"user={user.user_id}" if user else "anonymous",
                )
            return None

    _WS_AUTH_REGISTERED = True
    logger.info(
        "dash-clerk-auth: WebSocket auth registered (Dash %s, on_anonymous=%s)",
        _dash_version(),
        on_anonymous,
    )
    return True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
async def _resolve_user_for_socket(
    websocket,
    *,
    session_secret: Optional[str],
    identity_cookie_max_age: int,
    authorized_parties: Optional[list],
    billing_enabled: bool,
) -> tuple:
    """Return ``(user_or_none, source)`` for this WS.

    ``source`` names the resolve path for the connect-hook DEBUG log:
    ``"state"`` | ``"cookie"`` | ``"jwt"`` | ``"jwt-rejected"`` |
    ``"idle"`` (Clerk cookies present but no session token) |
    ``"anonymous"``.

    Identity precedence:

    1. ``websocket.state.clerk_user`` if the ASGI middleware already
       resolved it (preferred — avoids double work).
    2. ``__dca_identity`` cookie verified locally.
    3. Clerk JWT verify against the ``__session`` cookie or bearer token.
    """
    state = getattr(websocket, "state", None)
    if state is not None:
        existing = getattr(state, "clerk_user", None)
        if isinstance(existing, ClerkUser):
            return existing, "state"

    headers = _normalize_headers(getattr(websocket, "headers", {}) or {})
    cookies = dict(getattr(websocket, "cookies", {}) or {})

    # Fast path — local cookie.
    if session_secret:
        token = cookies.get(_IDENTITY_COOKIE)
        if token:
            cached = _verify_identity(token, session_secret, identity_cookie_max_age)
            if cached is not None:
                return cached, "cookie"

    # Slow path — Clerk JWT verify, but only when there's an actual session
    # token. ``__client_uat``/``__refresh_*`` alone is the expected idle
    # state between Clerk's ~60s JWT rotations — a verify is guaranteed to
    # reject, so skip the roundtrip (mirrors the ASGI middleware).
    bearer: Optional[str] = None
    auth = headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        bearer = auth.split(" ", 1)[1].strip()

    has_session_token = "__session" in cookies or any(
        k.startswith("__session_") for k in cookies
    )
    if not (bearer or has_session_token):
        if any(k.startswith("__client") or k.startswith("__refresh") for k in cookies):
            return None, "idle"
        return None, "anonymous"

    user = await averify_request(
        method="GET",
        url=str(getattr(websocket, "url", "ws://localhost/")),
        headers=headers,
        cookies=cookies,
        bearer_token=bearer,
        authorized_parties=authorized_parties,
        billing_enabled=billing_enabled,
    )
    return user, ("jwt" if user is not None else "jwt-rejected")


def _resolve_hook(*names: str):
    """Return the first attribute that exists on ``dash.hooks`` from ``names``."""
    for name in names:
        candidate = getattr(hooks, name, None)
        if callable(candidate):
            return candidate
    return None


def _normalize_headers(headers: Any) -> dict:
    out: dict = {}
    if isinstance(headers, dict):
        items = headers.items()
    else:
        items = getattr(headers, "items", lambda: [])()
    for k, v in items:
        if isinstance(k, bytes):
            k = k.decode("latin-1")
        if isinstance(v, bytes):
            v = v.decode("latin-1")
        out[str(k).lower()] = str(v)
    return out


def _user_from_socket(websocket) -> Optional[ClerkUser]:
    state = getattr(websocket, "state", None)
    if state is None:
        return None
    user = getattr(state, "clerk_user", None)
    return user if isinstance(user, ClerkUser) else None


def _dash_version() -> str:
    try:
        import dash
        return getattr(dash, "__version__", "unknown")
    except Exception:
        return "unknown"
