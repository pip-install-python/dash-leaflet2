# dash-clerk-auth · Skills reference

> Comprehensive reference for the `dash-clerk-auth` Plotly Dash plugin.
> Pair this file with the hook when you want an agent (Claude, a subagent,
> etc.) to have a complete mental model of the package without re-reading
> the source. Safe to drop into a project's `.claude/support_files/` or
> `.cursor/rules/` directory.

- **Package**: `dash-clerk-auth`
- **Version**: `1.0.4` (2026-08-21)
- **Python**: `>=3.10` (raised from `>=3.9` in v1.0.0 — clerk-backend-api publishes no 3.9 build on any supported major, 5.x–7.x)
- **Dash**: `>=3.0.3` — first-class support for Dash 4 `backend="fastapi"` and `backend="quart"` since v0.6 (see §9). v0.7 added Dash 4.2 WebSocket-callback reliability (WS-aware ASGI middleware + per-renderer identity registry). v0.8 hardened it for Dash `4.2.0` (final) at scale: a thread-safe WS registry, a self-healing async client, loop-free **sync Clerk helpers** safe inside WS callback bodies (§13d), and DMC-theme-matched Clerk modals (§13f). **v0.9 closes the production gaps found by a downstream debugging report**: email enrichment (Clerk session JWTs carry no email claim — §13g), a real server-side identity path on `backend="flask"`, WS auth auto-registration, and idle-state log quieting.
- **dash-mantine-components**: `>=2.3.0` (verified on 2.3, 2.4, 2.6, 2.7)
- **clerk-backend-api**: `>=5.0.0,<8` — v0.6 raised the floor to use `authenticate_request_async` (was `>=4.0.0,<6` in v0.5); v1.0.1 widened the cap to `<8` so applications can pin `cryptography>=50.0.0` (SDK 5.x capped cryptography below the advisory fixes).
- **starlette / itsdangerous**: optional for `backend="flask"` (Flask pulls itsdangerous in transitively); required for FastAPI/Quart. Install via `pip install 'dash-clerk-auth[fastapi]'`.
- **License**: MIT
- **Repo**: <https://github.com/pip-install-python/dash-clerk-auth>

---

## 1. When to invoke this skill

Trigger on any of:

- User asks about Clerk authentication in a Dash app.
- User wants drop-in sign-in / sign-up UI for a Python web app built on Dash.
- User wants to gate Dash callbacks on an authenticated session.
- User wants to gate **layouts** server-side on auth/role/plan/feature
  (the v0.6 `@require_role_layout` family — fail-closed by default, so
  heavy admin layouts never build for anonymous visitors).
- User is on Dash 4 with `backend="fastapi"` (or `backend="quart"`)
  and needs Clerk auth.
- User has an `async def` Dash callback and needs to call Clerk without
  blocking the event loop (`await alist_users_cached()` etc).
- User wants to gate callbacks on a Clerk Billing plan or feature flag.
- User is running a multi-domain / multi-subdomain Dash setup and needs
  shared sign-on across sibling apps.
- User sees `ModuleNotFoundError: No module named 'clerk_backend_api.jwks_helpers'`
  — this is the 0.1.0 / 0.2.0 upgrade-path bug, fixed in 0.5.0.
- User reports a worker hang / slow response on FastAPI when an admin
  layout renders for anonymous visitors — this is the v0.6 motivating
  bug (heavy server-side layout built for everyone). The fix is
  `@require_role_layout` + the ASGI middleware shipped in v0.6.
- User is on Dash 4.2.0rc1+ with `websocket_callbacks=True` and reports
  "page locks me out, refresh fixes it" — this is the v0.7 motivating
  bug. The fix is the WS-aware ASGI middleware + the per-renderer identity
  registry shipped in v0.7. Also tell them about `register_websocket_auth(on_anonymous="allow")`.
- User reports `JWK_KID_MISMATCH` on every request even with valid
  `__session` cookie — they have signed into multiple Clerk dev apps on
  the same hostname (`localhost`/`127.0.0.1`). v0.7 strips other-app
  `__session_<suffix>` cookies before passing to Clerk's SDK. Upgrade.
- User asks "where is the `__dca_identity` cookie coming from?" — that's
  the v0.7 verified-positive cache; explain the cookie design (§13 below).
- User is debugging the Clerk profile modal / dropdown / avatar appearance
  (liquid-glass styles, dark-mode / light-mode toggle). Since v0.8.1 the modals
  are themed from Mantine's scheme-aware CSS variables so they track the DMC
  light/dark toggle — see §13f.
- User reports `RuntimeError: Event loop is closed` (or "attached/bound to a
  different loop") when calling Clerk from inside a Dash 4.2 WebSocket callback
  — point them at the loop-free `*_sync` helpers in §13d.
- User reports `user.email is None` (or an email-keyed gate denying a
  signed-in user) even though Clerk verified the session — Clerk session
  JWTs carry **no email claim** by default. Fixed in v0.9 by enrichment
  (§13g); on `< 0.9` the workaround is a manual `users.get` per user_id.
- User on `backend="flask"` reports the browser is signed in (avatar
  renders, `clerk-auth-store` populated) but `current_user()` /
  `g.clerk_user` is always `None` server-side — v0.5→v0.7 regression,
  fixed in v0.9 (flask `before_request` slow path, §5).
- User reports log spam: `Clerk verify rejected:
  reason=...SESSION_TOKEN_MISSING` / "slow-path Clerk verify FAILED" on
  idle tabs — expected idle state between Clerk's ~60s JWT rotations;
  v0.9 skips the roundtrip and logs it at DEBUG.
- User asks whether WS auth is actually active — point them at
  `ws_auth_registered()` (v0.9); registration is automatic on ASGI
  backends since v0.9.

Do NOT invoke for:

- FastAPI / Starlette apps that don't use Dash.
- Clerk React SDK usage in a React-proper app (use `@clerk/clerk-react`
  directly instead).
- Apps that only need an unauthenticated sign-up waitlist — Clerk's
  drop-in `<waitlist>` web component is lighter weight than this hook.

---

## 2. What the hook does

One call to `register_clerk_auth(...)` wires Clerk authentication into a
Dash app via the `@dash.hooks.index()` + `@dash.hooks.layout()` extension
points. The hook:

1. **Injects `clerk.browser.js`** (SDK v5) into the page `<head>`, using
   your publishable key.
2. **Injects a liquid-glass avatar + dropdown** in the top-right corner
   (or via `create_clerk_menu()` wherever you want — see §6 headless
   mode).
3. **Injects a hidden `dcc.Store(id="clerk-auth-store")`** that gets
   populated from `window.Clerk.user` on every session change
   (sign-in / sign-out / user switch).
4. **Wires `configure_app(app)`** as a *backend-detecting dispatcher*:
   - **Flask path** — sets up Flask-Session with a signed cookie,
     optional `ProxyFix`, a `before_request` hook that populates
     `flask.g.clerk_user` (since v0.9 it also runs a slow-path Clerk
     verify when only a `__session` cookie is present and mints
     `__dca_identity` on the response — flask no longer depends on the
     client POSTing a token), and the two REST endpoints below.
   - **FastAPI / Starlette / Quart path** (Dash 4 ASGI) — installs
     `ClerkASGIMiddleware` and Starlette `SessionMiddleware`, then
     mounts the same two endpoints as plain ASGI routes:
   - `POST /api/auth/session` — server-side Clerk JWT verification,
     mirrors the result into the session.
   - `POST /api/auth/signout` — clears the session.
5. **Binds a `ClerkUser` to the request** via either `flask.g`
   (Flask) or a `contextvars.ContextVar` (FastAPI). Backend-neutral
   helpers (`current_user()`, `is_authenticated()`, `callback_user()`)
   read whichever is populated.
6. **Exposes layout decorators** — `@require_auth_layout`,
   `@require_role_layout(role)`, `@require_plan_layout(plans)`,
   `@require_feature_layout(name)` — that fail-closed by default and
   commit to one branch *before* any callback or layout body runs.
7. **Exposes callback decorators** (v0.5, still available) —
   `@require_auth`, `@require_plan(...)`, `@require_feature(...)` — for
   Flask routes and Dash callbacks. Now backend-neutral.
8. **Exposes sync + async helpers**:
   - sync: `get_current_user_id()`, `get_user_info()`, `has_plan()`,
     `has_feature()` — for code that reads the session outside a
     callback context.
   - async: `await averify_request(...)`, `await aget_user_by_id(...)`,
     `await alist_users_cached(force=False, ttl_seconds=60)` — for use
     inside `async def` callbacks on Dash 4 + FastAPI.
9. **Pre-hydrates `clerk-auth-store` (v0.7)** — `@hooks.layout()` reads
   `current_user()` at build time and seeds the Store's `data` prop. Layout
   decorators see the right verdict synchronously even inside Dash 4.2's
   WS-served `_pages_content.children` callback, eliminating the
   first-paint anonymous flash.
10. **Mints the signed `__dca_identity` cookie (v0.7)** on every successful
    Clerk verify. Acts as a verified-positive cache so subsequent requests
    skip the JWKS roundtrip — single HMAC verify per request instead of
    a Clerk SDK call. Signed against the same `session_secret` that signs
    Flask/Starlette session cookies. See §13 for the full design.
11. **Registers Dash 4.2+ WebSocket auth — automatic since v0.9.**
    `configure_app` on an ASGI backend calls `register_websocket_auth()`
    itself (opt out with `register_clerk_auth(websocket_auth=False)`;
    assert with `ws_auth_registered()`). The hooks: `websocket_connect`
    reads the cookie / re-verifies on handshake; `websocket_message`
    populates a per-renderer registry that the thread-pool callback
    dispatch reads back through `current_user()`. `on_anonymous` defaults
    to `"allow"` (mixed-traffic safe); call `register_websocket_auth(
    on_anonymous="close")` yourself BEFORE `configure_app` for the v0.6
    fail-closed behaviour (first registration wins — it's idempotent).
    No-ops on Dash < 4.2.
12. **Enriches verified identities with the email (v0.9).** Clerk session
    JWTs carry no email claim by default, so a verified user would
    otherwise have `email=None` everywhere (and be cached/minted that way
    for the cookie lifetime). Both verify paths now fetch the user once
    via the users API (sticky per-`user_id`, once per process) before
    caching or minting. See §13g.

---

## 3. Minimum viable app

The same `register_clerk_auth(...)` call works on both backends —
`backend="auto"` (the default since v0.6) detects which one to wire.

### 3a. Flask backend (default — Dash 3 & 4)

```python
import os
from dotenv import load_dotenv
from dash import Dash
import dash_mantine_components as dmc
from dash_clerk_auth import register_clerk_auth, configure_app, create_clerk_menu

load_dotenv()

register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],          # sk_test_...
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"], # pk_test_...
    clerk_sign_in_url=os.environ["CLERK_SIGN_IN_URL"],         # https://<your-app>.clerk.accounts.dev/sign-in
    session_secret=os.environ["SESSION_SECRET"],               # v0.6 — replaces flask_secret_key=
    headless=True,      # skip the fixed-position avatar; we embed ours
    enable_billing=False,
    # backend="auto" (default) — autodetects Flask from app.server
    # on_unverified="forbidden" (default) — fail-closed for layout decorators
)

app = Dash(__name__, external_stylesheets=[dmc.styles.ALL])
configure_app(app)

app.layout = dmc.MantineProvider(
    dmc.AppShell(
        [
            dmc.AppShellHeader(
                dmc.Group(
                    [dmc.Title("My app", order=4), create_clerk_menu()],
                    justify="space-between", h="100%", px="md",
                )
            ),
            dmc.AppShellMain(dmc.Container("Hello, Clerk!", py="xl")),
        ],
        header={"height": 60},
    )
)

if __name__ == "__main__":
    app.run(debug=True, port=8050)
```

### 3b. FastAPI backend (Dash 4.x ASGI — added in v0.6, hardened in v0.7)

Install with the FastAPI extra: `pip install 'dash-clerk-auth[fastapi]'`.
For Dash 4.2 WebSocket callbacks: `pip install 'dash[fastapi]>=4.2.0rc1'`.

```python
# app_fastapi.py
import os
from dash import Dash
import dash_mantine_components as dmc
from dash_clerk_auth import register_clerk_auth, configure_app, create_clerk_menu

register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],
    clerk_sign_in_url=os.environ["CLERK_SIGN_IN_URL"],
    session_secret=os.environ["SESSION_SECRET"],   # v0.7 — also signs __dca_identity
    headless=True,
    backend="auto",                    # detects "fastapi" from app.server
    on_unverified="forbidden",         # fail-closed (default)
    verify_timeout=5.0,                # Clerk verify timeout, seconds
    # websocket_auth=True (default)    # v0.9 — WS auth hooks auto-register
)

app = Dash(
    __name__,
    backend="fastapi",                 # ← Dash 4 ASGI mode (≥ 4.2.0rc1)
    external_stylesheets=[dmc.styles.ALL],
    # Prefer per-callback @callback(websocket=True) over the global
    # websocket_callbacks=True flag: the renderer opens the socket whenever
    # the backend advertises the WS urls, so persistent/set_props callbacks
    # keep working while ordinary callbacks ride HTTP (where cookies and
    # middleware exist). Global flag still fully supported — WS auth covers it.
)
server = app.server                    # FastAPI instance — uvicorn target
configure_app(app)                     # v0.9 — also registers the WS auth hooks

# To customise WS auth (e.g. fail-closed), register BEFORE configure_app —
# it's idempotent and the first registration wins:
#   register_websocket_auth(on_anonymous="close")

app.layout = dmc.MantineProvider(
    dmc.AppShell([
        dmc.AppShellHeader(
            dmc.Group([dmc.Title("My app", order=4), create_clerk_menu()],
                      justify="space-between", h="100%", px="md")
        ),
        dmc.AppShellMain(dmc.Container("Hello, Clerk on ASGI!", py="xl")),
    ], header={"height": 60})
)

# Run with: uvicorn app_fastapi:server --host 0.0.0.0 --port 8050 --reload
```

Required env vars: `CLERK_SECRET_KEY`, `CLERK_PUBLISHABLE_KEY`,
`CLERK_SIGN_IN_URL`. Optional: `SESSION_SECRET` (canonical since v0.6;
falls back to `FLASK_SECRET_KEY` for backwards-compat),
`CLERK_FRONTEND_API`, `CLERK_SIGN_UP_URL`, `CLERK_WEBHOOK_SECRET`,
`DEBUG`.

---

## 4. `register_clerk_auth()` — full signature

| Kwarg | Type | Default | Effect |
|---|---|---|---|
| `clerk_secret_key` | `str` | `os.environ["CLERK_SECRET_KEY"]` | **Required.** Backend SDK credential, never exposed to the browser. |
| `clerk_publishable_key` | `str` | `os.environ["CLERK_PUBLISHABLE_KEY"]` | **Required.** Embedded in the injected `<script>` tag; safe to expose. |
| `clerk_sign_in_url` | `str` | `os.environ["CLERK_SIGN_IN_URL"]` | **Required.** Full URL to your Clerk sign-in page. Used both as a redirect target and, fallback-only, to derive the Clerk JS source origin. |
| `clerk_frontend_api` | `str \| None` | `os.environ.get("CLERK_FRONTEND_API", "")` | The Clerk-hosted Frontend API origin (`https://<your-app>.clerk.accounts.dev`). **Required in satellite mode**; recommended in all modes. |
| `session_secret` | `str \| None` | `os.environ.get("SESSION_SECRET")` then `FLASK_SECRET_KEY` | **(v0.6 canonical)** Signs the session cookie. Same secret drives Flask session and Starlette `SessionMiddleware`. |
| `flask_secret_key` | `str \| None` | `os.environ.get("FLASK_SECRET_KEY", "default-dev-secret-key")` | **Deprecated alias** for `session_secret` (still accepted; emits one `DeprecationWarning`). |
| `backend` | `Literal["auto","flask","fastapi","quart"]` | `"auto"` | **(v0.6)** Backend dispatcher. `"auto"` detects from `app.server` at `configure_app(app)` time. |
| `on_unverified` | `Literal["forbidden","allow","passthrough"]` | `"forbidden"` | **(v0.6)** Default policy for `require_*_layout` decorators when Clerk can't verify the request. `"forbidden"` fails closed. `"passthrough"` is the legacy v0.5 "render both" behaviour. |
| `verify_timeout` | `float` | `5.0` | **(v0.6)** Per-request Clerk verify timeout, seconds. |
| `authorized_parties` | `list[str] \| None` | `None` | **(v0.6)** Clerk `authorized_parties` whitelist passed to `authenticate_request`. |
| `websocket_auth` | `bool` | `True` | **(v0.9)** Auto-register the Dash 4.2+ WebSocket auth hooks when configuring an ASGI backend. Pass `False` to opt out (a WARNING fires if the app then runs `websocket_callbacks=True`). |
| `session_lifetime_days` | `int` | `7` | Session TTL (Flask cookie or Starlette `SessionMiddleware` `max_age`). Match your Clerk dashboard session setting. |
| `debug` | `bool` | `False` (falls back to `DEBUG` env) | Verbose logs + default-on debug panel. |
| `show_debug_panel` | `bool \| None` | mirrors `debug` | Force in-browser debug panel on or off. |
| `enable_proxy_fix` | `bool` | `True` | Wraps WSGI with `werkzeug.middleware.proxy_fix.ProxyFix`. Disable if not behind a reverse proxy. |
| `enable_billing` | `bool` | `False` | Turns on Clerk Billing: `plan` + `features` added to `clerk-auth-store`, `@require_plan` + `@require_feature` start gating. |
| `headless` | `bool` | `False` | When True, do NOT inject the fixed top-right avatar UI. Use with `create_clerk_menu()` to embed it in your own layout. |
| `is_satellite` | `bool` | `False` | Flip to True on every satellite domain in a galaxy. Calls `Clerk.load({isSatellite: true})`. |
| `satellite_domain` | `str \| None` | `None` | Host only (no protocol) for this satellite, e.g. `"store.example.com"`. Required when `is_satellite=True`. |
| `sign_up_url` | `str \| None` | `os.environ.get("CLERK_SIGN_UP_URL", "")` | Absolute URL to the primary's sign-up page. Passed to `Clerk.load()` as `signUpUrl`. |
| `allowed_redirect_origins` | `list[str] \| None` | `None` | On the primary, whitelist of satellite origins Clerk may redirect back to after sign-in. |
| `sign_in_url` | `str \| None` | `None` | Alias for `clerk_sign_in_url` (matches Clerk JS naming). If both are given, `sign_in_url` wins. |
| `app` | `Dash \| None` | `None` | Convenience: auto-call `configure_app(app)` after registration. |

**Call order matters.** `register_clerk_auth()` must run *before* `Dash(__name__, ...)` because the `@hooks.index()` / `@hooks.layout()` handlers fire during Dash app construction.

---

## 5. `configure_app(app)`

Call once, after `Dash(__name__, ...)`. Since v0.6 this is a
**backend-detecting dispatcher** — it reads the active backend from
`_clerk_config["backend"]` (set by `register_clerk_auth(backend=...)`)
or detects it from `app.server`, then calls `_configure_flask_app(app)`
or `_configure_fastapi_app(app)`.

### Flask path

- `SECRET_KEY`, `SESSION_TYPE='filesystem'`, `SESSION_PERMANENT=True`, `PERMANENT_SESSION_LIFETIME`, secure-cookie flags on `app.server.config`.
- `flask_session.Session(server)`.
- `ProxyFix` middleware (if `enable_proxy_fix=True`).
- **`@server.before_request`** populates `flask.g.clerk_user`. Resolution
  order (v0.9): **(1)** `__dca_identity` cookie (local HMAC verify, µs);
  **(2)** legacy Flask session dict; **(3) slow path — when a `__session`
  cookie or bearer token is present, `verify_user_sync` against Clerk
  (TTL-cached, thread-safe) and mint `__dca_identity` on THIS response via
  `after_this_request`.** Static prefixes (`/assets/`,
  `/_dash-component-suites/`, …) are skipped, but **`/_dash-layout` is
  deliberately NOT skipped** — the layout-hook store pre-hydration and
  dynamic root layouts read `g.clerk_user` while it's served. The slow path
  is what makes `backend="flask"` behaviorally identical to the ASGI
  middleware; before v0.9 the only identity writers were in
  `/api/auth/session`, which nothing calls anymore → signed-in browsers were
  anonymous server-side forever.
- `POST /api/auth/session` — reads `{token: "<JWT>"}` from the body, calls `clerk.authenticate_request(...)`, enriches the email (v0.9, §13g), populates the Flask session, mints `__dca_identity`, returns `{authenticated, user}`. Kept for clients that still POST tokens.
- `POST /api/auth/signout` — clears the Flask session + `__dca_identity`.
- Clientside callback that copies the `clerk-auth-trigger` hidden input into `clerk-auth-store.data`.

### FastAPI / Starlette / Quart path (v0.6, hardened in v0.7)

- **Starlette `SessionMiddleware`** with `secret_key=session_secret`,
  `max_age=session_lifetime_days*86400`, `same_site="lax"`,
  cookie name `dash_clerk_session`.
- **`ClerkASGIMiddleware`** — verifies Clerk session per request via
  `authenticate_request_async`, binds `ClerkUser` to a
  `contextvars.ContextVar` AND `scope["state"]["clerk_user"]`. Skips
  static asset paths (`/_dash-component-suites/...`, `/assets/...`,
  `/health`, `/_dash-layout`, `/_dash-dependencies`, `/_reload-hash`,
  `/_favicon.ico`). Verified-positive verdicts cache by JWT `jti` for
  up to 5 min (or until JWT `exp`, whichever sooner).
  - **(v0.7)** Now handles BOTH `scope["type"] == "http"` AND
    `"websocket"`. WS handshakes resolve identity through the same fast
    path as HTTP requests and stash the verdict on
    `scope["state"]["clerk_user"]` so the WS hooks can read it without
    re-verifying.
  - **(v0.7)** On HTTP responses, mints/refreshes the signed
    `__dca_identity` cookie after every successful Clerk verify. The
    cookie short-circuits the Clerk JWKS roundtrip on subsequent requests.
  - **(v0.7)** Strips per-app suffixed Clerk cookies (`__session_<suffix>`,
    `__client_uat_<suffix>`, `__refresh_<suffix>`, `__clerk_db_jwt_<suffix>`)
    from the Cookie header before handing it to Clerk's SDK. This prevents
    `JWK_KID_MISMATCH` rejections when the developer has signed into
    multiple Clerk dev apps on the same hostname.
- **`POST /api/auth/session`** and **`POST /api/auth/signout`** mounted
  as ASGI routes (FastAPI: typed `@app.post`; bare Starlette:
  `Route(...)`). Same response shape as the Flask side.
  - **(v0.7)** `/session` mints `__dca_identity`; `/signout` clears it.
- **(v0.9) `register_websocket_auth()` is called automatically** (unless
  `register_clerk_auth(websocket_auth=False)`). If the app runs with
  `websocket_callbacks=True` and WS auth is NOT registered, a WARNING
  names the symptom ("current_user() will be None in every
  WebSocket-served callback"). Assert registration from a health endpoint
  with `ws_auth_registered()`.
- The same clientside callback bridge.

**`RuntimeError` only when neither backend can be detected** (and the
caller didn't pass `backend="..."`). Set it explicitly to skip detection.

---

## 6. Public API at a glance

```python
from dash_clerk_auth import (
    # Setup
    register_clerk_auth,
    configure_app,

    # UI (optional, pair with headless=True)
    create_clerk_menu,

    # Session helpers (read current user — backend-neutral on v0.6)
    get_current_user_id,       # -> str | None
    get_user_info,             # -> dict | None
    get_current_user_plan,     # -> str | None  (needs enable_billing=True)
    get_current_user_features, # -> list[str]   (needs enable_billing=True)
    has_plan,                  # (plans) -> bool
    has_feature,               # (name) -> bool

    # Callback decorators (sync; v0.5)
    require_auth,              # Flask routes + Dash callbacks
    require_plan,              # (plans) — needs enable_billing=True
    require_feature,           # (name)  — needs enable_billing=True

    # ── v0.6 — backend-neutral identity ──
    ClerkUser,                 # dataclass: user_id, email, role, plan, features, ...
    current_user,              # -> ClerkUser | None  (works on Flask & FastAPI)
    callback_user,             # alias of current_user — clearer intent at callback sites
    is_authenticated,          # -> bool
    detect_backend,            # (server) -> "flask" | "fastapi" | "quart" | "unknown"

    # ── v0.6 — server-side layout gates ──
    require_auth_layout,       # (forbidden=None, on_inconclusive="forbidden")
    require_role_layout,       # (role,  forbidden=None, on_inconclusive="forbidden")
    require_plan_layout,       # (plans, forbidden=None, on_inconclusive="forbidden")
    require_feature_layout,    # (name,  forbidden=None, on_inconclusive="forbidden")
    default_forbidden_layout,  # build the default placeholder yourself

    # ── v0.6 — async Clerk surface (MAIN-LOOP ONLY: ASGI middleware, WS
    #          connect/message hooks. NOT from a WS callback body — see §13d) ──
    get_async_client,          # -> Clerk(...)  (singleton, shared httpx pool)
    averify_request,           # async; verify a request, return ClerkUser | None
    aget_user_by_id,           # async; TTL-cached user lookup
    alist_users_cached,        # async; TTL-cached, single-flight users.list

    # ── v0.8 — loop-free SYNC Clerk surface (SAFE inside WS callback bodies
    #          and job-worker threads — see §13d) ──
    get_sync_client,           # -> Clerk(...)  (singleton, never loop-bound)
    verify_user_sync,          # sync twin of averify_request
    get_user_by_id_sync,       # sync twin of aget_user_by_id
    list_users_sync,           # sync twin of alist_users_cached
    set_user_role_sync,        # merge-patch public_metadata.role (admin save)

    # ── Dash 4.2+ WebSocket auth (AUTO-registered by configure_app since v0.9) ──
    register_websocket_auth,   # call before configure_app only to customise
    ws_auth_registered,        # (v0.9) -> bool — assert from health endpoints

    # ── v0.9 — email enrichment (see §13g) ──
    enrich_user_sync,          # fill email/name/image on an email-less ClerkUser
    aenrich_user,              # async twin — main event loop only
)
```

### `ClerkUser` dataclass (v0.6)

The single shape both backends produce. Populated once per request from
the JWT payload by `ClerkUser.from_jwt_payload(payload, billing_enabled=...)`.

| Field | Type | Notes |
|---|---|---|
| `user_id` | `str` | Required. Clerk `sub`. |
| `email` | `str \| None` | Primary email. **Not in the JWT by default** — stock Clerk session tokens carry no email claim. Since v0.9 the verify paths enrich it via the users API (§13g); on `< 0.9` this was `None` unless the instance customised its session token. |
| `first_name`, `last_name` | `str \| None` | |
| `image_url` | `str \| None` | |
| `role` | `str \| None` | Resolved from `public_metadata.role` → `org_role` (strips `org:` prefix) → top-level `role`. Lowercased. |
| `plan` | `str \| None` | Only populated when `enable_billing=True`. Defaults to `"free"`. |
| `features` | `tuple[str, ...]` | Only populated when `enable_billing=True`. Accepts list or comma-string. |
| `session_id` | `str \| None` | Clerk `sid`. |
| `raw` | `Mapping[str, Any]` | Full immutable JWT payload. |

Methods: `has_role(role)`, `has_plan(plans)`, `has_feature(name)`,
`to_session_dict()`, `from_session_dict(d)`.

### `create_clerk_menu(show_dropdown=True, dropdown_align="right")`

Returns the liquid-glass avatar + dropdown as a Dash component you can drop
into any dmc container (typically `AppShellHeader`). Requires
`register_clerk_auth(headless=True)` or you'll get duplicate-id errors.

- `show_dropdown=False` — bare avatar only (wrap in your own `dmc.Menu`).
- `dropdown_align="left"` — flip the dropdown anchor for left-side avatars.

### `clerk-auth-store` (dcc.Store)

The hook injects this automatically. Payload:

```python
{
    "user_id":    "user_2abc...",       # Clerk user ID
    "email":      "user@example.com",   # primary email
    "first_name": "John",
    "last_name":  "Doe",
    "image_url":  "https://img.clerk.com/...",
    "session_id": "sess_2xyz...",

    # only when enable_billing=True:
    "plan":     "pro",                  # plan slug
    "features": ["analytics", "api"],   # list of feature flags
}
```

Subscribe with `Input("clerk-auth-store", "data")`. `storage_type='memory'`
— rebuilt from Clerk on every page load.

---

## 7. Callback patterns (copy-pasteable)

### Gate a callback on auth state

```python
@callback(
    Output("protected", "children"),
    Input("clerk-auth-store", "data"),
)
def protected(auth):
    if not auth or not auth.get("user_id"):
        return dmc.Alert("Please sign in", color="yellow")
    return dmc.Text(f"Hello, {auth['first_name'] or auth['email']}")
```

### Gate a Flask route

```python
from dash_clerk_auth import require_auth

@app.server.route("/api/private")
@require_auth
def private():
    return jsonify(ok=True)
```

### Gate on a Clerk Billing plan

```python
from dash_clerk_auth import require_plan

@callback(
    Output("pro-feature", "children"),
    Input("pro-btn", "n_clicks"),
    prevent_initial_call=True,
)
@require_plan(["pro", "enterprise"])   # single str also works
def pro_only(n):
    return "Welcome to Pro!"
```

### Gate on a feature flag

```python
from dash_clerk_auth import require_feature

@callback(Output("alerts", "children"), Input("alerts-btn", "n_clicks"))
@require_feature("advanced_alerts")
def alerts(n):
    return render_alerts()
```

### Read session from a Flask route

```python
from dash_clerk_auth import get_current_user_id, get_user_info

@app.server.route("/api/me")
def me():
    uid = get_current_user_id()
    if not uid:
        return jsonify(error="not signed in"), 401
    return jsonify(user=get_user_info())
```

### Soft UI gate (blur vs block)

Decorators BLOCK execution. For visual gating (blur, upgrade CTA), read
`clerk-auth-store` in the callback and branch instead:

```python
@callback(Output("pro-card", "style"), Input("clerk-auth-store", "data"))
def blur_if_not_pro(auth):
    plan = ((auth or {}).get("plan") or "free").lower()
    if plan != "pro":
        return {"filter": "blur(4px)", "pointerEvents": "none"}
    return {}
```

### Gate a layout server-side (v0.6 — fail-closed)

This is the v0.6 fix for the production foot-gun where heavy admin
layouts built for everyone (and stalled the worker). The decorator
commits to ONE branch *before* any callback or layout body runs.

```python
from dash_clerk_auth import require_role_layout
import dash

@require_role_layout("admin")
def layout():
    return _build_admin_content()       # NOT built for non-admin users

dash.register_page(__name__, path="/admin", layout=layout)
```

Defaults: `on_inconclusive="forbidden"` (fail closed — anonymous gets
the placeholder). Pass a custom `forbidden=` placeholder to override
the default liquid-glass card. Override the policy with
`on_inconclusive="allow"` (let through) or `"passthrough"` (legacy
v0.5 "render both" behaviour, kept for explicit opt-in).

`require_plan_layout("pro")` / `require_feature_layout("exports")` /
`require_auth_layout()` follow the same shape.

### Read identity in any callback (v0.6 — backend-neutral)

```python
from dash import callback, Input, Output, no_update
from dash_clerk_auth import callback_user

@callback(Output("hello", "children"), Input("trigger", "n_clicks"))
def greet(n):
    user = callback_user()              # ContextVar on FastAPI; flask.g on Flask
    if user is None:
        return no_update
    return f"Hi, {user.first_name or user.email}"
```

### `async def` callback on Dash 4 + FastAPI (v0.6)

`websocket_callbacks=True` in Dash 4.2+ enables real async callbacks.
Use the async Clerk wrapper so you don't block the event loop:

```python
from dash import callback, Input, Output
from dash_clerk_auth import alist_users_cached, callback_user

@callback(
    Output("admin-users", "children"),
    Input("admin-refresh-btn", "n_clicks"),
    websocket=True,            # Dash 4.2+ async-callback flag
)
async def load_users(n_clicks):
    user = callback_user()
    if user is None or not user.has_role("admin"):
        return "Not authorised"
    # cached for 60s with single-flight; force=True only on explicit refresh
    users = await alist_users_cached(force=bool(n_clicks))
    return [u.get("email") or u.get("id") for u in users]
```

---

## 8. Multi-domain (satellite galaxy) pattern

Architecture: one Clerk application, N Dash apps, each on its own TLD,
one of them acts as the auth hub (primary), the rest are Clerk satellites
that share sessions via the JWT cookie flow.

```python
# domain_config.py
CLERK_DOMAINS = {
    "ai": {   # PRIMARY hub, hosts sign-in
        "is_satellite": False,
        "satellite_domain": None,
        "sign_in_url": "/sign-in",
        "sign_up_url": "/sign-up",
        "allowed_redirect_origins": [
            "https://example.store", "https://example.me", "https://example.shop",
        ],
    },
    "store": {  # SATELLITE
        "is_satellite": True,
        "satellite_domain": "example.store",       # host only, no protocol
        "sign_in_url": "https://example.com/sign-in",
        "sign_up_url": "https://example.com/sign-up",
        "allowed_redirect_origins": [],
    },
    # ... me, shop, etc.
}

# app.py
DOMAIN_APP = os.environ["DOMAIN_APP"]            # "ai" | "store" | "me" | ...
cfg = CLERK_DOMAINS[DOMAIN_APP]

register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],
    clerk_frontend_api=os.environ["CLERK_FRONTEND_API"],
    is_satellite=cfg["is_satellite"],
    satellite_domain=cfg["satellite_domain"],
    sign_in_url=cfg["sign_in_url"],
    sign_up_url=cfg["sign_up_url"],
    allowed_redirect_origins=cfg["allowed_redirect_origins"],
    headless=True,        # satellites render their own headers
)
```

**Key design rules:**

1. **`clerk_user_id` is the only cross-database join key.** Don't use
   integer FKs between databases — each satellite owns its own DB. Every
   user-scoped table carries a string `clerk_user_id` column.
2. **One Clerk webhook endpoint on the primary.** Clerk doesn't need to
   know about the satellites. The primary receives user/plan/subscription
   events and fans the change out to each satellite DB.
3. **Plan changes don't need cross-DB writes.** Satellites read the `plan`
   claim live from `clerk-auth-store` on every session update — no
   propagation needed.
4. **Shared Clerk app, unique Clerk frontend API.** `CLERK_FRONTEND_API` is
   the same value on every domain. Publishable + secret keys are the same.
5. **Each satellite has its own Flask session store.** Sessions are
   service-local; only the Clerk JWT crosses domain boundaries.

See `examples/pages/multi_domain.py` in the repo for a complete
worked example of a multi-domain galaxy.

---

## 9. Compatibility matrix & gotchas

| Concern | Detail |
|---|---|
| **Dash 3 vs 4** | Works on both. `@hooks.index()` / `@hooks.layout()` are stable across 3.0 – 4.1. |
| **Dash 4 `backend="fastapi"`** | **Supported in v0.6.** `register_clerk_auth(backend="auto")` detects it and installs `ClerkASGIMiddleware` instead of Flask-Session. Install with the `[fastapi]` extra: `pip install 'dash-clerk-auth[fastapi]'`. |
| **Dash 4 `backend="quart"`** | Best-effort: same ASGI path as FastAPI. Install with `pip install 'dash-clerk-auth[quart]'`. Less tested than FastAPI; ship to staging first. |
| **Dash 4.2+ WebSocket callbacks** | **Supported in v0.7, hardened for `4.2.0` final in v0.8, auto-wired in v0.9.** `ClerkASGIMiddleware` runs on WebSocket scope (not just HTTP). Since v0.9 `configure_app` registers the WS lifecycle hooks (`websocket_connect`, `websocket_message`) and the per-renderer identity registry automatically on ASGI backends (`websocket_auth=False` to opt out; `ws_auth_registered()` to assert). `current_user()` works inside WS-served callbacks. Transport guidance: prefer per-callback `@callback(websocket=True)` over the global `websocket_callbacks=True` — the renderer rule is `global_enabled \|\| callback.websocket`, so persistent/`set_props` callbacks keep working with the global flag off while ordinary callbacks ride HTTP. The registry resolves via `ctx.websocket._renderer_id`, a property present since **4.2.0rc3 and unchanged in 4.2.0 final** (it was a `get_websocket()` method on rc1/rc2 — v0.8 resolves both). v0.8 also made the registry **thread-safe**. No-op on Dash < 4.2 — safe to call unconditionally. |
| **Calling Clerk from a WS callback body (v0.8)** | The async helpers (`averify_request`/`aget_user_by_id`/`alist_users_cached`) are **main-event-loop only** — Dash 4.2 runs each WS callback via `asyncio.run()` in a fresh per-call loop, so awaiting the loop-bound cached client raises `Event loop is closed`. Use the loop-free `verify_user_sync` / `get_user_by_id_sync` / `list_users_sync` / `set_user_role_sync` instead. See §13d. |
| **Multi-Clerk-app cookie collision (v0.7 fix)** | Signing into multiple Clerk dev apps on `localhost`/`127.0.0.1` leaves stale `__session_<suffix>` cookies. Clerk's SDK reads the first matching `__session*` and may pick the wrong app's JWT, returning `JWK_KID_MISMATCH`. v0.7 strips per-app suffixed cookies (`__session_<suffix>`, `__client_uat_<suffix>`, `__refresh_<suffix>`, `__clerk_db_jwt_<suffix>`) before passing to Clerk's SDK, so the canonical no-suffix cookies (which always belong to the active app) win. |
| **`__dca_identity` cookie (v0.7)** | Verified-positive cache for the Clerk verdict. Signed against `session_secret`. Minted on every successful Clerk verify. Subsequent requests verify it locally (HMAC, microseconds) and skip the JWKS roundtrip. See §13. |
| **dmc 2.3 → 2.6** | All versions work. The hook doesn't call `dmc` internally; it only uses `dash.html`. |
| **clerk-backend-api 5.x–7.x** | Floor 5.x required since v0.6 (uses `authenticate_request_async`); cap widened to `<8` in v1.0.1 for the `cryptography>=50` security floor. v0.5 supported 4.x via a multi-path import; v0.6 dropped that. |
| **Flask not required (v0.6)** | The package imports without Flask installed. Only needed when `backend="flask"` (or detected as such). |
| **Localhost + satellite** | Clerk rejects satellite mode on unregistered localhost domains. Detect `is_localhost` and flip `is_satellite=False` for local dev — all ports share cookies anyway. |
| **`register_clerk_auth()` is idempotent** | Second call logs a warning and no-ops. Useful when your app bootstraps twice (reloader). |
| **`flask_secret_key` deprecated** | v0.6 introduced `session_secret=` (same secret drives both backends). `flask_secret_key=` keeps working through v0.x with a one-shot `DeprecationWarning`. |
| **MantineProvider required** | The Clerk modals + liquid-glass CSS read `[data-mantine-color-scheme="dark\|light"]` on `<html>`, and **since v0.8.1 they're coloured from Mantine's own scheme-aware CSS variables** (`--mantine-color-body`, `--mantine-color-text`, `--mantine-color-default`, …). Wrap your layout in `dmc.MantineProvider` so those variables exist and flip on toggle; without it the modals fall back to the baked light-mode literals and won't follow the theme. See §13f. |
| **Duplicate avatar ids** | If you call `create_clerk_menu()` without `headless=True`, Dash will error the next time a callback fires with "duplicate id 'clerk-user-avatar'". The helper logs a WARNING pointing at the fix. |
| **Modal legibility on theme toggle** | First addressed in 0.5.0 (opaque `--clerk-modal-bg`). **0.8.0** added solid light-mode overrides; **0.8.1** fixed the dark case by sourcing Clerk's `appearance` colours from Mantine's scheme-aware variables — the previous approach baked colours at `Clerk.load()` and went stale (dark-on-dark) after a light→dark toggle. The modals now re-theme instantly with no Clerk re-render. See §13f + CHANGELOG. |
| **`require_auth` (callback) vs `require_auth_layout`** | Use `_layout` variants when gating a *layout* — they fail closed, never build the protected layout for unauthorised visitors. Use the callback `require_auth` (v0.5) when gating a single callback's execution. |
| **`require_auth` in a Dash callback** | Works, but returns `None` when unsigned in instead of redirecting — the decorator can't issue a Flask redirect from a clientside callback context. Prefer the callback-gate pattern in §7 for UI. |
| **Clerk billing claims** | Read from `user.publicMetadata.plan` / `user.publicMetadata.features` on the client. Configure a JWT template in the Clerk dashboard to expose `{{user.public_metadata.plan}}` + `{{user.public_metadata.features}}` as session claims. |

---

## 10. Environment variables

| Variable | Required? | Purpose |
|---|---|---|
| `CLERK_SECRET_KEY` | yes | Backend SDK |
| `CLERK_PUBLISHABLE_KEY` | yes | Frontend key |
| `CLERK_SIGN_IN_URL` | yes | Sign-in redirect target (and JS source origin in single-domain mode) |
| `CLERK_FRONTEND_API` | recommended | Clerk Frontend API origin (required in satellite mode) |
| `CLERK_SIGN_UP_URL` | optional | Sign-up redirect target for satellites |
| `SESSION_SECRET` | prod-required (v0.6 canonical) | Signs the session cookie. Falls back to `FLASK_SECRET_KEY` if unset for v0.5 compat. |
| `FLASK_SECRET_KEY` | prod-required (v0.5 alias) | Deprecated alias for `SESSION_SECRET`; still read for backwards-compat. |
| `CLERK_WEBHOOK_SECRET` | optional | For Svix webhook signature verification |
| `DEBUG` | optional | Enables logging + debug panel when truthy |

---

## 11. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `ModuleNotFoundError: clerk_backend_api.jwks_helpers` | You're on dash-clerk-auth 0.1.0 / 0.2.0 with `clerk-backend-api>=4.0` | Upgrade to `dash-clerk-auth>=0.5.0`. |
| Worker hang / 30+ second response on FastAPI when an admin page renders for an anonymous visitor | v0.5 `try_admin_from_request()` returned `None` on FastAPI (no `flask.request`) so the gate fell through to "render both" — anonymous bots paid the cost of building the heavy admin layout. | Upgrade to v0.6 and replace ad-hoc `gate_admin()` helpers with `@require_role_layout("admin")` from the package. Fail-closed default skips the heavy layout for non-admins. |
| `RuntimeError: dash_clerk_auth backend='fastapi'/'quart' requires starlette` at boot | Missing `[fastapi]` extra | `pip install 'dash-clerk-auth[fastapi]'`. |
| `RuntimeError: dash_clerk_auth: unable to determine Dash backend from app.server` | `app.server` is some custom WSGI/ASGI app that isn't Flask, Starlette, FastAPI, or Quart | Pass `backend="flask"` or `backend="fastapi"` to `register_clerk_auth()` explicitly. |
| Async callback blocks the event loop | Calling sync `clerk.users.list(...)` inside an `async def` callback | Use `await alist_users_cached()` / `await aget_user_by_id()` from `dash_clerk_auth`. They share an `httpx.AsyncClient` pool and have a TTL+single-flight cache. |
| `current_user()` returns `None` inside a callback on FastAPI | The `ClerkASGIMiddleware` wasn't installed, OR you're running on `backend="flask"` where `before_request` populates `g.clerk_user` (still works). | Make sure `configure_app(app)` runs after `register_clerk_auth(...)`. Confirm the backend was detected with `dash_clerk_auth.detect_backend(app.server)`. |
| `DeprecationWarning: register_clerk_auth(flask_secret_key=...) is deprecated` | v0.6 renamed the kwarg to `session_secret=` | Rename the kwarg. The old name keeps working through v0.x. |
| Avatar floating top-right but I want it in my header | Default mode injects a fixed-position avatar | Pass `headless=True` + `create_clerk_menu()` in your `AppShellHeader`. |
| Duplicate id `clerk-user-avatar` | `create_clerk_menu()` called without `headless=True` | Pass `headless=True` (or remove the `create_clerk_menu()` call). |
| Signed out, but the site still serves gated pages | **Pre-1.0.3 defect.** The logout handler called `window.Clerk.signOut()` and reloaded — client side only. Server identity resolves from the signed `__dca_identity` cookie first, and that cookie survived, so the browser stayed authenticated for up to `session_lifetime_days` (7 by default). | Upgrade to v1.0.3: sign-out awaits `Clerk.signOut()`, then `POST /api/auth/signout` (which clears the session and evicts the cookie), then reloads. Note the cookie is a stateless signed token: eviction is not cryptographic revocation, so a value captured beforehand verifies until it expires. Lower `session_lifetime_days` to shrink that window. |
| `POST /api/auth/session` or `/api/auth/signout` returns 422 on FastAPI | **Pre-1.0.4 defect.** The handlers took an unannotated `request`, which FastAPI resolves as a required *query* field, so it rejected every call before the handler ran. Invisible, because the injected script never checked the result — the only symptom was sign-out not revoking server-side. Starlette and Quart were unaffected. | Upgrade to v1.0.4. Stopgap if you cannot: mount Starlette `Route`s around the package's handlers. |
| Signed out on the primary, but a satellite still serves gated pages on a FRESH load | **Pre-1.0.4 defect.** 1.0.3 revoked on a signed-in → signed-out *transition*, which requires the tab to have observed the signed-in state. A browser that signed out elsewhere and then navigated here never had one, so the server kept serving off the `__dca_identity` ghost. | Upgrade to v1.0.4: on load, ClerkJS signed-out plus a server-rendered signed-in page ⇒ POST `/api/auth/signout`, then reload. Application click shims cannot cover this — nothing is clicked on the satellite. |
| Signed out on one host, still signed in on a sibling host | Same root cause, other half: a sign-out on another tab or another host of the same Clerk instance left each site's local identity cookie in place. | v1.0.3 fires the same revoke POST on a signed-in → signed-out transition, not only on the button. |
| Avatar shows the user's picture, but goes blank on hover | A host stylesheet is drawing a halo as `#clerk-user-avatar::before { z-index: -1 }`. The package sets `isolation: isolate` on the avatar, which makes it a **stacking context** — and inside one, a negative-z-index pseudo-element paints ABOVE the element's own background rather than behind it (CSS 2.1 Appendix E: the element's background is step 2, negative-z-index descendants are step 3). Since the picture IS the avatar's `background-image`, the halo covers it. The giveaway is that `getComputedStyle(el).backgroundImage` is still correct — the value was never overridden, it is being painted over. | Draw halos with `box-shadow` instead, which cannot overlap the element it surrounds — that is why the package's own hover halo uses one. Or move the pseudo-element to a wrapper around the avatar. |
| Signed-out avatar is a blank white circle | **Pre-1.0.3 defect.** The default avatar was a DiceBear API URL — a third-party image service on the critical path. When it rate-limited or moved, the background failed to load and the circle rendered empty. | Upgrade to v1.0.3 — the default is an inline SVG data URI with no network dependency. `AVATAR_DEFAULT_LIGHT` / `AVATAR_DEFAULT_DARK` are exported for apps rendering their own menu. |
| Satellite Sign In button 404s | `satellite_sign_in_redirect` was set to something that is not an absolute `http(s)` URL (a bare host, a path, or a stray `=true`). Pre-1.0.3 the package warned and used it anyway, navigating inside the satellite — where sign-in cannot happen. | v1.0.3 discards a non-absolute value and logs at ERROR; the button falls back to Clerk's Account Portal. Set it to the primary's full sign-in URL to restore the direct redirect. |
| Avatar renders but clicking it does nothing | Pre-1.0.2 the click handlers were bound to the avatar and menu buttons at load time, so they were never attached when the menu mounted late, and died with the old nodes whenever Dash replaced the menu on navigation. | Upgrade to v1.0.2 — handlers are delegated to `document`. (On a satellite, a *dead* avatar with no console error is the separate 0.9.1 `data-clerk-domain` issue.) |
| Light-mode profile modal looks washed out, text bleeds through | Running 0.2.0 CSS where the modal used the dropdown's transparent glass | Upgrade to 0.5.0 (`--clerk-modal-bg` tier). |
| Sign-in modal opens but sign-in on a satellite doesn't carry to sibling | Missing satellite config | Set `is_satellite=True` + `satellite_domain` on satellites, and `allowed_redirect_origins` on the primary. Add all satellites as "Satellite domains" in the Clerk dashboard. |
| Avatar doesn't populate / shows placeholder forever | Two distinct causes. (a) `clerk.browser.js` never loaded. (b) **Pre-1.0.2 race:** the client script resolved the menu with `getElementById` at the one moment `Clerk.load()` resolved, but Dash mounts that menu from a separate `/_dash-layout` fetch — when Clerk won that race the update no-opped, and `addListener` never re-fired because the session never *changed*. Intermittent by nature, and the giveaway is that `current_user()` and `clerk-auth-store` are both correct while the avatar is not. | (a) Check `clerk_frontend_api` is set and reachable; look for a 404 on the script tag. (b) Upgrade to v1.0.2 — the menu is rendered from the verified session server-side, state is stamped as a class on `<html>`, and a `MutationObserver` re-applies it whenever Dash mounts or replaces the menu. |
| `RuntimeError: Working outside of request context` | Calling `get_current_user_id()` outside a Flask request | Use the callback pattern (read `clerk-auth-store.user_id`) instead. 0.5.0 added `_safe_session()`; v0.6 layered `current_user()` on top so most call sites now return `None` gracefully instead of crashing. |
| `clerk_sign_in_url is required` at boot | Missing env var | Set `CLERK_SIGN_IN_URL` or pass `clerk_sign_in_url=` explicitly. |
| Callbacks not wired / `clerk-auth-store` never updates | Layout isn't wrapped in `dmc.MantineProvider`, or `configure_app(app)` not called | Both are required. |
| `WebSocket auth not registered — Dash X has no websocket_connect hook` | Running Dash < 4.2.0rc1 | Either upgrade Dash, or simply ignore — the message is informational and the call is a safe no-op. |
| `Clerk verify rejected: reason=...JWK_KID_MISMATCH` on every request | Browser is sending a stale `__session_<suffix>` cookie from a different Clerk dev app on the same hostname, OR `CLERK_SECRET_KEY` is from a different Clerk app than `CLERK_PUBLISHABLE_KEY`. | v0.7 auto-strips other-app suffixed cookies, so this should self-heal on upgrade. If it persists, verify both keys belong to the same app in the Clerk dashboard. The package's log line includes the JWT's `kid` to help diagnose. |
| Page locks me out then a refresh fixes it (Dash 4.2 + WebSocket callbacks) | v0.6 `ClerkASGIMiddleware` only ran on HTTP scope; Dash 4.2 page renders run inside WS-served callbacks that bypassed it. | Upgrade to v0.7 — the middleware now handles WS scope, and the per-renderer identity registry bridges the thread-pool dispatch. Optionally call `register_websocket_auth(on_anonymous="allow")`. |
| `__dca_identity` cookie isn't appearing in browser despite successful sign-in | Slow-path Clerk verify is failing silently. | Surface `dash_clerk_auth` logs at INFO (`logging.basicConfig(level=logging.INFO)`) — the package logs the rejection reason. Most often this is the multi-app cookie collision above (auto-fixed in v0.7). |
| `Clerk auth already initialized, skipping re-initialization` warning | The module is being imported twice in the same process — usually from running `python app_fastapi.py` where `if __name__ == "__main__"` calls `uvicorn.run("examples.app_fastapi:server", ...)` and uvicorn re-imports it as a different module name. | Run uvicorn directly: `uvicorn examples.app_fastapi:server --port 8050`. |
| `user.email is None` for a verified user; email-keyed gate denies the owner | Stock Clerk session JWTs carry no email claim — pre-0.9 the email-less user was jti-cached and minted into `__dca_identity` for the cookie lifetime. | Upgrade to v0.9 (automatic enrichment, §13g). Alternative on any version: customise the instance's session token with `{"email": "{{user.primary_email_address}}"}` in the Clerk dashboard. |
| `backend="flask"`: browser signed in but `current_user()` / `g.clerk_user` always `None` | v0.5→v0.7 regression: the only flask identity writers lived in `POST /api/auth/session` and the injected client script stopped calling it. | Upgrade to v0.9 — the flask `before_request` slow path verifies `__session` and mints `__dca_identity` with no client cooperation. |
| Log spam on idle tabs: `reason=...SESSION_TOKEN_MISSING` + "slow-path Clerk verify FAILED" | Expected idle state — Clerk JWTs rotate every ~60s; between rotations requests carry `__client_uat`/`__refresh_*` but no `__session`. | Upgrade to v0.9: the roundtrip is skipped and the state logs `no session token (rotated/idle)` at DEBUG. It was never a failure. |
| `RuntimeError: dictionary changed size during iteration` from `dash/backends/_fastapi.py::websocket_handler` on WS disconnect | **Upstream Dash 4.2.0 bug** (not this package): disconnect cleanup iterates `pending_callbacks.values()` while executor done-callbacks pop from it. | Harmless teardown noise. Fix belongs in dash (`list(pending_callbacks.values())`). Not to be confused with the registry race this package fixed in v0.8. |
| `?__clerk_handshake=...` redirect 500s a Dash page | Dash Pages forwards query params to callable layouts as kwargs; a bare `def layout():` raises `TypeError`. | Define page layouts as `def layout(**kwargs):`. The package's sign-in flow *produces* these redirects, so this bites every gated page eventually. |

---

## 12. Release history (abbreviated)

- **1.0.4** (2026-08-21) — **Two defects from a live network certification.**
  (1) The FastAPI auth endpoints had never been callable: registered with an
  unannotated `request` parameter, which FastAPI resolves as a required query
  field, so `POST /api/auth/{session,signout}` answered **422** on every
  FastAPI deployment since they existed. Invisible because the client never
  inspected the response; the only symptom was sign-out not revoking.
  Handlers are now annotated `request: Request` (module-level guarded import
  — `from __future__ import annotations` means FastAPI resolves it against
  module globals). Starlette and Quart were never affected. (2) A signed-out
  browser kept being served from the `__dca_identity` ghost on a FRESH load:
  1.0.3 only caught a live signed-in → signed-out transition, which requires
  the tab to have observed the signed-in state. Now, ClerkJS signed-out plus
  a server-rendered signed-in page triggers a revoke and reload — once, and
  only on a confirmed revoke. `revokeServerSession()` also checks the
  response instead of assuming it worked, which is what hid (1).
- **1.0.3** (2026-08-20) — **Sign out now revokes server-side identity.**
  The logout handler was client-side only: `Clerk.signOut()` invalidates
  `__session`, but server identity resolves from the signed
  `__dca_identity` cookie first, so a signed-out browser kept being served
  gated pages until that cookie expired — 7 days by default. Sign-out now
  awaits `Clerk.signOut()`, then `POST /api/auth/signout`, then reloads, and
  a signed-in → signed-out transition fires the same POST so a sign-out in
  another tab or on another host propagates. Eviction is not cryptographic
  revocation — the cookie is stateless and a captured value verifies until
  expiry; lower `session_lifetime_days` to shrink that window. Also: the
  signed-out avatar is an inline SVG data URI instead of a third-party
  image API (it rendered blank when that service faltered), and a
  non-absolute `satellite_sign_in_redirect` is discarded with a loud error
  rather than used to build a 404ing Sign In button.
- **1.0.2** (2026-08-18) — **The avatar could stay signed-out on a page
  where the session was valid.** The injected script resolved the menu
  with `getElementById` at the single moment `Clerk.load()` resolved;
  Dash mounts that menu from a separate `/_dash-layout` fetch, so when
  Clerk won the race every lookup returned `null`, the update silently
  no-opped, and `addListener` never fired again because the session never
  *changed* — leaving a signed-in user on the placeholder avatar and a
  "Sign In" menu while `current_user()` and `clerk-auth-store` were both
  correct. Dash re-mounting the menu on navigation put the stale paint
  back. Three independent layers now: `create_clerk_menu()` renders the
  verified viewer server-side, signed-in/out is a class on `<html>` the
  stylesheet keys off (so a late-mounted menu is right on first paint),
  and a `MutationObserver` re-applies the cached session to any menu Dash
  mounts or replaces. Click handlers are delegated to `document` instead
  of bound to nodes that get replaced. Profile fields render via
  `textContent`, not `innerHTML`. `scripts/avatar_race_harness.py`
  reproduces the race with no Clerk account.
- **1.0.1** (2026-08-18) — `clerk-backend-api` cap widened to
  `>=5.0.0,<8` so applications can pin `cryptography>=50.0.0`; SDK 5.x
  capped `cryptography` at `<47.0.0`, below the fix for four advisories.
  Metadata only — no runtime change.
- **1.0.0** (2026-08-03) — First stable release. The 0.9.x surface
  (signed identity cookie, WebSocket identity registry, sync Clerk
  helpers, satellite wiring) declared stable; Python floor raised to
  `>=3.10`.
- **0.9.1** (2026-07-31) — **Satellite-mode fix:** with the script-tag
  installation, ClerkJS v5 auto-instantiates from the tag's data
  attributes and its satellite check reads the *instance* domain — a
  domain passed only to `Clerk.load()` is ignored, so satellites threw
  `ClerkJS: Missing domain and proxyUrl` and the user button never
  mounted (dead avatar) while server-side verification kept working.
  The generated script tag now carries
  `data-clerk-domain="<satellite_domain>"` when `is_satellite=True`.
- **0.9.0** (2026-06-11) — **Production-gap fixes from a downstream
  debugging report** (production Dash 4.2.0 app, flask dev +
  fastapi prod). **(1) Email enrichment:** Clerk session JWTs carry no
  email claim; both verify paths now fetch the user once per `user_id`
  per process (sticky cache) BEFORE jti-caching or minting
  `__dca_identity`, so `user.email` is populated everywhere — new
  `enrich_user_sync` / `aenrich_user` (§13g). **(2) Flask server-side
  identity restored:** `before_request` gained the ASGI-equivalent slow
  path (verify `__session` via `verify_user_sync`, mint `__dca_identity`
  via `after_this_request`) — pre-0.9, nothing wrote identity on flask
  because the client script stopped POSTing to `/api/auth/session` in
  v0.6. **(3) WS auth auto-registration:** `configure_app` (ASGI) calls
  `register_websocket_auth()` itself; `websocket_auth=False` opts out;
  WARNING when `websocket_callbacks=True` runs unprotected; new
  `ws_auth_registered()`. **(4) Observability:** DEBUG logs on every
  resolve path (flask outcomes, WS connect source, first renderer bind).
  **(5) Idle quieting:** `__client_uat`-only requests skip the
  guaranteed-reject verify on all three paths and log at DEBUG;
  `SESSION_TOKEN_MISSING` rejects log DEBUG everywhere. 136-test suite —
  the email-less JWT payload (`{sub, sid, v}`) is now the canonical
  fixture shape.
- **0.8.1** (2026-06-02) — **Clerk modals track the DMC theme on toggle.**
  Clerk's `appearance` colours were baked once at `Clerk.load()` from the
  then-active theme, so a light→dark toggle left dark-on-dark text. Every
  theme-dependent colour in `appearance` (`variables` + `elements`) now resolves
  from Mantine's scheme-aware CSS variables (`--mantine-color-body`,
  `--mantine-color-text`, `--mantine-color-default`, `--mantine-color-placeholder`,
  `--mantine-primary-color-*`) with light fallbacks, plus a dark-mode CSS
  override block mirroring 0.8.0's light one and a scheme-neutral `::placeholder`
  rule (injected `<style>` + `assets/style.css`). Modals re-theme instantly, with
  no Clerk re-render, and reach Clerk's hashed `cl-internal-*` elements. See §13f.
- **0.8.0** (2026-06-02) — **Dash `4.2.0` (final) scale hardening + loop-free
  sync Clerk API.** Shipped `verify_user_sync` / `get_user_by_id_sync` /
  `list_users_sync` / `set_user_role_sync` / `get_sync_client()` — safe inside
  Dash 4.2 WS callback bodies and job threads, where the async client breaks on
  the per-callback `asyncio.run()` model (`Event loop is closed`); the async
  helpers also self-heal (rebuild + retry once) on that and the "bound/attached
  to a different loop" variants. Made `_ws_registry` thread-safe (a `threading.Lock`
  around the eviction sweep that could race a worker `lookup()`), and made
  `renderer_id` resolution work across rc1 (`get_websocket()`) → rc3/final
  (`ctx.websocket`). Removed a leaked ContextVar set in the WS connect hook.
  Light-mode CSS overrides for the SignIn/UserProfile modals. 115-test suite.
  See §13d/§13e.
- **0.7.0** (2026-05-14) — **Dash 4.2 WebSocket reliability + identity
  cookie cache.** `ClerkASGIMiddleware` now handles WebSocket scope (not
  just HTTP), so Dash 4.2 WS-served callbacks see the verified user
  immediately. New `_ws_registry` bridges Dash's thread-pool callback
  dispatch (where ContextVars don't propagate) via a per-`renderer_id`
  user map, populated in the `websocket_message` hook and read from
  `current_user()` via `ctx.websocket._renderer_id`. New signed
  `__dca_identity` cookie (in `_identity_cookie.py`) caches the Clerk
  verdict — first request after sign-in pays for the JWKS roundtrip and
  mints the cookie; every subsequent request HMAC-verifies locally
  (microseconds) and skips Clerk entirely. `register_websocket_auth()`
  rewritten against the actual Dash 4.2.0rc3 hook names (`websocket_connect`,
  `websocket_message` — v0.6 looked up nonexistent names and silently
  no-op'd) and gains `on_anonymous="allow"` (default, mixed-traffic safe)
  vs `"close"` (v0.6 fail-closed). `@hooks.layout()` pre-hydrates
  `clerk-auth-store` from `current_user()` at build time, killing the
  first-paint anonymous flash. Cookie hygiene: per-app suffixed Clerk
  cookies (`__session_<suffix>` etc) are stripped before Clerk SDK calls
  so multi-Clerk-dev-app collisions can't trigger `JWK_KID_MISMATCH`.
  Diagnostic logging on Clerk verify rejections includes the JWT's `kid`
  for KID_MISMATCH cases. 94-test suite. See
  [`.claude/planning/0.7-architecture-and-bug-postmortem.md`](.claude/planning/0.7-architecture-and-bug-postmortem.md).
- **0.6.0** (2026-04-30) — **First-class Dash 4 `backend="fastapi"` /
  `backend="quart"` support.** Backend-neutral `current_user()` /
  `ClerkUser` dataclass via `contextvars.ContextVar` (FastAPI) /
  `flask.g` (Flask). New `ClerkASGIMiddleware` verifies Clerk sessions
  once per HTTP request with a JTI-keyed cache. New
  `@require_*_layout` decorators that fail-closed by default — fixes
  the production foot-gun where heavy admin layouts built for anonymous
  visitors. New async Clerk wrapper (`averify_request`,
  `aget_user_by_id`, `alist_users_cached`) with shared `httpx`
  connection pool, TTL caches and single-flight semantics. Opt-in
  Dash 4.2+ WebSocket auth (broken in v0.6 — looked up wrong hook names;
  fixed in v0.7). `flask_secret_key=` deprecated in favour
  of `session_secret=`. `clerk-backend-api>=5.0` floor. 57-test suite.
- **0.5.0** (2026-04-22) — Clerk SDK 4.x/5.x compat, satellite-domain
  kwargs, `create_clerk_menu()` helper, modal legibility fix, soft Flask
  detection, Dash 4 + dmc 2.6 verified, structured multi-page demo.
- **0.2.0** (2025-06-04) — Clerk Billing support (`@require_plan`,
  `@require_feature`, `plan` + `features` in `clerk-auth-store`).
- **0.1.0** (2025-06-02) — Initial release for the Plotly Dash Plugin
  Challenge.

See `CHANGELOG.md` for full details.

---

## 13. Cookie + WebSocket reliability, sync API, theming & enrichment (v0.7 design, v0.8 hardening, v0.9 gaps closed)

The v0.7 release added two pieces of architecture that downstream callers
should know about — they're transparent in normal use but matter when
debugging or extending the package.

### 13a. Signed identity cookie

After every successful Clerk verify, the package mints a signed cookie:

```
Set-Cookie: __dca_identity=<itsdangerous URLSafeTimedSerializer payload>;
            Path=/; Max-Age=604800; HttpOnly; SameSite=Lax[; Secure]
```

The payload is `ClerkUser.to_session_dict()` — same shape as the legacy
Flask session dict. The cookie is signed with the same `session_secret`
that signs Flask/Starlette session cookies; rotating the secret invalidates
all three together.

**Reading.** `ClerkASGIMiddleware._resolve_identity` checks the cookie first
on every request. HMAC verify is microseconds; valid cookie → done, no
Clerk roundtrip. Invalid/missing → fall through to `averify_request` and
re-mint on success.

**TTL.** `session_lifetime_days * 86400` (default 7d), bounded by a minimum
of 60s. **NOT bounded by the JWT's `exp`** — Clerk dev session JWTs rotate
every 60s, and bounding the cookie's TTL by the JWT's lifetime would mean
the cookie expires almost immediately. The cookie's job is to cache the
*identity* across many JWT refreshes; the user's identity doesn't change
every 60s, their JWT does.

**Mint sites (4, all signing with the same secret):**

1. `ClerkASGIMiddleware._handle_http` wraps the inner app's `send`
   callable; injects `Set-Cookie` on `http.response.start` after a slow-path
   verify. Covers steady-state authenticated browsing on ASGI.
2. **(v0.9)** Flask `before_request` slow path mints via
   `flask.after_this_request` after a successful `verify_user_sync`.
   Covers steady-state authenticated browsing on Flask — the flask twin
   of site 1, and the fix for "flask never establishes identity".
3. `_fastapi.py::_session_handler` (`/api/auth/session` POST) attaches the
   cookie to its JSONResponse after Clerk confirms the bearer token. Covers
   the sign-in moment.
4. Flask `/api/auth/session` route in `__init__.py::auth_session` calls
   `response.set_cookie(...)`. Covers the Flask-backend sign-in moment
   for clients that still POST tokens.

All four mint AFTER v0.9 email enrichment (§13g), so the cookie always
carries the email.

**Read sites:** `_identity_cookie.verify(token, secret, max_age)`,
called from the ASGI middleware, the Flask `before_request` hook, and the
WS connect hook.

**Clear:** `/api/auth/signout` on both backends emits
`Set-Cookie: __dca_identity=; Max-Age=0`.

### 13b. WS-aware ASGI middleware + per-renderer registry

Dash 4.2.0rc3 dispatches WebSocket-served callbacks via
`ThreadPoolExecutor.submit(...)` — `concurrent.futures` does NOT propagate
ContextVars from the asyncio task to the worker thread. So the v0.6
ContextVar-based identity disappeared inside WS-served callbacks.

v0.7's fix has two halves:

1. **`ClerkASGIMiddleware` now handles `scope["type"] == "websocket"`.**
   On WS handshake it resolves identity via the same fast/slow path as
   HTTP and stashes the verdict on `scope["state"]["clerk_user"]`
   (Starlette surfaces this as `websocket.state.clerk_user`).

2. **`_ws_registry.py` bridges the thread-pool gap.** A bounded
   `renderer_id → ClerkUser` map (24h TTL, 4096-entry cap, opportunistic
   eviction). Populated in the `websocket_message` hook from
   `websocket.state.clerk_user` (asyncio task), keyed by
   `message["rendererId"]` (a UUID Dash assigns per WS connection). Read
   from `current_user()` via `dash.callback_context.websocket._renderer_id`
   inside the worker thread.

The chain inside the worker:

```python
# inside the WS-served callback, on a thread-pool worker
def my_callback(...):
    user = current_user()
    # current_user() walks:
    #   1. ContextVar (empty — didn't propagate)
    #   2. _ws_registry.lookup(ctx.websocket._renderer_id) ← HIT
    #   3. (skipped) Flask g
    # → returns ClerkUser
```

### 13c. Multi-Clerk-app cookie hygiene

`_clerk_client._build_httpx_request` strips per-app suffixed Clerk cookies
before calling `Clerk.authenticate_request_async`:

| Suffixed name | Action |
|---|---|
| `__session_<suffix>` | stripped |
| `__client_uat_<suffix>` | stripped |
| `__refresh_<suffix>` | stripped |
| `__clerk_db_jwt_<suffix>` | stripped |
| canonical `__session`, `__client_uat`, `__refresh`, `__clerk_db_jwt` | kept |
| every non-Clerk cookie | kept untouched |

Why: Clerk's frontend SDK uses a per-instance suffix scheme so multiple
Clerk apps can coexist on the same hostname (essential for `localhost`
dev). Each app drops its own `__session_<suffix>`. Browsers send all of
them on every request. Clerk's backend SDK reads the FIRST `__session*`
in declaration order — which can be from a different app, returning
`JWK_KID_MISMATCH` even when the canonical `__session` is valid.
Filtering forces the SDK to use the canonical no-suffix cookie, which
Clerk JS always maintains for the active app.

Full architectural write-up:
[`.claude/planning/0.7-architecture-and-bug-postmortem.md`](.claude/planning/0.7-architecture-and-bug-postmortem.md).

### 13d. Calling Clerk from inside a WS callback (v0.8 — the cross-loop hazard)

**Rule: inside a Dash 4.2 WebSocket-served callback body, read identity with
`current_user()` and call Clerk through the `*_sync` helpers — never `await`
the async client.**

Why: Dash 4.2 runs each async WS callback via `asyncio.run()` in a rotating
thread-pool worker (`dash/backends/ws.py::run_callback_in_executor`), so every
callback gets a *fresh* event loop that is closed when it returns. The
process-cached `httpx.AsyncClient` behind `get_async_client()` binds its
connection pool to the first loop that touches it, so reusing it from a later
worker raises **`RuntimeError: Event loop is closed`** (reproduced on
httpx 0.28.1 / httpcore 1.0.9 — roughly every other call under a multi-thread
executor). This model is unchanged from rc3 through **4.2.0 final**.

clerk-auth's *own* async client is safe because the package only ever awaits it
on the main uvicorn loop (the ASGI middleware and the WS connect/message
hooks). The hazard is **application code** awaiting it from a callback body.

```python
# ❌ WRONG — async client awaited on the WS worker's throwaway loop
async def save_role(n, user_id, role):
    await set_role_async(user_id, role)   # RuntimeError: Event loop is closed

# ✅ RIGHT — loop-free sync helpers (httpx.Client, never loop-bound)
from dash_clerk_auth import current_user, set_user_role_sync

def save_role(n, user_id, role):
    actor = current_user()                # registry → trustworthy server-side id
    if actor is None or not actor.has_role("admin"):
        raise PreventUpdate               # fail-closed authz re-check
    set_user_role_sync(user_id, role)     # sync Clerk call, safe on the worker
```

The v0.8 sync helpers — `verify_user_sync`, `get_user_by_id_sync`,
`list_users_sync`, `set_user_role_sync`, and the raw `get_sync_client()` —
mirror the async signatures, use a thread-safe TTL cache, and are safe from any
thread (WS callback workers, `jobs.py` daemons, APScheduler). If you must stay
async, wrap a sync call in `asyncio.to_thread(...)`. As a backstop, the async
helpers now also rebuild the cached client and retry once when they hit a
closed loop — but prefer the sync API; don't rely on the safety net.

**Identity vs. authorization in a WS callback:** use `clerk-auth-store` to
decide *what to render* (race-free on first paint); use `current_user()` for
*server-side authorization* (admin re-checks, per-user attribution) where
trusting client-supplied data is wrong. The registry makes `current_user()`
trustworthy inside the worker.

**Registry-resolution compatibility:** `current_user()` reads
`callback_context.websocket._renderer_id`. That accessor is the `websocket`
**property** in 4.2.0rc3 and 4.2.0 final (identical), but was a
`get_websocket()` **method** in rc1/rc2 — where the registry was silently inert
and `current_user()` returned `None` in every WS callback. v0.8 resolves both,
so the registry works on any 4.2.x; the recommended fix is to run 4.2.0 final.

### 13e. Scaling notes (v0.8)

- **Shared `session_secret` across processes.** The `__dca_identity` cookie is
  the only cross-process identity cache; it is HMAC-signed with
  `session_secret`. Every web process (and every container — web, workers)
  must use the **same** value from a stable shared env var, never a per-boot
  random. If it drifts, processes reject each other's cookies → constant
  slow-path Clerk JWKS roundtrips and "signed out then back in" flapping as a
  load balancer bounces requests between them.
- **The registry is thread-safe and per-process.** Writes (`attach`, main
  loop) and reads/touches (`lookup`, worker threads) are guarded by a
  `threading.Lock`; before v0.8 the eviction sweep could race a worker's
  `lookup` and raise `dictionary changed size during iteration` under load. A
  WS connection is pinned to one process, so cross-process consistency is never
  needed. Envelope: 24 h TTL, 4096 entries/process.

### 13f. Theming the Clerk components (v0.8.1 — DMC-variable matching)

The package injects a Clerk `appearance` object (in `@hooks.index()`) plus a
`<style>` block that targets Clerk's **stable** semantic classes (`cl-card`,
`cl-modalContent`, `cl-navbar`, `cl-profileSection`, `cl-formFieldInput`, … —
never the hashed `cl-internal-*`). The SignIn and UserProfile modals are styled
to match the active Mantine theme.

**Why it's done this way.** Clerk's `appearance` is evaluated **once** at
`Clerk.load()`. If you bake `theme === 'dark' ? darkColor : lightColor` into it,
those colours freeze at the page's load-time scheme, and a later DMC light↔dark
toggle (which only flips `data-mantine-color-scheme` on `<html>`) leaves Clerk's
text/background colours stale — the classic "dark text on a dark modal after I
switched themes" bug. The fix (v0.8.1): pass **Mantine's own scheme-aware CSS
variables** as the colour values instead of literals:

```js
// in the injected appearance — colours that follow the DMC theme automatically
variables: {
  colorBackground:    'var(--mantine-color-body, #FFFFFF)',
  colorText:          'var(--mantine-color-text, #1F2937)',
  colorTextSecondary: 'var(--mantine-color-dimmed, #6B7280)',
  colorInputBackground: 'var(--mantine-color-default, #FFFFFF)',
  colorPrimary:       'var(--mantine-primary-color-filled, #3B82F6)',
  // …
}
```

Because `MantineProvider` defines those variables on `:root` and redefines them
under `[data-mantine-color-scheme="dark"]`, Clerk re-resolves them on every
toggle with **no re-render** — and it reaches Clerk's hashed internal elements
that CSS can't target by class. The injected `<style>` adds matching
`html[data-mantine-color-scheme="light"]` and `…="dark"` override blocks for the
stable `cl-*` surfaces (solid backgrounds so nothing bleeds through) plus a
`::placeholder` rule.

**Consumer takeaways:**
- You get this for free — just wrap your app in `dmc.MantineProvider` (required
  anyway; see §9) and toggle the scheme however you like (`ColorSchemeToggle`,
  a `Switch` + clientside callback setting `data-mantine-color-scheme`, etc.).
- To restyle further, follow Clerk's BYOCSS guidance: target a stable `cl-*`
  class in your own `assets/*.css`, or pass `appearance.elements`. Your
  `assets/` CSS loads after the package's injected `<style>`, so a plain
  `.cl-formButtonPrimary { … }` rule (no `!important` needed for most props)
  wins. Use Mantine variables there too (`var(--mantine-color-*)`) to stay
  theme-reactive.
- The package's modal overrides use `!important` on stable classes; if you need
  to beat them, match the `html[data-mantine-color-scheme="…"] .cl-…` specificity
  or raise yours.

### 13g. Email enrichment (v0.9 — why `user.email` works at all)

A stock Clerk session JWT payload is just:

```json
{"azp": "...", "exp": 0, "iat": 0, "iss": "https://<app>.clerk.accounts.dev",
 "sid": "sess_...", "sts": "active", "sub": "user_...", "v": 2}
```

**No email, no name.** Pre-0.9, `ClerkUser.from_jwt_payload` therefore
produced `email=None` for every verified user — and because the verify
verdict is jti-cached and minted into `__dca_identity`, the email-less
identity persisted for the cookie's whole lifetime (7 days). Any
email-keyed authorization (`user.email == OWNER_EMAIL`) denied users that
Clerk had verified successfully, while logs showed a clean verify.

**v0.9 fix** (in `_clerk_client.py`): after a positive verify whose payload
lacks an email, the verify helpers fetch the user once via the users API
and remember `{email, first_name, last_name, image_url}` per `user_id`
for the process lifetime:

- `averify_request` enriches via `aget_user_by_id` (async, main loop);
- `verify_user_sync` enriches via `get_user_by_id_sync` (loop-free);
- the flask `/api/auth/session` route (which bypasses both helpers)
  calls `enrich_user_sync` explicitly;
- enrichment runs **before** the jti-cache put and before every
  `__dca_identity` mint, so the cost is one backend-API call **per user
  per process** — not per request, not per JWT rotation.

Semantics worth knowing:

- A user with no email at Clerk (phone-only signup) is remembered as
  email-less — no repeated fetching.
- A transient `users.get` failure is NOT remembered — the user comes
  through verified-but-email-less and the next slow-path verify retries.
- `dash_clerk_auth.enrich_user_sync(user)` / `await aenrich_user(user)`
  are public for host apps with their own verify paths.
- Alternative that makes enrichment a no-op: customise the instance's
  session token in the Clerk dashboard with
  `{"email": "{{user.primary_email_address}}"}`. The package never
  *requires* dashboard config to produce a usable identity, though.
- **Testing note:** the email-less payload shape above is the canonical
  fixture (`tests/test_v09_fixes.py`). An email-filled stub masks this
  entire bug class — it did, pre-0.9.

---

## 14. Related packages

- [`clerk-backend-api`](https://pypi.org/project/clerk-backend-api/) —
  official Clerk Python SDK; `dash-clerk-auth` uses it for server-side
  JWT verification.
- [`svix`](https://pypi.org/project/svix/) — Clerk webhooks are signed
  with Svix. Use it to verify webhook payloads.
- [`dash-mantine-components`](https://pypi.org/project/dash-mantine-components/)
  — recommended UI companion; the hook's liquid-glass styles key off
  `data-mantine-color-scheme`.