# dash_clerk_auth/__init__.py

"""
dash-clerk-auth — Clerk authentication plugin for Plotly Dash.

Liquid-glass-styled UI, Dash Hooks integration (Dash 3 & 4), protected-callback
decorators, optional Clerk Billing support.

v0.6 adds first-class support for Dash 4's ``backend="fastapi"`` (and Quart):
an ASGI middleware verifies Clerk sessions once per request and binds a
:class:`ClerkUser` to a :class:`contextvars.ContextVar`. Backend-neutral
helpers (:func:`current_user`, :func:`require_role_layout`, etc.) read from
that ContextVar on FastAPI and from ``flask.g``/``flask.session`` on Flask.
``backend="auto"`` (the default) detects which to use from ``app.server``.
"""

__version__ = "1.0.4"

import os
import time
import logging
import random
import string
import urllib.parse
import uuid
import json
import warnings
from functools import wraps
from datetime import timedelta

from dash import html, hooks, dcc, Input, Output, State, no_update, callback_context, ALL, clientside_callback

# --- Flask stack: soft-import so the package loads on non-Flask Dash backends ---
try:
    from flask import session, request, jsonify, redirect, g as flask_g, after_this_request
    from flask_session import Session
    from werkzeug.middleware.proxy_fix import ProxyFix
    _FLASK_AVAILABLE = True
except ImportError:
    session = None
    request = None
    jsonify = None
    redirect = None
    flask_g = None
    after_this_request = None
    Session = None
    ProxyFix = None
    _FLASK_AVAILABLE = False

# --- v0.6 backend-neutral surface ---
from ._user import ClerkUser  # noqa: E402
from ._backend import (  # noqa: E402
    current_user,
    callback_user,
    is_authenticated,
    detect_backend,
    set_request_user,
    reset_request_user,
)
from ._decorators import (  # noqa: E402
    require_auth_layout,
    require_role_layout,
    require_plan_layout,
    require_feature_layout,
    default_forbidden_layout,
)
from ._clerk_client import (  # noqa: E402
    get_async_client,
    get_sync_client,
    set_async_client_secret,
    averify_request,
    aget_user_by_id,
    alist_users_cached,
    verify_user_sync,
    get_user_by_id_sync,
    list_users_sync,
    set_user_role_sync,
    enrich_user_sync,
    aenrich_user,
)
from ._ws import ws_auth_registered  # noqa: E402

# --- Clerk SDK: try the modern paths (5.x → 4.x → legacy 1-3.x) ---
try:
    from clerk_backend_api import Clerk
    import httpx
except ImportError as e:
    raise ImportError(
        "clerk-backend-api>=4.0.0 and httpx>=0.28.0 are required for dash-clerk-auth. "
        "Install them with: pip install 'clerk-backend-api>=4.0.0' 'httpx>=0.28.0'"
    ) from e

try:
    # clerk-backend-api >= 5.0 — top-level export
    from clerk_backend_api import AuthenticateRequestOptions
except ImportError:
    try:
        # clerk-backend-api 4.x — moved under security.authenticaterequest
        from clerk_backend_api.security.authenticaterequest import AuthenticateRequestOptions
    except ImportError:
        try:
            # clerk-backend-api 4.x alternate path some minor versions expose
            from clerk_backend_api.security.types import AuthenticateRequestOptions
        except ImportError:
            try:
                # clerk-backend-api <= 3.x legacy path
                from clerk_backend_api.jwks_helpers import AuthenticateRequestOptions  # type: ignore
            except ImportError as _exc:
                raise ImportError(
                    "clerk-backend-api>=4.0 is required for dash-clerk-auth. "
                    "Install it with: pip install 'clerk-backend-api>=4.0'"
                ) from _exc

# Configure logging
logger = logging.getLogger(__name__)

# Global variables to store configuration
_clerk_config = {
    'initialized': False,
    'billing_enabled': False
}

# LIQUID GLASS DESIGN TOKENS - Theme-aware
LIQUID_GLASS_TOKENS = {
    'light': {
        'glass_bg': 'rgba(255, 255, 255, 0.75)',
        'glass_bg_secondary': 'rgba(255, 255, 255, 0.60)',
        'glass_bg_hover': 'rgba(255, 255, 255, 0.85)',
        'border': 'rgba(0, 0, 0, 0.08)',
        'border_hover': 'rgba(0, 0, 0, 0.12)',
        'shadow_sm': '0 2px 8px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.06)',
        'shadow_md': '0 4px 16px rgba(0, 0, 0, 0.06), 0 2px 4px rgba(0, 0, 0, 0.08)',
        'shadow_lg': '0 12px 40px rgba(0, 0, 0, 0.08), 0 4px 12px rgba(0, 0, 0, 0.10)',
        'text_primary': '#2c3e50',
        'text_secondary': '#6c757d',
        'hover_bg': 'rgba(0, 0, 0, 0.04)',
        'danger_bg': 'rgba(239, 68, 68, 0.1)',
        'danger_text': '#ef4444',
    },
    'dark': {
        'glass_bg': 'rgba(30, 30, 35, 0.75)',
        'glass_bg_secondary': 'rgba(40, 40, 45, 0.60)',
        'glass_bg_hover': 'rgba(45, 45, 50, 0.85)',
        'border': 'rgba(255, 255, 255, 0.10)',
        'border_hover': 'rgba(255, 255, 255, 0.16)',
        'shadow_sm': '0 2px 8px rgba(0, 0, 0, 0.20), 0 1px 2px rgba(0, 0, 0, 0.30)',
        'shadow_md': '0 4px 16px rgba(0, 0, 0, 0.30), 0 2px 4px rgba(0, 0, 0, 0.40)',
        'shadow_lg': '0 12px 40px rgba(0, 0, 0, 0.40), 0 4px 12px rgba(0, 0, 0, 0.50)',
        'text_primary': '#e9ecef',
        'text_secondary': '#adb5bd',
        'hover_bg': 'rgba(255, 255, 255, 0.06)',
        'danger_bg': 'rgba(239, 68, 68, 0.15)',
        'danger_text': '#ff6b6b',
    }
}


def _flask_to_httpx_request(flask_request, token=None):
    """Convert a Flask request to an httpx Request for Clerk authentication."""
    headers = dict(flask_request.headers)
    if token:
        headers['Authorization'] = f'Bearer {token}'

    return httpx.Request(
        method=flask_request.method,
        url=str(flask_request.url),
        headers=headers,
    )


def register_clerk_auth(
        clerk_secret_key=None,
        clerk_publishable_key=None,
        clerk_sign_in_url=None,
        clerk_frontend_api=None,
        session_secret=None,
        flask_secret_key=None,
        session_lifetime_days=7,
        debug=False,
        show_debug_panel=None,
        enable_proxy_fix=True,
        enable_billing=False,
        headless=False,
        is_satellite=False,
        satellite_domain=None,
        sign_in_url=None,
        sign_up_url=None,
        allowed_redirect_origins=None,
        backend="auto",
        on_unverified="forbidden",
        verify_timeout=5.0,
        authorized_parties=None,
        websocket_auth=True,
        satellite_sign_in_redirect=None,
        app=None,
):
    """Register Clerk authentication hooks.

    Common (single-domain) setup::

        register_clerk_auth(
            clerk_secret_key=os.environ["CLERK_SECRET_KEY"],
            clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],
            clerk_sign_in_url="https://your-app.clerk.accounts.dev/sign-in",
        )

    Multi-domain satellite setup (see ``/multi-domain`` page for full example)::

        # On the PRIMARY (auth hub) — hosts sign-in, whitelists satellite origins:
        register_clerk_auth(
            clerk_sign_in_url="https://hub.example.com/sign-in",
            clerk_frontend_api="https://your-app.clerk.accounts.dev",
            allowed_redirect_origins=[
                "https://store.example.com", "https://me.example.com"
            ],
        )

        # On each SATELLITE — redirects sign-in to the primary:
        register_clerk_auth(
            clerk_sign_in_url="https://hub.example.com/sign-in",
            sign_up_url="https://hub.example.com/sign-up",
            clerk_frontend_api="https://your-app.clerk.accounts.dev",
            is_satellite=True,
            satellite_domain="store.example.com",   # host only, no protocol
        )

    :param headless: When True, the hook does NOT inject its default
        top-right avatar / dropdown UI — useful when the host app renders
        its own user controls (the ``clerk-auth-store`` and underlying
        components are still injected).
    :param is_satellite: Pass ``True`` on every satellite domain so
        ``Clerk.load()`` is called with ``isSatellite: true``.
    :param satellite_domain: This satellite's host (e.g. ``"store.example.com"``).
    :param sign_up_url: Absolute URL to the primary's sign-up page. Used on
        satellites when ``is_satellite=True``.
    :param satellite_sign_in_redirect: v0.9.2 — absolute URL of a page on the
        PRIMARY application (e.g. ``"https://hub.example.com/onboarding"``).
        Only meaningful with ``is_satellite=True``: the Sign In button then
        NAVIGATES to ``<url>?returnTo=<current page>`` instead of opening the
        Clerk modal, which ClerkJS forbids on satellite domains ("This
        operation is not allowed on a satellite domain"). Unset, satellites
        fall back to ``Clerk.redirectToSignIn()`` (the Clerk-native hop to
        ``sign_in_url``). Env fallback: ``CLERK_SATELLITE_SIGN_IN_REDIRECT``.
        A separate parameter from ``sign_in_url`` on purpose — that one also
        feeds ``Clerk.load()`` and server-side redirects.
    :param clerk_frontend_api: The Clerk-hosted Frontend API origin
        (``https://your-app.clerk.accounts.dev``). Required in satellite
        mode because ``clerk_sign_in_url`` now points at *your* primary
        domain, so the hook can't infer where to load ``clerk.browser.js``
        from.
    :param allowed_redirect_origins: On the primary, the list of satellite
        origins Clerk is allowed to redirect back to after sign-in.
    :param sign_in_url: Alias for ``clerk_sign_in_url``, matches Clerk JS
        naming.
    :param session_secret: Secret for the cookie-based session (Flask
        ``SECRET_KEY`` / Starlette ``SessionMiddleware`` secret_key). Renamed
        from ``flask_secret_key`` in v0.6 because the same value drives both
        backends. ``flask_secret_key`` keeps working as a deprecated alias.
    :param backend: ``"auto"`` (default), ``"flask"``, ``"fastapi"`` or
        ``"quart"``. ``"auto"`` detects from ``app.server`` when ``app=`` is
        passed (or at ``configure_app(app)`` time otherwise).
    :param on_unverified: layout-decorator default policy when Clerk can't
        verify the request. ``"forbidden"`` (fail closed, default),
        ``"allow"`` (fail open), ``"passthrough"`` (legacy v0.5 — render
        both the protected layout and the placeholder).
    :param verify_timeout: per-request Clerk verification timeout (s).
    :param authorized_parties: optional Clerk ``authorized_parties``
        whitelist passed to ``authenticate_request``.
    :param websocket_auth: v0.9 — automatically register the Dash 4.2+
        WebSocket auth hooks when configuring an ASGI backend (no-op with
        an info log on Dash versions without the hooks). Without them,
        ``current_user()`` is ``None`` inside every WebSocket-served
        callback, because Dash 4.2 dispatches those through a thread pool
        that no HTTP middleware, cookie or ContextVar reaches. Pass
        ``False`` to opt out (you can still call
        :func:`register_websocket_auth` yourself, e.g. to set
        ``on_anonymous="close"``).
    """
    global _clerk_config

    if _clerk_config.get('initialized'):
        logger.warning("Clerk auth already initialized, skipping re-initialization")
        return

    # Deprecated alias: flask_secret_key → session_secret
    if flask_secret_key is not None and session_secret is None:
        warnings.warn(
            "register_clerk_auth(flask_secret_key=...) is deprecated; use "
            "session_secret= (the same secret drives both Flask and FastAPI "
            "session cookies). flask_secret_key= keeps working through v0.x.",
            DeprecationWarning,
            stacklevel=2,
        )
        session_secret = flask_secret_key

    # Configuration
    _clerk_config['debug'] = debug or os.getenv('DEBUG', '').lower() in ('true', '1', 'yes')
    _clerk_config['show_debug_panel'] = show_debug_panel if show_debug_panel is not None else _clerk_config['debug']
    _clerk_config['clerk_secret_key'] = clerk_secret_key or os.environ.get('CLERK_SECRET_KEY')
    _clerk_config['clerk_publishable_key'] = clerk_publishable_key or os.environ.get('CLERK_PUBLISHABLE_KEY')
    # sign_in_url is a Clerk-JS-friendly alias for clerk_sign_in_url — prefer it if both are given.
    _clerk_config['clerk_sign_in_url'] = sign_in_url or clerk_sign_in_url or os.environ.get('CLERK_SIGN_IN_URL')
    _clerk_config['session_secret'] = (
        session_secret
        or os.environ.get('SESSION_SECRET')
        or os.environ.get('FLASK_SECRET_KEY', 'default-dev-secret-key')
    )
    # Keep the v0.5 key for any internal reads still using it.
    _clerk_config['flask_secret_key'] = _clerk_config['session_secret']
    _clerk_config['session_lifetime_days'] = session_lifetime_days
    _clerk_config['enable_proxy_fix'] = enable_proxy_fix
    _clerk_config['billing_enabled'] = enable_billing
    _clerk_config['headless'] = headless
    _clerk_config['is_satellite'] = is_satellite
    _clerk_config['satellite_domain'] = satellite_domain or ''
    _clerk_config['sign_up_url'] = sign_up_url or os.environ.get('CLERK_SIGN_UP_URL', '')
    _satellite_redirect = (
        satellite_sign_in_redirect
        or os.environ.get('CLERK_SATELLITE_SIGN_IN_REDIRECT', '')
    )
    if _satellite_redirect and not _satellite_redirect.startswith(('http://', 'https://')):
        # v1.0.3: DISCARD it rather than use it. This value is the href of a
        # satellite's Sign In button, and a relative one navigates inside the
        # satellite — which is the one place sign-in cannot happen — for a
        # guaranteed 404. Unset is strictly better: the button falls through
        # to Clerk's Account Portal, which works. A misconfiguration should
        # cost a warning, not the sign-in path. Booleans from a careless
        # env var (`=true`) land here too.
        logger.error(
            "satellite_sign_in_redirect=%r is not an absolute http(s) URL and "
            "has been IGNORED — a relative value navigates inside the "
            "satellite, where sign-in cannot happen, and 404s. Sign In will "
            "fall back to Clerk's Account Portal. Set it to the primary's "
            "full sign-in URL (https://...) to restore the direct redirect.",
            _satellite_redirect,
        )
        _satellite_redirect = ''
    _clerk_config['satellite_sign_in_redirect'] = _satellite_redirect
    _clerk_config['clerk_frontend_api'] = clerk_frontend_api or os.environ.get('CLERK_FRONTEND_API', '')
    _clerk_config['allowed_redirect_origins'] = allowed_redirect_origins or []
    _clerk_config['backend'] = backend
    _clerk_config['on_unverified'] = on_unverified
    _clerk_config['verify_timeout'] = float(verify_timeout)
    _clerk_config['authorized_parties'] = list(authorized_parties or [])
    _clerk_config['websocket_auth'] = bool(websocket_auth)

    # Validation
    if not _clerk_config['clerk_secret_key']:
        raise ValueError("clerk_secret_key is required")
    if not _clerk_config['clerk_publishable_key']:
        raise ValueError("clerk_publishable_key is required")
    if not _clerk_config['clerk_sign_in_url']:
        raise ValueError("clerk_sign_in_url is required")
    if _clerk_config['is_satellite'] and not _clerk_config['satellite_domain']:
        raise ValueError("satellite_domain is required when is_satellite=True")

    # Initialize Clerk client (sync — used by the v0.5 Flask path).
    try:
        _clerk_config['clerk_client'] = Clerk(bearer_auth=_clerk_config['clerk_secret_key'])
        logger.info("Clerk client initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize Clerk client: {e}")
        raise

    # Wire the async client to the same secret. ``get_async_client()`` lazy-
    # constructs on first call from the secret seeded here.
    try:
        set_async_client_secret(_clerk_config['clerk_secret_key'])
    except Exception as exc:  # pragma: no cover — never fatal
        logger.debug("set_async_client_secret() noop'd: %s", exc)

    # Clerk JS source origin: prefer explicit clerk_frontend_api (required in
    # satellite mode, where clerk_sign_in_url points at the primary app, not
    # Clerk). Fall back to deriving from the sign-in URL for backwards compat.
    frontend_api = _clerk_config['clerk_frontend_api']
    if frontend_api:
        clerk_js_origin = frontend_api.rstrip('/')
    else:
        clerk_js_origin = _clerk_config['clerk_sign_in_url'].split('/sign-in')[0]
        if _clerk_config['is_satellite']:
            logger.warning(
                "is_satellite=True without clerk_frontend_api — deriving Clerk JS "
                "URL from clerk_sign_in_url=%s. This will only work if the sign-in "
                "URL lives on the Clerk-hosted domain. Set clerk_frontend_api for "
                "reliable behaviour.",
                _clerk_config['clerk_sign_in_url'],
            )

    _clerk_config['clerk_js_origin'] = clerk_js_origin
    # On satellites the domain must ride on the script tag itself: with the
    # script-tag installation, ClerkJS v5 auto-instantiates from the tag's
    # data attributes, and its satellite check reads the INSTANCE domain — a
    # domain passed only to Clerk.load() is ignored, load() throws
    # "ClerkJS: Missing domain and proxyUrl", and the user button never
    # mounts (the avatar renders but is dead) while server-side session
    # verification keeps working. Observed on a production satellite
    # deployment, 2026-07-31.
    domain_attr = (
        f'\n            data-clerk-domain="{_clerk_config["satellite_domain"]}"'
        if _clerk_config['is_satellite'] and _clerk_config['satellite_domain']
        else ''
    )
    _clerk_config['clerk_script'] = f'''
        <script
            async
            crossorigin="anonymous"{domain_attr}
            data-clerk-publishable-key="{_clerk_config['clerk_publishable_key']}"
            src="{clerk_js_origin}/npm/@clerk/clerk-js@5/dist/clerk.browser.js"
            type="text/javascript">
        </script>'''

    _clerk_config['initialized'] = True
    role = 'satellite' if is_satellite else 'primary'
    logger.info(
        "Clerk auth registered (role=%s, billing=%s, headless=%s)",
        role, 'on' if enable_billing else 'off', headless,
    )

    if app is not None:
        configure_app(app)


def _current_auth_snapshot():
    """The verified viewer for THIS request as a plain dict, or ``None``.

    Same shape the ``clerk-auth-store`` is pre-hydrated with. Never raises:
    outside a request scope (a layout or menu built at import time) there is
    simply no viewer, and every caller degrades to the anonymous rendering
    that the client script then corrects.
    """
    try:
        viewer = current_user()
    except Exception:
        return None
    if viewer is None:
        return None
    try:
        return viewer.to_session_dict()
    except Exception:
        return None


def _avatar_placeholder(background: str, glyph: str) -> str:
    """The signed-out avatar, as a self-contained CSS ``background-image``.

    v1.0.3: this used to be a DiceBear API URL — a third-party image service
    on the critical path of the one control that tells a user whether they
    are signed in. When that service rate-limited or moved, the background
    silently failed to load and the avatar rendered as a blank white circle.
    An authentication widget must not have a runtime dependency on someone
    else's uptime, so the default is drawn here instead: no network, no
    third party, and nothing that can fail to load.

    Two variants exist rather than one ``currentColor`` glyph because an SVG
    referenced from ``background-image`` is an isolated document — it does
    not inherit the page's colour. They are exposed as the
    ``--clerk-avatar-default`` custom property and swapped with the rest of
    the theme tokens.
    """
    svg = (
        "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 44 44'>"
        f"<circle cx='22' cy='22' r='22' fill='{background}'/>"
        f"<circle cx='22' cy='17.5' r='7' fill='{glyph}'/>"
        "<path d='M7.5 41.5c1.6-7.6 7.4-11.5 14.5-11.5s12.9 3.9 14.5 11.5z' "
        f"fill='{glyph}'/>"
        "</svg>"
    )
    # `safe` keeps the markup legible in the emitted CSS; what MUST be
    # encoded is `#` (it would start a fragment) and the angle brackets.
    #
    # Hoisted out of the f-string deliberately: an f-string expression may not
    # contain a backslash before Python 3.12 (PEP 701 lifted that), and this
    # package supports 3.10. Inlining the quote() call needs an escaped quote
    # inside the expression and is a hard SyntaxError on 3.10/3.11 — which is
    # an IMPORT failure, not a test failure. tests/test_python_floor.py pins it.
    encoded = urllib.parse.quote(svg, safe="/:='? ")
    return f'url("data:image/svg+xml,{encoded}")'


AVATAR_DEFAULT_LIGHT = _avatar_placeholder("#E9ECEF", "#ADB5BD")
AVATAR_DEFAULT_DARK = _avatar_placeholder("#343A40", "#6C757D")


@hooks.index()
def add_clerk_script(index_string):
    """Inject Clerk script and liquid glass styles into HTML"""
    if not _clerk_config.get('initialized'):
        return index_string

    clerk_script = _clerk_config.get('clerk_script', '')
    billing_enabled = 'true' if _clerk_config.get('billing_enabled') else 'false'

    # Enhanced initialization with theme detection
    init_script = f'''
        <script>
            window.clerkBillingEnabled = {billing_enabled};

            // Page-JS surface for host apps (e.g. custom sign-in buttons).
            // buildSatelliteRedirect() returns the primary-app URL a satellite
            // must NAVIGATE to for sign-in (Clerk forbids the modal there),
            // with the current page carried in ?returnTo=; null when not a
            // satellite or no satellite_sign_in_redirect is configured.
            window.dashClerkAuth = Object.assign(window.dashClerkAuth || {{}}, {{
                isSatellite: {str(_clerk_config.get('is_satellite', False)).lower()},
                signInUrl: {json.dumps(_clerk_config.get('clerk_sign_in_url', ''))},
                signUpUrl: {json.dumps(_clerk_config.get('sign_up_url', ''))},
                satelliteSignInRedirect: {json.dumps(_clerk_config.get('satellite_sign_in_redirect', ''))},
                buildSatelliteRedirect: function (opts) {{
                    var base = this.satelliteSignInRedirect;
                    if (!this.isSatellite || !base) return null;
                    var url = base + (base.indexOf('?') === -1 ? '?' : '&')
                            + 'returnTo=' + encodeURIComponent(window.location.href);
                    if (opts && opts.mode === 'signup') url += '&mode=signup';
                    return url;
                }}
            }});

            window.waitForClerk = function() {{
                return new Promise((resolve) => {{
                    const checkClerk = () => {{
                        if (window.Clerk) {{
                            resolve(window.Clerk);
                        }} else {{
                            setTimeout(checkClerk, 50);
                        }}
                    }};
                    checkClerk();
                }});
            }};

            // Theme detection utility
            window.getTheme = function() {{
                const scheme = document.documentElement.getAttribute('data-mantine-color-scheme');
                return scheme === 'dark' ? 'dark' : 'light';
            }};

            // Apply theme-aware styles
            window.updateClerkTheme = function() {{
                const theme = window.getTheme();
                console.log('[Clerk Glass] Theme changed to:', theme);

                // Update CSS custom properties. Two backdrop tiers:
                //   --clerk-glass-bg* drives small overlays (dropdown, debug
                //     panel) where see-through is the desired aesthetic.
                //   --clerk-modal-bg* drives the Clerk profile modal and its
                //     nested sections, where legibility matters more than the
                //     glass effect — so these are significantly more opaque.
                const root = document.documentElement;
                const tokens = theme === 'dark' ? {{
                    '--clerk-glass-bg': 'rgba(30, 30, 35, 0.50)',
                    '--clerk-glass-bg-secondary': 'rgba(40, 40, 45, 0.40)',
                    '--clerk-glass-bg-hover': 'rgba(45, 45, 50, 0.70)',
                    '--clerk-modal-bg': 'rgba(20, 20, 25, 0.92)',
                    '--clerk-modal-bg-secondary': 'rgba(30, 30, 35, 0.85)',
                    '--clerk-modal-bg-hover': 'rgba(40, 40, 45, 0.92)',
                    '--clerk-modal-backdrop': 'rgba(0, 0, 0, 0.55)',
                    '--clerk-modal-border': 'rgba(255, 255, 255, 0.14)',
                    '--clerk-modal-specular': 'rgba(255, 255, 255, 0.18)',
                    '--clerk-border': 'rgba(255, 255, 255, 0.10)',
                    '--clerk-shadow-md': '0 4px 16px rgba(0, 0, 0, 0.30), 0 2px 4px rgba(0, 0, 0, 0.40)',
                    '--clerk-text': '#e9ecef',
                    '--clerk-avatar-default': {json.dumps(AVATAR_DEFAULT_DARK)},
                }} : {{
                    '--clerk-glass-bg': 'rgba(255, 255, 255, 0.50)',
                    '--clerk-glass-bg-secondary': 'rgba(255, 255, 255, 0.40)',
                    '--clerk-glass-bg-hover': 'rgba(255, 255, 255, 0.70)',
                    // Modal: much more opaque in light mode so page content
                    // behind the modal doesn't bleed through and wash out the
                    // Clerk-rendered text.
                    '--clerk-modal-bg': 'rgba(255, 255, 255, 0.96)',
                    '--clerk-modal-bg-secondary': 'rgba(248, 250, 252, 0.90)',
                    '--clerk-modal-bg-hover': 'rgba(255, 255, 255, 1.00)',
                    '--clerk-modal-backdrop': 'rgba(15, 23, 42, 0.35)',
                    '--clerk-modal-border': 'rgba(15, 23, 42, 0.10)',
                    '--clerk-modal-specular': 'rgba(255, 255, 255, 0.9)',
                    '--clerk-border': 'rgba(0, 0, 0, 0.08)',
                    '--clerk-shadow-md': '0 4px 16px rgba(0, 0, 0, 0.06), 0 2px 4px rgba(0, 0, 0, 0.08)',
                    '--clerk-text': '#2c3e50',
                    '--clerk-avatar-default': {json.dumps(AVATAR_DEFAULT_LIGHT)},
                }};

                Object.entries(tokens).forEach(([key, value]) => {{
                    root.style.setProperty(key, value);
                }});
            }};

            // Watch for theme changes
            const observer = new MutationObserver((mutations) => {{
                mutations.forEach((mutation) => {{
                    if (mutation.attributeName === 'data-mantine-color-scheme') {{
                        window.updateClerkTheme();
                    }}
                }});
            }});

            document.addEventListener('DOMContentLoaded', async function() {{
                console.log('[Clerk Glass] 🌊 Initializing liquid glass authentication...');

                // Set initial theme
                window.updateClerkTheme();

                // Debug: Check if elements exist
                setTimeout(() => {{
                    const avatar = document.getElementById('clerk-user-avatar');
                    const dropdown = document.getElementById('clerk-menu-dropdown');
                    const container = document.getElementById('clerk-auth-menu-container');

                    console.log('[Clerk Glass] 🔍 Element check:', {{
                        avatar: avatar ? '✅ EXISTS' : '❌ MISSING',
                        dropdown: dropdown ? '✅ EXISTS' : '❌ MISSING',
                        container: container ? '✅ EXISTS' : '❌ MISSING'
                    }});

                    if (avatar) {{
                        const styles = window.getComputedStyle(avatar);
                        console.log('[Clerk Glass] 🎨 Avatar styles:', {{
                            display: styles.display,
                            visibility: styles.visibility,
                            opacity: styles.opacity,
                            width: styles.width,
                            height: styles.height,
                            zIndex: styles.zIndex
                        }});
                    }}

                    if (container) {{
                        const styles = window.getComputedStyle(container);
                        console.log('[Clerk Glass] 📦 Container styles:', {{
                            position: styles.position,
                            top: styles.top,
                            right: styles.right,
                            display: styles.display,
                            zIndex: styles.zIndex
                        }});
                    }}
                }}, 500);

                // Observe theme changes
                observer.observe(document.documentElement, {{
                    attributes: true,
                    attributeFilter: ['data-mantine-color-scheme']
                }});

                try {{
                    await window.waitForClerk();
                    const theme = window.getTheme();

                    const clerkLoadOptions = {{
                        appearance: {{
                            layout: {{
                                socialButtonsPlacement: 'top',
                                socialButtonsVariant: 'iconButton',
                                shimmer: true
                            }},
                            // Colours come from Mantine's OWN scheme-aware CSS
                            // variables (defined on :root by MantineProvider and
                            // flipped by data-mantine-color-scheme). Passing
                            // var(...) here — instead of a theme-baked literal —
                            // is what makes the modals re-theme INSTANTLY on a
                            // DMC light/dark toggle and match the rest of the app,
                            // including Clerk's hashed internal elements. The
                            // literal after each comma is a light-mode fallback
                            // for the rare case the DMC vars aren't present.
                            variables: {{
                                colorPrimary: 'var(--mantine-primary-color-filled, #3B82F6)',
                                colorDanger: 'var(--mantine-color-error, #EF4444)',
                                colorSuccess: 'var(--mantine-color-green-filled, #10B981)',
                                colorWarning: 'var(--mantine-color-yellow-filled, #F59E0B)',
                                colorNeutral: 'var(--mantine-color-text, #000000)',
                                colorBackground: 'var(--mantine-color-body, #FFFFFF)',
                                colorInputBackground: 'var(--mantine-color-default, #FFFFFF)',
                                colorInputText: 'var(--mantine-color-text, #1F2937)',
                                colorText: 'var(--mantine-color-text, #1F2937)',
                                colorTextSecondary: 'var(--mantine-color-dimmed, #6B7280)',
                                borderRadius: 'var(--mantine-radius-md, 12px)',
                                fontFamily: 'var(--mantine-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif)',
                            }},
                            elements: {{
                                card: {{
                                    background: 'var(--mantine-color-body, #FFFFFF)',
                                    backdropFilter: 'blur(24px) saturate(200%)',
                                    WebkitBackdropFilter: 'blur(24px) saturate(200%)',
                                    border: '1px solid var(--mantine-color-default-border, rgba(0,0,0,0.08))',
                                    borderRadius: '20px',
                                    boxShadow: theme === 'dark' 
                                        ? '0 12px 40px rgba(0, 0, 0, 0.40), 0 4px 12px rgba(0, 0, 0, 0.50), 0 0 0 1px rgba(255, 255, 255, 0.05) inset'
                                        : '0 12px 40px rgba(0, 0, 0, 0.08), 0 4px 12px rgba(0, 0, 0, 0.10)',
                                }},
                                headerTitle: {{
                                    color: 'var(--mantine-color-text, #1F2937)',
                                    fontWeight: '600'
                                }},
                                headerSubtitle: {{
                                    color: 'var(--mantine-color-dimmed, #6B7280)',
                                }},
                                formFieldLabel: {{
                                    color: 'var(--mantine-color-text, #1F2937)',
                                    fontWeight: '500',
                                }},
                                formFieldInput: {{
                                    background: 'var(--mantine-color-default, #FFFFFF)',
                                    border: '1px solid var(--mantine-color-default-border, rgba(0,0,0,0.12))',
                                    borderRadius: '10px',
                                    color: 'var(--mantine-color-text, #1F2937)',
                                    fontSize: '14px',
                                    padding: '12px 14px',
                                    transition: 'all 0.2s ease',
                                    '&::placeholder': {{
                                        color: 'var(--mantine-color-placeholder, #868E96)',
                                    }},
                                    '&:focus': {{
                                        background: theme === 'dark' ? 'rgba(255, 255, 255, 0.16)' : 'rgba(0, 0, 0, 0.08)',
                                        border: theme === 'dark' ? '1.5px solid rgba(255, 255, 255, 0.30)' : '1px solid #3B82F6',
                                        boxShadow: theme === 'dark' 
                                            ? '0 0 0 3px rgba(255, 255, 255, 0.10)'
                                            : '0 0 0 3px rgba(59, 130, 246, 0.1)',
                                    }}
                                }},
                                formButtonPrimary: {{
                                    background: '#3B82F6',
                                    border: '1px solid #3B82F6',
                                    color: '#FFFFFF',
                                    boxShadow: '0 4px 12px rgba(59, 130, 246, 0.25)',
                                    fontWeight: '600',
                                    padding: '12px 24px',
                                    borderRadius: '10px',
                                    transition: 'all 0.2s ease',
                                    '&:hover': {{
                                        background: '#2563EB',
                                        transform: 'translateY(-1px)',
                                        boxShadow: '0 6px 16px rgba(59, 130, 246, 0.35)',
                                    }},
                                    '&:active': {{
                                        transform: 'translateY(0)',
                                    }}
                                }},
                                socialButtonsIconButton: {{
                                    background: 'var(--mantine-color-default, rgba(0,0,0,0.04))',
                                    backdropFilter: 'blur(12px)',
                                    WebkitBackdropFilter: 'blur(12px)',
                                    border: '1px solid var(--mantine-color-default-border, rgba(0,0,0,0.08))',
                                    borderRadius: '10px',
                                    padding: '12px',
                                    transition: 'all 0.2s ease',
                                    '&:hover': {{
                                        background: 'var(--mantine-color-default-hover, rgba(0,0,0,0.08))',
                                        borderColor: theme === 'dark' ? 'rgba(255, 255, 255, 0.22)' : 'rgba(0, 0, 0, 0.12)',
                                        transform: 'translateY(-2px)',
                                    }}
                                }},
                                providerIcon: {{
                                    background: 'transparent',
                                    border: 'none',
                                    padding: '0',
                                }},
                                footer: {{
                                    background: 'transparent',
                                    backdropFilter: 'blur(12px)',
                                    WebkitBackdropFilter: 'blur(12px)',
                                    borderTop: '1px solid var(--mantine-color-default-border, rgba(0,0,0,0.08))',
                                    padding: '16px 24px',
                                    borderRadius: '0 0 20px 20px',
                                }},
                                dividerText: {{
                                    color: 'var(--mantine-color-dimmed, #6B7280)',
                                }},
                                dividerLine: {{
                                    background: 'var(--mantine-color-default-hover, rgba(0,0,0,0.08))',
                                }},
                                modalCloseButton: {{
                                    background: 'var(--mantine-color-default, rgba(0,0,0,0.04))',
                                    border: '1px solid var(--mantine-color-default-border, rgba(0,0,0,0.08))',
                                    color: 'var(--mantine-color-text, #1F2937)',
                                    borderRadius: '8px',
                                    '&:hover': {{
                                        background: theme === 'dark' ? 'rgba(255, 255, 255, 0.14)' : 'rgba(0, 0, 0, 0.08)',
                                        borderColor: theme === 'dark' ? 'rgba(255, 255, 255, 0.18)' : 'rgba(0, 0, 0, 0.12)',
                                    }}
                                }},
                                formFieldInputShowPasswordButton: {{
                                    color: 'var(--mantine-color-dimmed, #6B7280)',
                                    '&:hover': {{
                                        color: 'var(--mantine-color-text, #1F2937)',
                                    }}
                                }},
                                userButtonPopoverCard: {{
                                    background: 'var(--mantine-color-body, #FFFFFF)',
                                    backdropFilter: 'blur(24px) saturate(200%)',
                                    WebkitBackdropFilter: 'blur(24px) saturate(200%)',
                                    border: '1px solid var(--mantine-color-default-border, rgba(0,0,0,0.08))',
                                }},
                                userButtonPopoverActionButton: {{
                                    color: 'var(--mantine-color-text, #1F2937)',
                                    '&:hover': {{
                                        background: 'var(--mantine-color-default, rgba(0,0,0,0.04))',
                                    }}
                                }},
                                menuItem: {{
                                    color: 'var(--mantine-color-text, #1F2937)',
                                    '&:hover': {{
                                        background: 'var(--mantine-color-default, rgba(0,0,0,0.04))',
                                    }}
                                }},
                                profilePage: {{
                                    background: 'var(--mantine-color-body, #FFFFFF)',
                                }},
                                badge: {{
                                    background: 'var(--mantine-primary-color-light, rgba(59, 130, 246, 0.1))',
                                    color: 'var(--mantine-primary-color-light-color, #3B82F6)',
                                    border: '1px solid var(--mantine-color-default-border, rgba(59, 130, 246, 0.2))',
                                }},
                            }}
                        }}
                    }};

                    // --- Satellite domain wiring ---------------------------
                    // On satellites, Clerk needs to know (a) it's a satellite,
                    // (b) this domain's host, and (c) where the primary hosts
                    // sign-in / sign-up so it can redirect there.
                    const isSatellite = {str(_clerk_config.get('is_satellite', False)).lower()};
                    if (isSatellite) {{
                        clerkLoadOptions.isSatellite = true;
                        clerkLoadOptions.domain = {json.dumps(_clerk_config.get('satellite_domain', ''))};
                        clerkLoadOptions.signInUrl = {json.dumps(_clerk_config.get('clerk_sign_in_url', ''))};
                        const _signUp = {json.dumps(_clerk_config.get('sign_up_url', ''))};
                        if (_signUp) clerkLoadOptions.signUpUrl = _signUp;
                    }}

                    // On the primary, whitelist satellite origins so Clerk
                    // accepts redirects back to them after sign-in.
                    const allowedOrigins = {json.dumps(_clerk_config.get('allowed_redirect_origins', []))};
                    if (!isSatellite && allowedOrigins.length > 0) {{
                        clerkLoadOptions.allowedRedirectOrigins = allowedOrigins;
                    }}

                    await window.Clerk.load(clerkLoadOptions);
                    console.log('[Clerk] Ready', isSatellite ? '(satellite)' : '(primary)', 'theme:', theme);

                    const updateAuthState = () => {{
                        const user = window.Clerk.user;
                        const session = window.Clerk.session;

                        const authData = {{
                            user_id: user?.id || null,
                            email: user?.primaryEmailAddress?.emailAddress || null,
                            first_name: user?.firstName || null,
                            last_name: user?.lastName || null,
                            image_url: user?.imageUrl || null,
                            session_id: session?.id || null
                        }};

                        if (window.clerkBillingEnabled) {{
                            authData.plan = user?.publicMetadata?.plan || 'free';
                            authData.features = user?.publicMetadata?.features || [];
                        }}

                        console.log('[Clerk] Session changed:', authData);

                        // Signed-in -> signed-out without going through this
                        // page's own button: another tab, or another host on
                        // the same Clerk instance. The listener already sees
                        // it; before 1.0.3 it just never told the server, so
                        // every sibling satellite kept a local identity ghost
                        // until the cookie expired.
                        const previous = window.dashClerkAuth.authState;
                        if (previous && previous.user_id && !authData.user_id) {{
                            console.log('[Clerk] session ended elsewhere — revoking locally');
                            revokeServerSession();
                        }} else if (!authData.user_id && serverRenderedSignedIn
                                   && !reconciledOnLoad) {{
                            // v1.0.4 — the ghost this page was rendered from.
                            //
                            // 1.0.3 only caught a live transition, which
                            // requires THIS tab to have seen the signed-in
                            // state first. A browser that signed out on
                            // another host and then simply navigated here
                            // never had one: ClerkJS resolves signed-out
                            // immediately, while the server still holds
                            // __dca_identity and has already served gated
                            // content off it. That is how a satellite kept
                            // serving an admin board to a signed-out browser.
                            //
                            // Reload only on a confirmed revoke — reloading
                            // after a failed POST would rebuild the same page
                            // and spin.
                            reconciledOnLoad = true;
                            console.log('[Clerk] server rendered a session the '
                                        + 'browser no longer has — revoking');
                            revokeServerSession().then((revoked) => {{
                                if (revoked) window.location.reload();
                            }});
                        }}

                        try {{
                            if (window.dash_clientside?.set_props) {{
                                window.dash_clientside.set_props('clerk-auth-store', {{data: authData}});
                                console.log('[Clerk] ✅ Auth data updated via set_props');
                            }}
                        }} catch (e) {{
                            console.log('[Clerk] set_props not available:', e.message);
                        }}

                        try {{
                            const hiddenInput = document.getElementById('clerk-auth-trigger');
                            if (hiddenInput) {{
                                hiddenInput.value = JSON.stringify(authData);
                                hiddenInput.dispatchEvent(new Event('input', {{ bubbles: true }}));
                                hiddenInput.dispatchEvent(new Event('change', {{ bubbles: true }}));
                                console.log('[Clerk] ✅ Auth data sent via trigger input');
                            }}
                        }} catch (e) {{
                            console.error('[Clerk] ❌ Trigger update failed:', e);
                        }}

                        updateUI(authData);
                        updateDebugPanel(authData);
                    }};

                    // v1.0.2 — the avatar-stuck-signed-out fix.
                    //
                    // The menu this writes into is rendered by Dash's React
                    // renderer, which mounts only after a SEPARATE
                    // /_dash-layout fetch. When Clerk wins that race (warm
                    // CDN, valid session cookie) every getElementById below
                    // returned null, the old updateUI silently no-opped, and
                    // Clerk's addListener never fired again because the
                    // session never CHANGED — so a signed-in user sat on a
                    // placeholder avatar and a "Sign In" menu for the whole
                    // life of the page while the server-side session was
                    // perfectly valid. Dash re-mounting the menu on page
                    // navigation reintroduced the same stale paint.
                    //
                    // Three things make it self-healing: the state is cached
                    // on window.dashClerkAuth, row visibility is driven by a
                    // class on <html> (CSS applies to nodes that mount
                    // later), and the node is stamped so a re-mounted menu
                    // is detectable. applyAuthState is idempotent.
                    // v1.0.3 — sign out has to reach the SERVER.
                    //
                    // Server-side identity has three layers: the signed
                    // __dca_identity cookie (verified locally, max-age
                    // session_lifetime_days — SEVEN DAYS by default), the
                    // session dict, and only then a Clerk verify of
                    // __session. Clerk.signOut() invalidates the input to
                    // the third and nothing else, so before this release a
                    // signed-out browser kept being served every gated page
                    // from the first layer until the cookie expired. On a
                    // shared computer that is the next person inheriting the
                    // previous user's access for up to a week.
                    //
                    // POST /api/auth/signout clears the session AND evicts
                    // the identity cookie. It has existed since v0.5 on both
                    // backends; nothing ever called it. It is idempotent, so
                    // firing it twice — which happens whenever an app also
                    // installs its own logout handler — is harmless.
                    const revokeServerSession = async () => {{
                        try {{
                            const res = await fetch('/api/auth/signout', {{
                                method: 'POST',
                                credentials: 'same-origin',
                                headers: {{'Content-Type': 'application/json'}},
                            }});
                            // Reported, not assumed: on FastAPI this endpoint
                            // answered 422 for its whole existence (the handler
                            // took an unannotated `request`, which FastAPI read
                            // as a required query field), and because nothing
                            // checked the status the failure was invisible.
                            if (!res || !res.ok) {{
                                console.error('[Clerk] signout POST rejected:',
                                              res && res.status);
                                return false;
                            }}
                            console.log('[Clerk] server session revoked');
                            return true;
                        }} catch (e) {{
                            // Never block sign-out on a network hiccup: the
                            // client is already signed out either way, and a
                            // thrown error here would strand the user on a
                            // page that looks signed in.
                            console.error('[Clerk] signout POST failed:', e);
                            return false;
                        }}
                    }};
                    window.dashClerkAuth.revokeServerSession = revokeServerSession;

                    // v1.0.4 — what the SERVER believed when it rendered this
                    // page, captured BEFORE applyAuthState can overwrite the
                    // class. It is the only signal available: __dca_identity
                    // is HttpOnly, so the page cannot read the cookie itself.
                    const serverRenderedSignedIn =
                        document.documentElement.classList.contains('clerk-signed-in');
                    window.dashClerkAuth.serverRenderedSignedIn = serverRenderedSignedIn;
                    let reconciledOnLoad = false;

                    const applyAuthState = (authData) => {{
                        if (!authData) return;
                        window.dashClerkAuth.authState = authData;

                        const signedIn = !!authData.user_id;
                        const rootClasses = document.documentElement.classList;
                        rootClasses.toggle('clerk-signed-in', signedIn);
                        rootClasses.toggle('clerk-signed-out', !signedIn);

                        const avatar = document.getElementById('clerk-user-avatar');
                        if (avatar) {{
                            if (signedIn && authData.image_url) {{
                                avatar.style.backgroundImage = `url(${{authData.image_url}})`;
                            }} else {{
                                // Signed out, or signed in with no Clerk
                                // image: the same inline default either way.
                                // Assigning the token beats removeProperty —
                                // it does not depend on a stylesheet rule
                                // having won the cascade for this element.
                                avatar.style.backgroundImage =
                                    'var(--clerk-avatar-default)';
                            }}
                            avatar.dataset.clerkState = signedIn ? authData.user_id : 'anonymous';
                        }}

                        // The root class alone would do this in a spec-
                        // compliant engine (an !important author rule beats a
                        // normal inline declaration), but writing the inline
                        // value too costs nothing and removes any dependence
                        // on that corner of the cascade.
                        const rows = [
                            ['clerk-login-button', signedIn ? 'none' : 'flex'],
                            ['clerk-user-info', signedIn ? 'block' : 'none'],
                            ['clerk-profile-button', signedIn ? 'flex' : 'none'],
                            ['clerk-menu-divider', signedIn ? 'block' : 'none'],
                            ['clerk-logout-menu-item', signedIn ? 'flex' : 'none'],
                        ];
                        rows.forEach(([id, display]) => {{
                            const el = document.getElementById(id);
                            if (el) el.style.display = display;
                        }});

                        const userInfo = document.getElementById('clerk-user-info');
                        if (userInfo) {{
                            // textContent, not innerHTML: first/last name and
                            // email are user-controlled Clerk profile fields.
                            userInfo.textContent = '';
                            if (signedIn) {{
                                const nameEl = document.createElement('div');
                                nameEl.style.fontWeight = '600';
                                nameEl.style.marginBottom = '4px';
                                nameEl.textContent = [authData.first_name, authData.last_name]
                                    .filter(Boolean).join(' ');
                                const emailEl = document.createElement('div');
                                emailEl.style.fontSize = '12px';
                                emailEl.style.color = 'var(--clerk-text-secondary, #6c757d)';
                                emailEl.textContent = authData.email || '';
                                userInfo.appendChild(nameEl);
                                userInfo.appendChild(emailEl);
                            }}
                        }}
                    }};

                    // Kept as a name so host apps that called updateUI()
                    // directly (it was reachable from the page scope) don't
                    // break on upgrade.
                    const updateUI = applyAuthState;

                    const updateDebugPanel = (authData) => {{
                        const debugUserId = document.getElementById('clerk-debug-user-id');
                        const debugEmail = document.getElementById('clerk-debug-email');
                        const debugName = document.getElementById('clerk-debug-name');
                        const debugSession = document.getElementById('clerk-debug-session');

                        if (debugUserId) debugUserId.textContent = authData.user_id || 'Not signed in';
                        if (debugEmail) debugEmail.textContent = authData.email || 'N/A';
                        if (debugName) debugName.textContent = authData.first_name ? `${{authData.first_name}} ${{authData.last_name || ''}}` : '';
                        if (debugSession) debugSession.textContent = authData.session_id || 'N/A';
                    }};

                    // Handlers are DELEGATED to document instead of bound to
                    // the nodes. Same race as above: at this point the menu
                    // may not exist yet, and Dash may replace it later — a
                    // node-bound listener dies with the node it was attached
                    // to, which is why a re-mounted avatar could render fine
                    // and still be unclickable.
                    const inside = (target, id) =>
                        target && target.closest ? target.closest('#' + id) : null;

                    document.addEventListener('click', (e) => {{
                        const dropdown = document.getElementById('clerk-menu-dropdown');

                        if (inside(e.target, 'clerk-user-avatar')) {{
                            e.stopPropagation();
                            if (dropdown) {{
                                dropdown.style.display =
                                    dropdown.style.display === 'block' ? 'none' : 'block';
                            }}
                            return;
                        }}

                        if (inside(e.target, 'clerk-login-button')) {{
                            if (isSatellite) {{
                                // ClerkJS throws "This operation is not
                                // allowed on a satellite domain" for the
                                // modal here — navigate to the primary.
                                const dca = window.dashClerkAuth;
                                const dest = dca && dca.buildSatelliteRedirect
                                    && dca.buildSatelliteRedirect();
                                if (dest) {{ window.location.assign(dest); return; }}
                                window.Clerk.redirectToSignIn({{
                                    signInForceRedirectUrl: window.location.href,
                                    signUpForceRedirectUrl: window.location.href
                                }});
                                return;
                            }}
                            window.Clerk.openSignIn({{
                                afterSignInUrl: window.location.href,
                                redirectUrl: window.location.href
                            }});
                            return;
                        }}

                        if (inside(e.target, 'clerk-profile-button')) {{
                            window.Clerk.openUserProfile();
                            return;
                        }}

                        if (inside(e.target, 'clerk-logout-menu-item')
                                || inside(e.target, 'clerk-logout-trigger')) {{
                            // Order matters: Clerk.signOut() FIRST, so the
                            // server's slow path cannot re-verify a still-live
                            // __session and mint a fresh identity cookie in
                            // the window between the two calls. Then revoke,
                            // then reload — awaited, so the reload never races
                            // the Set-Cookie that clears the identity.
                            (async () => {{
                                try {{
                                    await window.Clerk.signOut();
                                }} catch (err) {{
                                    console.error('[Clerk] signOut failed:', err);
                                }}
                                await revokeServerSession();
                                window.location.reload();
                            }})();
                            return;
                        }}

                        // Anywhere else closes the dropdown.
                        if (dropdown && !inside(e.target, 'clerk-menu-dropdown')) {{
                            dropdown.style.display = 'none';
                        }}
                    }});

                    // Clerk fires no event when Dash mounts or re-mounts the
                    // menu, so watch the DOM for it and re-apply the cached
                    // state. The stamp makes this idempotent — it does work
                    // only when the node on screen disagrees with the session
                    // we already know about.
                    let reapplyQueued = false;
                    const menuObserver = new MutationObserver(() => {{
                        if (reapplyQueued) return;
                        const state = window.dashClerkAuth.authState;
                        if (!state) return;
                        const avatar = document.getElementById('clerk-user-avatar');
                        if (!avatar) return;
                        const stamp = state.user_id || 'anonymous';
                        if (avatar.dataset.clerkState === stamp) return;
                        reapplyQueued = true;
                        requestAnimationFrame(() => {{
                            reapplyQueued = false;
                            const current = window.dashClerkAuth.authState;
                            applyAuthState(current);
                            updateDebugPanel(current);
                        }});
                    }});
                    menuObserver.observe(document.body, {{childList: true, subtree: true}});

                    window.Clerk.addListener(updateAuthState);
                    console.log('[Clerk] Performing initial auth check...');
                    updateAuthState();

                    if (!window.Clerk.user) {{
                        console.log('[Clerk] No active session');
                    }} else {{
                        console.log('[Clerk] Active session detected');
                    }}
                }} catch (error) {{
                    console.error('[Clerk] Initialization error:', error);
                }}
            }});
        </script>
    '''

    # Liquid Glass CSS styles - NO INLINE STYLES, use classes with !important
    liquid_glass_styles = '''
    <style>
        /* Initialize CSS variables (light-mode defaults — JS swaps these on
           dark-mode toggle via window.updateClerkTheme). Two tiers of
           backdrop: --clerk-glass-bg* is the translucent look for the header
           dropdown + debug panel; --clerk-modal-bg* is the much more opaque
           backing for the Clerk profile modal so text stays legible. */
        :root {
            --clerk-glass-bg: rgba(255, 255, 255, 0.50);
            --clerk-glass-bg-secondary: rgba(255, 255, 255, 0.40);
            --clerk-glass-bg-hover: rgba(255, 255, 255, 0.70);
            --clerk-modal-bg: rgba(255, 255, 255, 0.96);
            --clerk-modal-bg-secondary: rgba(248, 250, 252, 0.90);
            --clerk-modal-bg-hover: rgba(255, 255, 255, 1.00);
            --clerk-modal-backdrop: rgba(15, 23, 42, 0.35);
            --clerk-modal-border: rgba(15, 23, 42, 0.10);
            --clerk-modal-specular: rgba(255, 255, 255, 0.9);
            --clerk-border: rgba(0, 0, 0, 0.08);
            --clerk-shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.06);
            --clerk-shadow-md: 0 4px 16px rgba(0, 0, 0, 0.06), 0 2px 4px rgba(0, 0, 0, 0.08);
            --clerk-shadow-lg: 0 12px 40px rgba(0, 0, 0, 0.08), 0 4px 12px rgba(0, 0, 0, 0.10);
            --clerk-text: #2c3e50;
            --clerk-text-secondary: #6c757d;
            --clerk-hover-bg: rgba(0, 0, 0, 0.04);
            --clerk-danger-bg: rgba(239, 68, 68, 0.1);
            --clerk-blur-sm: 10px;
            --clerk-blur-md: 20px;
            --clerk-blur-lg: 30px;
        }

        /* SESSION STATE — driven by a class on <html>, not inline styles.
           The server stamps it at index render and the Clerk listener keeps
           it in sync. This is what makes a menu Dash mounts LATE (or
           re-mounts on navigation) correct on its FIRST paint: CSS applies
           to nodes the moment they appear, with no JS round-trip to lose.
           !important is load-bearing — it has to beat the inline display
           styles Dash renders onto these same elements. */
        html.clerk-signed-in #clerk-login-button { display: none !important; }
        html.clerk-signed-in #clerk-user-info { display: block !important; }
        html.clerk-signed-in #clerk-profile-button,
        html.clerk-signed-in #clerk-logout-menu-item { display: flex !important; }
        html.clerk-signed-in #clerk-menu-divider { display: block !important; }

        html.clerk-signed-out #clerk-login-button { display: flex !important; }
        html.clerk-signed-out #clerk-user-info,
        html.clerk-signed-out #clerk-profile-button,
        html.clerk-signed-out #clerk-menu-divider,
        html.clerk-signed-out #clerk-logout-menu-item { display: none !important; }

        /* CRITICAL: Ensure container is visible */
        #clerk-auth-menu-container {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            pointer-events: auto !important;
        }

        /* USER AVATAR */
        #clerk-user-avatar {
            position: relative !important;
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            cursor: pointer !important;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
            isolation: isolate !important;
        }

        /* Halo effect using box-shadow (no overlap with avatar) */
        #clerk-user-avatar:hover {
            transform: scale(1.08) rotate(2deg) !important;
            box-shadow: 
                0 0 0 6px var(--clerk-glass-bg),
                0 0 0 7px var(--clerk-border),
                var(--clerk-shadow-lg) !important;
        }

        #clerk-user-avatar:active {
            transform: scale(0.96) !important;
        }

        /* DROPDOWN MENU */
        #clerk-menu-dropdown {
            background: transparent !important;
            backdrop-filter: blur(var(--clerk-blur-md)) saturate(180%) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-md)) saturate(180%) !important;
            border: 1px solid var(--clerk-border) !important;
            border-radius: 14px !important;
            box-shadow: var(--clerk-shadow-lg) !important;
            animation: dropdown-slide-in 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
            overflow: hidden !important;
        }

        #clerk-menu-dropdown::before {
            content: '';
            position: absolute;
            inset: 0;
            background: var(--clerk-glass-bg);
            z-index: -1;
            pointer-events: none;
            border-radius: 14px;
        }

        #clerk-menu-dropdown::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: rgba(255, 255, 255, 0.4);
            z-index: 1;
            pointer-events: none;
        }

        @keyframes dropdown-slide-in {
            0% {
                opacity: 0;
                transform: translateY(-12px) scale(0.94);
            }
            100% {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        /* USER INFO CARD */
        #clerk-user-info {
            position: relative;
            z-index: 2;
            background: var(--clerk-glass-bg-secondary) !important;
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            border-radius: 10px !important;
            border: 1px solid var(--clerk-border) !important;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
            margin: 6px !important;
            padding: 14px 12px !important;
        }

        #clerk-user-info:hover {
            background: var(--clerk-glass-bg-hover) !important;
            transform: translateY(-1px);
            box-shadow: var(--clerk-shadow-sm) !important;
        }

        /* BUTTONS */
        #clerk-profile-button,
        #clerk-logout-menu-item,
        #clerk-login-button {
            position: relative !important;
            z-index: 2 !important;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
            border-radius: 8px !important;
        }

        #clerk-profile-button:hover,
        button[id*="clerk-profile"]:hover {
            background: var(--clerk-hover-bg) !important;
            transform: translateX(3px);
            box-shadow: var(--clerk-shadow-sm) !important;
        }

        #clerk-logout-menu-item:hover {
            background: var(--clerk-danger-bg) !important;
            transform: translateX(3px);
            box-shadow: 0 2px 8px rgba(239, 68, 68, 0.2) !important;
        }

        #clerk-login-button {
            background: linear-gradient(135deg, #049ff2 0%, #0284c7 100%) !important;
            border: none !important;
            border-radius: 10px !important;
            box-shadow: 0 4px 12px rgba(4, 159, 242, 0.3) !important;
        }

        #clerk-login-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(4, 159, 242, 0.4) !important;
        }

        /* DEBUG PANEL */
        #clerk-debug-panel {
            background: transparent !important;
            backdrop-filter: blur(var(--clerk-blur-md)) saturate(180%) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-md)) saturate(180%) !important;
            border: 1px solid var(--clerk-border) !important;
            border-radius: 16px !important;
            box-shadow: var(--clerk-shadow-lg) !important;
            overflow: hidden !important;
            animation: debug-slide 0.4s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }

        #clerk-debug-panel::before {
            content: '';
            position: absolute;
            inset: 0;
            background: var(--clerk-glass-bg);
            z-index: -1;
            pointer-events: none;
            border-radius: 16px;
        }

        #clerk-debug-panel::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.6) 50%, transparent 100%);
            z-index: 1;
            pointer-events: none;
        }

        @keyframes debug-slide {
            0% {
                opacity: 0;
                transform: translateX(100%) scale(0.9);
            }
            100% {
                opacity: 1;
                transform: translateX(0) scale(1);
            }
        }

        #clerk-debug-user-id,
        #clerk-debug-email,
        #clerk-debug-name,
        #clerk-debug-session {
            padding: 8px 12px !important;
            margin: 6px 0 !important;
            background: rgba(0, 0, 0, 0.03) !important;
            border-radius: 6px !important;
            border: 1px solid var(--clerk-border) !important;
            font-family: 'SF Mono', Monaco, Menlo, monospace !important;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }

        #clerk-debug-user-id:hover,
        #clerk-debug-email:hover,
        #clerk-debug-name:hover,
        #clerk-debug-session:hover {
            background: rgba(0, 0, 0, 0.05) !important;
            transform: translateX(2px);
            box-shadow: var(--clerk-shadow-sm) !important;
            cursor: pointer;
        }

        /* DARK MODE ADJUSTMENTS */
        [data-mantine-color-scheme="dark"] #clerk-debug-user-id,
        [data-mantine-color-scheme="dark"] #clerk-debug-email,
        [data-mantine-color-scheme="dark"] #clerk-debug-name,
        [data-mantine-color-scheme="dark"] #clerk-debug-session {
            background: rgba(255, 255, 255, 0.04) !important;
        }

        [data-mantine-color-scheme="dark"] #clerk-debug-user-id:hover,
        [data-mantine-color-scheme="dark"] #clerk-debug-email:hover,
        [data-mantine-color-scheme="dark"] #clerk-debug-name:hover,
        [data-mantine-color-scheme="dark"] #clerk-debug-session:hover {
            background: rgba(255, 255, 255, 0.06) !important;
        }

        /* ========================================
           CLERK PROFILE MODAL - LIQUID GLASS
           ========================================
           Uses the --clerk-modal-* variables (more opaque than the
           --clerk-glass-* tier) so the Clerk-rendered text stays legible on
           light backgrounds instead of washing out. */

        /* Backdrop / scrim behind the modal — Clerk doesn't dim the page by
           default, which makes a semi-transparent modal look like it's
           floating in a void. Add a soft scrim so the modal has context. */
        .cl-modalBackdrop,
        div[class*="cl-modalBackdrop"] {
            background: var(--clerk-modal-backdrop) !important;
            backdrop-filter: blur(2px) !important;
            -webkit-backdrop-filter: blur(2px) !important;
        }

        /* Main modal container. `position: relative` is REQUIRED so the
           ::before background layer below anchors inside the modal — without
           it the layer escapes to the nearest positioned ancestor and the
           modal ends up transparent. */
        .cl-modalContent,
        .cl-userProfile-root,
        .cl-cardBox {
            position: relative !important;
            background: transparent !important;
            backdrop-filter: blur(var(--clerk-blur-md)) saturate(180%) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-md)) saturate(180%) !important;
            border: 1px solid var(--clerk-modal-border) !important;
            box-shadow: var(--clerk-shadow-lg) !important;
            overflow: hidden !important;
        }

        /* Opaque modal backing — uses the higher-contrast modal variables. */
        .cl-modalContent::before,
        .cl-cardBox::before {
            content: '';
            position: absolute;
            inset: 0;
            background: var(--clerk-modal-bg) !important;
            z-index: -1;
            pointer-events: none;
            border-radius: inherit;
        }

        /* Top specular highlight on modal */
        .cl-modalContent::after,
        .cl-cardBox::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent 0%, var(--clerk-modal-specular) 50%, transparent 100%) !important;
            z-index: 1;
            pointer-events: none;
        }

        /* Navbar — opaque-ish tint rather than see-through in light mode. */
        .cl-navbar {
            background: var(--clerk-modal-bg-secondary) !important;
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            border-bottom: 1px solid var(--clerk-modal-border) !important;
        }

        /* Navbar buttons - glass hover */
        .cl-navbarButton {
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
            border-radius: 10px !important;
        }

        .cl-navbarButton:hover {
            background: var(--clerk-hover-bg) !important;
            transform: translateY(-1px);
            box-shadow: var(--clerk-shadow-sm) !important;
        }

        .cl-navbarButton[data-active="true"],
        .cl-active {
            background: var(--clerk-glass-bg-hover) !important;
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            box-shadow: var(--clerk-shadow-sm) !important;
        }

        /* Profile sections — nested panels within the modal. Use the modal
           backing tokens so nested content doesn't inherit the see-through
           glass look that causes light-mode legibility problems. */
        .cl-profileSection {
            background: var(--clerk-modal-bg-secondary) !important;
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            border: 1px solid var(--clerk-modal-border) !important;
            border-radius: 12px !important;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }

        .cl-profileSection:hover {
            background: var(--clerk-modal-bg-hover) !important;
            transform: translateY(-2px);
            box-shadow: var(--clerk-shadow-md) !important;
        }

        /* Profile section items */
        .cl-profileSectionItem {
            background: var(--clerk-modal-bg-secondary) !important;
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            border: 1px solid var(--clerk-modal-border) !important;
            border-radius: 10px !important;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }

        .cl-profileSectionItem:hover {
            background: var(--clerk-modal-bg-hover) !important;
            transform: translateX(3px);
            box-shadow: var(--clerk-shadow-sm) !important;
        }

        /* Badges */
        .cl-badge {
            background: var(--clerk-modal-bg-secondary) !important;
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            border: 1px solid var(--clerk-modal-border) !important;
            padding: 4px 10px !important;
            border-radius: 6px !important;
        }

        /* Buttons - consistent glass */
        .cl-button,
        .cl-profileSectionPrimaryButton,
        .cl-menuButton {
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
            border-radius: 8px !important;
        }

        .cl-button:hover,
        .cl-profileSectionPrimaryButton:hover,
        .cl-menuButton:hover {
            background: var(--clerk-hover-bg) !important;
            transform: translateX(2px);
            box-shadow: var(--clerk-shadow-sm) !important;
        }

        /* Close button */
        .cl-modalCloseButton {
            background: var(--clerk-modal-bg-secondary) !important;
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            border: 1px solid var(--clerk-modal-border) !important;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }

        .cl-modalCloseButton:hover {
            background: var(--clerk-danger-bg) !important;
            transform: rotate(90deg) scale(1.1);
            box-shadow: var(--clerk-shadow-md) !important;
        }

        /* Footer — the "Secured by Clerk" strip at the bottom. */
        .cl-footer {
            background: var(--clerk-modal-bg-secondary) !important;
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            border-top: 1px solid var(--clerk-modal-border) !important;
        }

        /* Scroll box - subtle glass tint */
        .cl-scrollBox {
            background: transparent !important;
        }

        /* Avatar in modal - glass ring */
        .cl-avatarBox {
            position: relative;
        }

        .cl-avatarBox::before {
            content: '';
            position: absolute;
            inset: -4px;
            background: var(--clerk-glass-bg);
            backdrop-filter: blur(var(--clerk-blur-sm));
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm));
            border-radius: 50%;
            border: 1px solid var(--clerk-border);
            z-index: -1;
            box-shadow: var(--clerk-shadow-sm);
            pointer-events: none;
        }

        /* Provider icons - glass background */
        .cl-providerIcon {
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            border: 1px solid var(--clerk-border) !important;
            border-radius: 8px !important;
        }

        /* Form inputs — live inside the modal so use the opaque modal tier
           for consistent legibility. */
        .cl-formFieldInput,
        input[class*="cl-"] {
            background: var(--clerk-modal-bg-secondary) !important;
            backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            -webkit-backdrop-filter: blur(var(--clerk-blur-sm)) !important;
            border: 1px solid var(--clerk-modal-border) !important;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }

        .cl-formFieldInput:focus,
        input[class*="cl-"]:focus {
            background: var(--clerk-modal-bg-hover) !important;
            border-color: #049ff2 !important;
            box-shadow: 0 0 0 3px rgba(4, 159, 242, 0.1) !important;
        }
        /* (Obsolete dark-mode overrides for .cl-modalContent / .cl-cardBox /
           .cl-navbar / .cl-profileSection removed — the ::before backing
           layer now pulls its colour from --clerk-modal-bg, which the JS
           theme-toggles for both schemes. Keeping redundant rules here
           would stack a translucent tint on top of the opaque backing.) */

        /* ============================================================
           LIGHT-MODE LEGIBILITY OVERRIDES (v0.8)
           ------------------------------------------------------------
           The translucent glass tiers above read well in dark mode but
           wash out in light mode: the SignIn and UserProfile modals end
           up letting the page bleed through (transparent shells + a
           z-index:-1 ::before backing + Clerk's own semi-transparent
           colorBackground), so text and panels look broken on a light
           page. Here we force SOLID, high-contrast surfaces and explicit
           text colours using *literal* values (not the --clerk-* vars,
           which the inline JS theme-swap would otherwise win over).

           Scoped to html[data-mantine-color-scheme="light"] so the
           dark-mode look is completely untouched, and the higher selector
           specificity (element + attribute + class) beats the !important
           glass rules above in light mode. Targets only Clerk's STABLE
           semantic classes (cl-card, cl-navbar, …) — never the hashed
           cl-internal-* classes, which change between Clerk releases. */

        /* Solid modal shells — kills the transparent/::before bleed-through. */
        html[data-mantine-color-scheme="light"] .cl-modalContent,
        html[data-mantine-color-scheme="light"] .cl-card,
        html[data-mantine-color-scheme="light"] .cl-cardBox,
        html[data-mantine-color-scheme="light"] .cl-rootBox {
            background: #ffffff !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border-color: rgba(15, 23, 42, 0.10) !important;
        }
        html[data-mantine-color-scheme="light"] .cl-modalContent::before,
        html[data-mantine-color-scheme="light"] .cl-cardBox::before {
            background: #ffffff !important;
        }

        /* Structural wrappers stay transparent so the white shell shows. */
        html[data-mantine-color-scheme="light"] .cl-main,
        html[data-mantine-color-scheme="light"] .cl-scrollBox,
        html[data-mantine-color-scheme="light"] .cl-pageScrollBox,
        html[data-mantine-color-scheme="light"] .cl-page,
        html[data-mantine-color-scheme="light"] .cl-profilePage,
        html[data-mantine-color-scheme="light"] .cl-header {
            background: transparent !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
        }

        /* UserProfile left-rail navbar. */
        html[data-mantine-color-scheme="light"] .cl-navbar {
            background: #f6f8fb !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border-right: 1px solid rgba(15, 23, 42, 0.08) !important;
            border-bottom: none !important;
        }
        html[data-mantine-color-scheme="light"] .cl-navbarButton {
            color: #1f2937 !important;
        }
        html[data-mantine-color-scheme="light"] .cl-navbarButton:hover {
            background: rgba(15, 23, 42, 0.04) !important;
        }
        html[data-mantine-color-scheme="light"] .cl-navbarButton[data-active="true"],
        html[data-mantine-color-scheme="light"] .cl-navbarButton.cl-active {
            background: rgba(59, 130, 246, 0.10) !important;
            color: #2563eb !important;
        }

        /* Nested panels (profile sections + their items). */
        html[data-mantine-color-scheme="light"] .cl-profileSection,
        html[data-mantine-color-scheme="light"] .cl-profileSectionItem,
        html[data-mantine-color-scheme="light"] .cl-profileSectionItemList {
            background: #f6f8fb !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border-color: rgba(15, 23, 42, 0.08) !important;
        }
        html[data-mantine-color-scheme="light"] .cl-profileSection:hover,
        html[data-mantine-color-scheme="light"] .cl-profileSectionItem:hover {
            background: #eef2f7 !important;
        }

        /* Make every Clerk-rendered string legible (dark on white). */
        html[data-mantine-color-scheme="light"] .cl-headerTitle,
        html[data-mantine-color-scheme="light"] .cl-profileSectionTitleText,
        html[data-mantine-color-scheme="light"] .cl-userPreviewMainIdentifierText,
        html[data-mantine-color-scheme="light"] .cl-formFieldLabel,
        html[data-mantine-color-scheme="light"] .cl-accordionTriggerButton {
            color: #1f2937 !important;
        }
        html[data-mantine-color-scheme="light"] .cl-headerSubtitle,
        html[data-mantine-color-scheme="light"] .cl-dividerText,
        html[data-mantine-color-scheme="light"] .cl-formFieldHintText,
        html[data-mantine-color-scheme="light"] .cl-footerActionText {
            color: #6b7280 !important;
        }

        /* Action buttons / links / overflow-menu icons. */
        html[data-mantine-color-scheme="light"] .cl-profileSectionPrimaryButton,
        html[data-mantine-color-scheme="light"] .cl-footerActionLink {
            color: #2563eb !important;
        }
        html[data-mantine-color-scheme="light"] .cl-menuButton {
            color: #6b7280 !important;
        }

        /* SignIn social buttons + form inputs — solid white surfaces. */
        html[data-mantine-color-scheme="light"] .cl-socialButtonsBlockButton,
        html[data-mantine-color-scheme="light"] .cl-socialButtonsIconButton {
            background: #ffffff !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border: 1px solid rgba(15, 23, 42, 0.12) !important;
            color: #1f2937 !important;
        }
        html[data-mantine-color-scheme="light"] .cl-socialButtonsBlockButton:hover,
        html[data-mantine-color-scheme="light"] .cl-socialButtonsIconButton:hover {
            background: #f6f8fb !important;
        }
        html[data-mantine-color-scheme="light"] .cl-formFieldInput,
        html[data-mantine-color-scheme="light"] input[class*="cl-"] {
            background: #ffffff !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border: 1px solid rgba(15, 23, 42, 0.16) !important;
            color: #1f2937 !important;
        }

        /* Divider, footer strip, badge. */
        html[data-mantine-color-scheme="light"] .cl-dividerLine {
            background: rgba(15, 23, 42, 0.10) !important;
        }
        html[data-mantine-color-scheme="light"] .cl-footer {
            background: #f6f8fb !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border-top: 1px solid rgba(15, 23, 42, 0.08) !important;
        }
        html[data-mantine-color-scheme="light"] .cl-badge {
            background: rgba(59, 130, 246, 0.10) !important;
            color: #2563eb !important;
            border: 1px solid rgba(59, 130, 246, 0.20) !important;
        }

        /* ============================================================
           DARK-MODE LEGIBILITY OVERRIDES (v0.8.1)
           ------------------------------------------------------------
           Mirror of the light block, driven by Mantine's scheme-aware
           dark palette so the UserProfile modal panels + text MATCH the
           DMC dark theme (fixes the washed dark-on-dark render that the
           load-time-baked Clerk appearance produced after a theme
           toggle). Solid DMC surfaces, light text; the ::before glass
           backing is removed so nothing bleeds through. Pairs with the
           DMC-variable-driven Clerk `appearance` above, which colours
           Clerk's hashed internal elements the same way. */
        html[data-mantine-color-scheme="dark"] .cl-modalContent,
        html[data-mantine-color-scheme="dark"] .cl-card,
        html[data-mantine-color-scheme="dark"] .cl-cardBox,
        html[data-mantine-color-scheme="dark"] .cl-rootBox {
            background: var(--mantine-color-body, #242424) !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border-color: var(--mantine-color-default-border, #424242) !important;
        }
        html[data-mantine-color-scheme="dark"] .cl-modalContent::before,
        html[data-mantine-color-scheme="dark"] .cl-cardBox::before {
            display: none !important;
        }
        html[data-mantine-color-scheme="dark"] .cl-navbar {
            background: var(--mantine-color-default, #2e2e2e) !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border-right: 1px solid var(--mantine-color-default-border, #424242) !important;
            border-bottom: none !important;
        }
        html[data-mantine-color-scheme="dark"] .cl-profileSection,
        html[data-mantine-color-scheme="dark"] .cl-profileSectionItem,
        html[data-mantine-color-scheme="dark"] .cl-profileSectionItemList {
            background: var(--mantine-color-default, #2e2e2e) !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border-color: var(--mantine-color-default-border, #424242) !important;
        }
        html[data-mantine-color-scheme="dark"] .cl-profileSection:hover,
        html[data-mantine-color-scheme="dark"] .cl-profileSectionItem:hover {
            background: var(--mantine-color-default-hover, #3b3b3b) !important;
        }
        html[data-mantine-color-scheme="dark"] .cl-navbarButton,
        html[data-mantine-color-scheme="dark"] .cl-headerTitle,
        html[data-mantine-color-scheme="dark"] .cl-profileSectionTitleText,
        html[data-mantine-color-scheme="dark"] .cl-userPreviewMainIdentifierText,
        html[data-mantine-color-scheme="dark"] .cl-formFieldLabel {
            color: var(--mantine-color-text, #c9c9c9) !important;
        }
        html[data-mantine-color-scheme="dark"] .cl-headerSubtitle,
        html[data-mantine-color-scheme="dark"] .cl-dividerText,
        html[data-mantine-color-scheme="dark"] .cl-footerActionText {
            color: var(--mantine-color-dimmed, #828282) !important;
        }
        html[data-mantine-color-scheme="dark"] .cl-socialButtonsBlockButton,
        html[data-mantine-color-scheme="dark"] .cl-socialButtonsIconButton,
        html[data-mantine-color-scheme="dark"] .cl-formFieldInput,
        html[data-mantine-color-scheme="dark"] input[class*="cl-"] {
            background: var(--mantine-color-default, #2e2e2e) !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            border: 1px solid var(--mantine-color-default-border, #424242) !important;
            color: var(--mantine-color-text, #c9c9c9) !important;
        }
        html[data-mantine-color-scheme="dark"] .cl-footer {
            background: transparent !important;
            border-top: 1px solid var(--mantine-color-default-border, #424242) !important;
        }

        /* Structural wrappers transparent in BOTH schemes so the modal
           shell colour shows through (kills the stray light header bar the
           UserProfile modal showed in dark mode). */
        .cl-main, .cl-scrollBox, .cl-pageScrollBox, .cl-page,
        .cl-profilePage, .cl-header, .cl-profileSectionContent {
            background: transparent !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
        }

        /* Input placeholder — DMC-coloured in BOTH schemes (var() tracks
           the toggle). Clerk's own ::placeholder styling is unreliable. */
        .cl-formFieldInput::placeholder,
        input[class*="cl-"]::placeholder {
            color: var(--mantine-color-placeholder, #868e96) !important;
            opacity: 1 !important;
        }


        /* Accessibility */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                transition-duration: 0.01ms !important;
            }
        }

        /* Focus visible */
        *:focus-visible {
            outline: 2px solid #049ff2 !important;
            outline-offset: 2px !important;
        }
    </style>
    '''

    # The signed-out avatar. Its own block because the value is a data URI
    # built in Python, and liquid_glass_styles above is a literal. The
    # :root value is the light default; window.updateClerkTheme() swaps it
    # with the other tokens. The element rule is the pre-JS paint and the
    # fallback for a menu Dash mounts before any script has touched it.
    avatar_styles = f"""
    <style>
        :root {{
            --clerk-avatar-default: {AVATAR_DEFAULT_LIGHT};
        }}
        #clerk-user-avatar {{
            background-image: var(--clerk-avatar-default);
        }}
    </style>
    """

    # Stamp this request's verified session onto <html> while the head is
    # still parsing, so the state rules above are live before the body — and
    # therefore before Dash mounts the menu. Without this the first paint is
    # always the anonymous one and the signed-in look arrives (at best) a
    # Clerk round-trip later, or (when Clerk resolves first) never.
    _snapshot = _current_auth_snapshot()
    _root_state = (
        'clerk-signed-in' if (_snapshot and _snapshot.get('user_id'))
        else 'clerk-signed-out'
    )
    state_script = (
        '<script>(function(){var c=document.documentElement.classList;'
        "c.remove('clerk-signed-in','clerk-signed-out');"
        "c.add('" + _root_state + "');})();</script>"
    )

    if '</head>' in index_string:
        index_string = index_string.replace(
            '</head>',
            f'{clerk_script}{init_script}{liquid_glass_styles}'
            f'{avatar_styles}{state_script}</head>'
        )

    return index_string


@hooks.layout()
def add_auth_components(layout):
    """Add authentication UI components to the layout.

    v0.7: ``clerk-auth-store`` is pre-hydrated from ``current_user()`` at
    layout build time. This is the change that kills the "first paint
    shows anonymous → refresh fixes it" race: when the page render runs
    inside a Dash 4.2 WebSocket-served callback, ``current_user()`` reads
    the verified identity from either the ContextVar (HTTP) or the
    per-renderer WS registry (WS) — both populated by the ASGI middleware
    + WS hooks before this layout function executes. The store starts
    populated, so layout decorators (``@require_auth_layout`` /
    ``@admin_required``) commit to the right branch synchronously instead
    of falling through to the dual-div client-gate fallback.
    """
    if not _clerk_config.get('initialized'):
        return layout

    # Read the verified user once at layout build time so the store
    # starts populated. Safe across all backends — current_user() falls
    # through to None outside any request scope (e.g. import-time builds).
    initial_auth_data = _current_auth_snapshot()

    auth_components = [
        dcc.Location(id="url", refresh=False),
        dcc.Store(
            id="clerk-auth-store",
            storage_type='memory',
            data=initial_auth_data,
        ),
        dcc.Input(id="clerk-auth-trigger", type="text", style={'display': 'none'}),
        dcc.Interval(
            id='clerk-auth-check-interval',
            interval=1000,
            n_intervals=0,
            disabled=False
        ),
        html.Button("Logout Trigger", id="clerk-logout-trigger", style={'display': 'none'}),
    ]

    # In headless mode the host app renders its own avatar / menu; otherwise
    # the hook injects its fixed-position glass dropdown in the top-right.
    if not _clerk_config.get('headless'):
        auth_components.append(
            html.Div(
                id="clerk-auth-menu-container",
                children=[_create_auth_menu()],
                style={
                    'position': 'fixed',
                    'top': '16px',
                    'right': '16px',
                    'zIndex': '9999',
                },
            )
        )

    if _clerk_config.get('show_debug_panel'):
        auth_components.append(_create_debug_panel())

    if not isinstance(layout, list):
        layout = [layout]

    return auth_components + layout


def _menu_identity_lines(snapshot):
    """Name + email rows for the dropdown, from a server-side snapshot.

    Mirrors what the client script renders once Clerk resolves, so the two
    paths cannot disagree about the layout.
    """
    name = ' '.join(
        part for part in (snapshot.get('first_name'), snapshot.get('last_name'))
        if part
    )
    return [
        html.Div(name, style={'fontWeight': '600', 'marginBottom': '4px'}),
        html.Div(
            snapshot.get('email') or '',
            style={'fontSize': '12px', 'color': 'var(--clerk-text-secondary, #6c757d)'},
        ),
    ]


def create_clerk_menu(show_dropdown=True, dropdown_align="right", _internal=False):
    """Build the liquid-glass avatar (and optionally its dropdown) as a Dash
    component you can place anywhere in your layout.

    Use this together with ``register_clerk_auth(..., headless=True)`` when
    you want the avatar embedded in your own layout — a
    ``dmc.AppShellHeader`` Group, a custom topbar, a drawer, etc. — rather
    than floating fixed top-right.

    Example::

        from dash_clerk_auth import register_clerk_auth, create_clerk_menu
        register_clerk_auth(..., headless=True)

        dmc.AppShellHeader(
            dmc.Group([
                dmc.Title("My app"),
                create_clerk_menu(),        # <- avatar + dropdown drop in here
            ], justify="space-between", h="100%", px="md"),
        )

    :param show_dropdown: When False, return just the bare avatar
        ``html.Div(id='clerk-user-avatar')`` with no dropdown sibling — useful
        if you want to wrap the avatar in your own ``dmc.Menu`` / ``dmc.Popover``.
        The hook's click-to-toggle JS is skipped in that case (it's a no-op
        when the dropdown element is missing).
    :param dropdown_align: ``"right"`` (default) or ``"left"`` — which edge of
        the avatar the dropdown snaps to. Flip to ``"left"`` when the avatar
        sits on the left-hand side of a header.
    :param _internal: reserved; used by the hook's default fixed-position
        injection. End users should leave it at False.
    :return: A single ``html.Div`` (wrapped in ``position: relative`` so the
        dropdown anchors correctly). Safe to nest inside any DMC component.
    """
    if not _internal and not _clerk_config.get('headless'):
        logger.warning(
            "create_clerk_menu() called while headless=False — the hook has "
            "already injected its own avatar at the fixed top-right. Rendering "
            "this widget too will create duplicate id='clerk-user-avatar' "
            "elements and Dash will error on the next callback. Pass "
            "headless=True to register_clerk_auth() when embedding the menu "
            "in your own layout."
        )

    sign_in_url = _clerk_config.get('clerk_sign_in_url', '')

    # v1.0.2: render the verified viewer's own face when the server knows who
    # this is. That removes the client-side race from the common case
    # entirely — a signed-in user's first paint is already correct, with no
    # dependency on when clerk.browser.js resolves relative to Dash's
    # separate /_dash-layout fetch. When the menu is built outside a request
    # scope (a module-level layout object) there is no viewer and this falls
    # back to the placeholder, which the injected script then corrects.
    snapshot = _current_auth_snapshot()
    signed_in = bool(snapshot and snapshot.get('user_id'))

    # The neutral glyph for anyone we cannot identify server-side. It is a
    # custom property, not a literal, so the light/dark swap is the same one
    # every other Clerk surface gets.
    avatar_image = "var(--clerk-avatar-default)"
    if signed_in:
        _image_url = snapshot.get('image_url') or ''
        # Quote/newline check, not decoration: this lands inside a
        # single-quoted CSS url(), so anything that could close it is
        # dropped in favour of the placeholder.
        if _image_url and not set(_image_url) & {"'", '"', '\\', '\n', '\r', '(', ')'}:
            avatar_image = f"url('{_image_url}')"

    avatar = html.Div(
        id="clerk-user-avatar",
        n_clicks=0,
        **{'data-clerk-state': snapshot['user_id'] if signed_in else 'anonymous'},
        style={
            'display': 'block',
            'width': '44px',
            'height': '44px',
            'borderRadius': '50%',
            'backgroundSize': 'cover',
            'backgroundPosition': 'center',
            'border': '2px solid rgba(0,0,0,0.1)',
            'backgroundColor': '#f8f9fa',
            'boxShadow': '0 2px 8px rgba(0,0,0,0.1)',
            'backgroundImage': avatar_image,
        }
    )

    if not show_dropdown:
        # Still wrap in a relative div so it behaves like a normal inline
        # block — lets users drop it into a dmc.Group without surprises.
        return html.Div([avatar], style={'position': 'relative', 'display': 'inline-block'})

    # Dropdown — the pixel-offset anchors it 52px below the avatar; flip the
    # horizontal anchor based on dropdown_align.
    _align_key = 'left' if dropdown_align == 'left' else 'right'
    dropdown_style = {
        'position': 'absolute',
        'top': '52px',
        _align_key: '0',
        'display': 'none',
        'minWidth': '200px',
        'zIndex': '10000',
        'padding': '6px',
    }

    dropdown = html.Div(
        [
            html.Button(
                [html.Span("Sign In"), html.Span("→", style={'fontSize': '16px', 'marginLeft': '8px'})],
                id="clerk-login-button",
                n_clicks=0,
                **{'data-signin-url': sign_in_url},
                style={
                    'display': 'none' if signed_in else 'flex',
                    'alignItems': 'center',
                    'justifyContent': 'space-between',
                    'width': '100%',
                    'padding': '12px 16px',
                    'margin': '6px',
                    'color': 'white',
                    'cursor': 'pointer',
                    'fontFamily': '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto',
                    'fontSize': '14px',
                    'fontWeight': '500',
                }
            ),

            html.Div([
                # Text has to come from the server — CSS can show or hide a
                # row but cannot fill one in. Visibility itself is handled by
                # the clerk-signed-in / clerk-signed-out class on <html>, so
                # these inline display values are only the pre-stylesheet
                # default.
                html.Div(
                    _menu_identity_lines(snapshot) if signed_in else None,
                    id="clerk-user-info",
                    style={'display': 'block' if signed_in else 'none'},
                ),
                html.Button(
                    [html.Span("👤", style={'marginRight': '8px'}), html.Span("Manage Profile")],
                    id="clerk-profile-button",
                    n_clicks=0,
                    style={
                        'display': 'flex' if signed_in else 'none',
                        'alignItems': 'center',
                        'width': '100%',
                        'padding': '10px 12px',
                        'margin': '3px 6px',
                        'border': 'none',
                        'backgroundColor': 'transparent',
                        'color': 'var(--clerk-text)',
                        'cursor': 'pointer',
                        'fontFamily': '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto',
                        'fontSize': '14px',
                    }
                ),
            ]),

            html.Hr(
                id="clerk-menu-divider",
                style={
                    'display': 'block' if signed_in else 'none',
                    'margin': '6px 10px',
                    'border': 'none',
                    'borderTop': '1px solid var(--clerk-border)'
                }
            ),

            html.Button(
                [html.Span("🚪", style={'marginRight': '8px'}), html.Span("Sign Out")],
                id="clerk-logout-menu-item",
                n_clicks=0,
                style={
                    'display': 'flex' if signed_in else 'none',
                    'alignItems': 'center',
                    'width': '100%',
                    'padding': '10px 12px',
                    'margin': '3px 6px',
                    'border': 'none',
                    'backgroundColor': 'transparent',
                    'color': '#ef4444',
                    'cursor': 'pointer',
                    'fontFamily': '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto',
                    'fontSize': '14px',
                }
            ),
        ],
        id="clerk-menu-dropdown",
        style=dropdown_style,
    )

    return html.Div([avatar, dropdown], style={'position': 'relative', 'display': 'inline-block'})


# Back-compat alias for the module's internal fixed-position injection.
def _create_auth_menu():
    return create_clerk_menu(_internal=True)


def _create_debug_panel():
    """Create debug panel with minimal inline styles"""
    return html.Div(
        children=[
            html.Div(
                "🔧 Clerk Auth Debug",
                style={
                    'fontWeight': '700',
                    'marginBottom': '12px',
                    'fontSize': '14px',
                    'padding': '16px 18px',
                    'background': 'var(--clerk-glass-bg-secondary)',
                    'borderBottom': '1px solid var(--clerk-border)'
                }
            ),
            html.Div([
                html.Div("User ID:",
                         style={'fontSize': '11px', 'color': 'var(--clerk-text-secondary)', 'fontWeight': '600',
                                'textTransform': 'uppercase', 'letterSpacing': '0.05em', 'marginTop': '12px',
                                'marginBottom': '4px'}),
                html.Div(id="clerk-debug-user-id", children="Not signed in"),

                html.Div("Email:",
                         style={'fontSize': '11px', 'color': 'var(--clerk-text-secondary)', 'fontWeight': '600',
                                'textTransform': 'uppercase', 'letterSpacing': '0.05em', 'marginTop': '12px',
                                'marginBottom': '4px'}),
                html.Div(id="clerk-debug-email", children="N/A"),

                html.Div("Name:",
                         style={'fontSize': '11px', 'color': 'var(--clerk-text-secondary)', 'fontWeight': '600',
                                'textTransform': 'uppercase', 'letterSpacing': '0.05em', 'marginTop': '12px',
                                'marginBottom': '4px'}),
                html.Div(id="clerk-debug-name", children=""),

                html.Div("Session ID:",
                         style={'fontSize': '11px', 'color': 'var(--clerk-text-secondary)', 'fontWeight': '600',
                                'textTransform': 'uppercase', 'letterSpacing': '0.05em', 'marginTop': '12px',
                                'marginBottom': '4px'}),
                html.Div(id="clerk-debug-session", children="N/A"),
            ], style={'padding': '16px 18px'})
        ],
        id="clerk-debug-panel",
        style={
            'position': 'fixed',
            'bottom': '20px',
            'right': '20px',
            'width': '350px',
            'maxHeight': '500px',
            'zIndex': '9999',
            'fontFamily': '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto',
            'fontSize': '12px',
        }
    )


def configure_app(app):
    """Configure a Dash app for Clerk authentication.

    Detects the active backend from ``app.server``:

    - Flask (WSGI): mounts Flask-Session, ``/api/auth/{session,signout}``
      routes, the ProxyFix middleware and a ``before_request`` hook that
      populates ``flask.g.clerk_user`` so :func:`current_user` works
      identically to the FastAPI path.
    - FastAPI / Starlette / Quart (ASGI, Dash 4): installs the
      :class:`ClerkASGIMiddleware` and a Starlette ``SessionMiddleware``
      (signed-cookie). Auth routes are mounted as plain POST endpoints.

    Set ``backend=`` on :func:`register_clerk_auth` to override detection.
    """
    if not _clerk_config.get('initialized'):
        raise RuntimeError("Clerk auth not initialized. Call register_clerk_auth() first.")

    backend = (_clerk_config.get('backend') or 'auto').lower()
    if backend == 'auto':
        backend = detect_backend(app.server)
        _clerk_config['backend'] = backend
        logger.info("dash-clerk-auth: backend autodetected as '%s'", backend)

    if backend == 'flask':
        _configure_flask_app(app)
    elif backend in ('fastapi', 'quart'):
        _configure_fastapi_app(app)
    else:
        raise RuntimeError(
            f"dash-clerk-auth: unable to determine Dash backend from app.server "
            f"(detected={backend!r}). Pass backend='flask' or backend='fastapi' "
            f"to register_clerk_auth() explicitly."
        )


def _configure_flask_app(app):
    """v0.5 Flask configuration path, plus the v0.6 before_request hook."""
    if not _FLASK_AVAILABLE:
        raise RuntimeError(
            "dash_clerk_auth: Flask backend requested but Flask is not installed. "
            "Install with: pip install flask flask-session"
        )

    server = app.server
    if not hasattr(server, 'before_request') or not hasattr(server, 'route'):
        raise RuntimeError(
            "dash_clerk_auth: backend='flask' but app.server is not a Flask "
            "instance. Pass backend='fastapi' if you're on Dash 4 ASGI."
        )

    # Configure Flask-Session
    server.config['SECRET_KEY'] = _clerk_config['session_secret']
    server.config['SESSION_TYPE'] = 'filesystem'
    server.config['SESSION_PERMANENT'] = True
    server.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=_clerk_config['session_lifetime_days'])
    server.config['SESSION_COOKIE_SECURE'] = True
    server.config['SESSION_COOKIE_HTTPONLY'] = True
    server.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

    Session(server)

    if _clerk_config.get('enable_proxy_fix'):
        server.wsgi_app = ProxyFix(server.wsgi_app, x_for=1, x_proto=1, x_host=1)

    # v0.7: populate g.clerk_user before each request. Identity precedence:
    #   1. __dca_identity cookie (signed, local — microsecond verify)
    #   2. flask.session dict (v0.5 backwards compat)
    #   3. v0.9 slow path: Clerk verify against the __session cookie /
    #      bearer token, minting __dca_identity on THIS response.
    # The slow path is what makes backend="flask" behaviorally identical to
    # the ASGI middleware with no client cooperation — before v0.9 the only
    # identity writers lived in /api/auth/session, which the injected
    # client script no longer calls, so a fully signed-in browser stayed
    # anonymous to every server-side check forever.
    #
    # Skip list: static assets ONLY — narrower than the ASGI middleware's.
    # /_dash-layout must keep resolving identity here, because on Flask the
    # @hooks.layout() store pre-hydration and any dynamic root layout read
    # current_user() (i.e. g.clerk_user) WHILE that route is served; skipping
    # it would reintroduce the first-paint anonymous flash v0.7 fixed.
    _SKIP_PREFIXES = (
        "/_dash-component-suites/",
        "/_favicon.ico",
        "/_reload-hash",
        "/assets/",
        "/static/",
        "/health",
        "/api/health",
    )
    from ._identity_cookie import (
        COOKIE_NAME as _IDENTITY_COOKIE_NAME,
        bounded_max_age as _identity_bounded_max_age,
        flask_clear_cookie_kwargs as _identity_flask_clear_kwargs,
        flask_set_cookie_kwargs as _identity_flask_set_kwargs,
        mint as _identity_mint,
        verify as _identity_verify,
    )

    _IDENTITY_COOKIE_MAX_AGE = _clerk_config['session_lifetime_days'] * 24 * 60 * 60

    def _flask_slow_path_verify(path):
        """Clerk-verify this request and mint __dca_identity on the response.

        Returns the verified (and email-enriched) ClerkUser, or None.
        verify_user_sync is TTL-cached by cookie set (≤5 min / JWT exp) and
        thread-safe, so under Clerk's ~60s dev-key JWT rotation this costs
        about one roundtrip per user per minute — same as the ASGI path.
        """
        cookies = request.cookies
        auth = request.headers.get('Authorization', '')
        bearer = auth.split(' ', 1)[1].strip() if auth.lower().startswith('bearer ') else None
        # Only call Clerk when there's an actual session token to verify.
        # __client_uat/__refresh_* alone is the expected idle state between
        # Clerk's ~60s JWT rotations — a verify is guaranteed to reject.
        has_session_token = '__session' in cookies or any(
            k.startswith('__session_') for k in cookies
        )
        if not (bearer or has_session_token):
            if any(k.startswith('__client') or k.startswith('__refresh') for k in cookies):
                logger.debug("clerk-auth %s: no session token (rotated/idle) — anonymous", path)
            else:
                logger.debug("clerk-auth %s: anonymous (no bearer, no __session)", path)
            return None

        user = verify_user_sync(
            method=request.method,
            url=request.url,
            headers={k.lower(): v for k, v in request.headers.items()},
            cookies=dict(cookies),
            bearer_token=bearer,
            authorized_parties=_clerk_config.get('authorized_parties') or None,
            billing_enabled=bool(_clerk_config.get('billing_enabled')),
        )
        if user is None:
            logger.info(
                "clerk-auth %s: slow-path Clerk verify rejected (session token present)",
                path,
            )
            return None

        logger.info(
            "clerk-auth %s: slow-path Clerk verify ok user=%s — minting __dca_identity",
            path, user.user_id,
        )
        secret = _clerk_config.get('session_secret')
        if secret and after_this_request is not None:
            cookie_token = _identity_mint(user, secret)
            is_secure = request.is_secure or request.headers.get(
                'X-Forwarded-Proto', ''
            ).lower().startswith('https')

            @after_this_request
            def _set_identity_cookie(response):
                response.set_cookie(
                    **_identity_flask_set_kwargs(
                        cookie_token,
                        max_age=max(60, int(_IDENTITY_COOKIE_MAX_AGE)),
                        secure=is_secure,
                    )
                )
                return response
        return user

    @server.before_request
    def _populate_clerk_user():
        # Static assets / housekeeping — never verify (same skip list as
        # the ASGI middleware).
        path = request.path or ''
        if any(path == p or path.startswith(p) for p in _SKIP_PREFIXES):
            flask_g.clerk_user = None
            return

        user: ClerkUser | None = None
        # Fast path — local cookie verify.
        if _clerk_config.get('session_secret'):
            token = request.cookies.get(_IDENTITY_COOKIE_NAME)
            if token:
                user = _identity_verify(
                    token,
                    _clerk_config['session_secret'],
                    _IDENTITY_COOKIE_MAX_AGE,
                )
                if user is not None:
                    logger.debug(
                        "clerk-auth %s: fast-path cookie verified for user=%s",
                        path, user.user_id,
                    )
        # Fallback — legacy session dict.
        if user is None:
            try:
                user = ClerkUser.from_session_dict(session) if session is not None else None
            except Exception:
                user = None
            if user is not None:
                logger.debug(
                    "clerk-auth %s: identity reconstructed from flask session user=%s",
                    path, user.user_id,
                )
        # v0.9 slow path — mirror the ASGI middleware.
        if user is None:
            user = _flask_slow_path_verify(path)
        flask_g.clerk_user = user

    @server.route('/api/auth/session', methods=['POST'])
    def auth_session():
        """Verify authentication session from client"""
        try:
            data = request.get_json()
            token = data.get('token') if data else None

            if not token:
                return jsonify({'authenticated': False, 'error': 'No token provided'}), 401

            httpx_request = _flask_to_httpx_request(request, token=token)
            clerk_client = _clerk_config.get('clerk_client')
            auth_options = AuthenticateRequestOptions(
                authorized_parties=_clerk_config.get('authorized_parties') or None
            )
            request_state = clerk_client.authenticate_request(httpx_request, auth_options)

            if request_state.is_signed_in:
                payload = request_state.payload or {}
                user = ClerkUser.from_jwt_payload(
                    payload,
                    billing_enabled=bool(_clerk_config.get('billing_enabled')),
                )
                # Session JWTs carry no email claim by default — enrich via
                # the users API (sticky-cached per user_id) BEFORE writing
                # the session / minting __dca_identity. This route bypasses
                # the _clerk_client verify helpers, so it enriches here.
                user = enrich_user_sync(user)
                user_data = user.to_session_dict()

                session.update(user_data)
                session.modified = True
                # Mirror onto flask.g so the rest of THIS request sees the
                # user without waiting for the next request's before_request.
                flask_g.clerk_user = user

                response = jsonify({'authenticated': True, 'user': user_data})
                # Mint the __dca_identity cookie so subsequent requests
                # (and Dash 4.2 WS handshakes) skip the Clerk roundtrip.
                # Uses the configured cookie max_age (default 7 days), NOT
                # the JWT exp — Clerk session JWTs rotate every ~60s on
                # dev keys; the cookie's job is to cache the *identity*
                # across many JWT refreshes.
                secret = _clerk_config.get('session_secret')
                if secret:
                    cookie_token = _identity_mint(user, secret)
                    response.set_cookie(
                        **_identity_flask_set_kwargs(
                            cookie_token,
                            max_age=max(60, int(_IDENTITY_COOKIE_MAX_AGE)),
                            secure=request.is_secure,
                        )
                    )
                return response
            else:
                return jsonify({'authenticated': False, 'error': request_state.reason or 'Authentication failed'}), 401

        except Exception as e:
            logger.error(f"Session verification error: {str(e)}")
            return jsonify({'authenticated': False, 'error': 'Session verification failed'}), 500

    @server.route('/api/auth/signout', methods=['POST'])
    def auth_signout():
        """Clear server-side session"""
        session.clear()
        flask_g.clerk_user = None
        response = jsonify({'success': True})
        response.set_cookie(
            **_identity_flask_clear_kwargs(secure=request.is_secure)
        )
        return response

    logger.info("Flask app configured with Clerk authentication routes")

    clientside_callback(
        """
        function(triggerValue) {
            if (!triggerValue) return window.dash_clientside.no_update;
            try {
                const authData = JSON.parse(triggerValue);
                console.log('[Clerk] Store updated via trigger:', authData);
                return authData;
            } catch (e) {
                console.error('[Clerk] Failed to parse auth data:', e);
                return window.dash_clientside.no_update;
            }
        }
        """,
        Output('clerk-auth-store', 'data'),
        Input('clerk-auth-trigger', 'value')
    )

    logger.info("🌊 Liquid Glass authentication configured successfully")


def _configure_fastapi_app(app):
    """ASGI configuration path — Dash 4 ``backend='fastapi'`` (or Quart)."""
    from ._fastapi import configure_fastapi_app

    configure_fastapi_app(
        app,
        clerk_secret_key=_clerk_config['clerk_secret_key'],
        session_secret=_clerk_config['session_secret'],
        session_lifetime_days=_clerk_config['session_lifetime_days'],
        billing_enabled=bool(_clerk_config.get('billing_enabled')),
        authorized_parties=_clerk_config.get('authorized_parties') or None,
        on_unverified=_clerk_config.get('on_unverified', 'forbidden'),
        verify_timeout=_clerk_config.get('verify_timeout', 5.0),
    )

    # v0.9: register the Dash 4.2+ WebSocket auth hooks automatically.
    # Dash 4.2 dispatches WS-served callbacks through a ThreadPoolExecutor
    # that no HTTP middleware, cookie or ContextVar reaches — without the
    # connect/message hooks + renderer registry, current_user() is None in
    # every WS-served callback while the app *looks* fully functional.
    # register_websocket_auth is idempotent and degrades gracefully (info
    # log + False) on Dash versions without the hooks. Opt out with
    # register_clerk_auth(websocket_auth=False).
    ws_registered = False
    if _clerk_config.get('websocket_auth', True):
        ws_registered = register_websocket_auth()
    if getattr(app, '_websocket_callbacks', False) and not ws_registered:
        logger.warning(
            "dash-clerk-auth: this app delivers EVERY callback over WebSocket "
            "(websocket_callbacks=True) but WebSocket auth is not registered — "
            "server-side identity (current_user()) will be None in every "
            "WebSocket-served callback. Remove websocket_auth=False, or call "
            "register_websocket_auth() yourself."
        )

    # The clerk-auth-store ↔ clerk-auth-trigger clientside bridge is
    # backend-agnostic — register it here so FastAPI apps don't have to
    # do it themselves.
    clientside_callback(
        """
        function(triggerValue) {
            if (!triggerValue) return window.dash_clientside.no_update;
            try {
                const authData = JSON.parse(triggerValue);
                return authData;
            } catch (e) {
                return window.dash_clientside.no_update;
            }
        }
        """,
        Output('clerk-auth-store', 'data'),
        Input('clerk-auth-trigger', 'value')
    )

    logger.info("🌊 Liquid Glass authentication configured successfully (FastAPI/ASGI)")


def _safe_session():
    """Return the Flask session dict, or an empty dict if Flask isn't loaded or
    we're outside a request context (e.g. during import-time checks)."""
    if not _FLASK_AVAILABLE or session is None:
        return {}
    try:
        # Touch a key to force a RuntimeError if we're outside a request context
        _ = session.get('user_id')
        return session
    except RuntimeError:
        return {}


def get_current_user_id():
    """Get current user ID — backend-neutral.

    Reads via :func:`current_user` (ContextVar on FastAPI, ``flask.g``
    on Flask), falling back to the legacy ``flask.session`` dict.
    """
    user = current_user()
    if user is not None:
        return user.user_id
    return _safe_session().get('user_id')


def get_current_user_plan():
    """Get current user plan — backend-neutral."""
    if not _clerk_config.get('billing_enabled'):
        return None
    user = current_user()
    if user is not None:
        return user.plan or 'free'
    return _safe_session().get('plan', 'free')


def get_current_user_features():
    """Get current user features — backend-neutral."""
    if not _clerk_config.get('billing_enabled'):
        return []
    user = current_user()
    if user is not None:
        return list(user.features)
    return _safe_session().get('features', [])


def has_plan(required_plans):
    """Check if user has one of the required plans — backend-neutral."""
    if not _clerk_config.get('billing_enabled'):
        return True

    if isinstance(required_plans, str):
        required_plans = [required_plans]

    user = current_user()
    if user is not None:
        return user.has_plan(required_plans)

    user_plan = (_safe_session().get('plan') or 'free').lower()
    return user_plan in [p.lower() for p in required_plans]


def has_feature(required_feature):
    """Check if user has a required feature — backend-neutral."""
    if not _clerk_config.get('billing_enabled'):
        return True

    user = current_user()
    if user is not None:
        return user.has_feature(required_feature)
    return required_feature in _safe_session().get('features', [])


def require_auth(f):
    """Decorator to require authentication on a Dash callback.

    Backend-neutral: reads :func:`current_user`, returns ``None`` (no
    update) when anonymous on FastAPI, redirects to the sign-in URL when
    available on Flask, returns ``None`` outside any request context.
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = get_current_user_id()
        if not user_id:
            if _FLASK_AVAILABLE and redirect is not None:
                try:
                    return redirect(_clerk_config.get('clerk_sign_in_url'))
                except RuntimeError:
                    return None
            return None
        return f(*args, **kwargs)

    return decorated_function


def require_plan(plans):
    """Decorator to require specific plan"""

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not has_plan(plans):
                return "Upgrade required", 403
            return f(*args, **kwargs)

        return decorated_function

    return decorator


def require_feature(feature):
    """Decorator to require specific feature"""

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not has_feature(feature):
                return "Feature not available", 403
            return f(*args, **kwargs)

        return decorated_function

    return decorator


def get_user_info(user_id=None):
    """Get user information from session or Clerk API — backend-neutral.

    Tries (in order):
    1. The verified ClerkUser bound to this request (current_user()).
    2. The legacy v0.5 Flask session dict.
    3. A blocking Clerk SDK lookup (Flask path only — async callers
       should ``await aget_user_by_id`` instead).
    """
    user = current_user() if user_id is None else None
    if user is not None:
        info = {
            'id': user.user_id,
            'email': user.email or 'user@example.com',
            'first_name': user.first_name or 'User',
            'last_name': user.last_name or '',
            'image_url': user.image_url or '',
            'email_addresses': [{'email_address': user.email or 'user@example.com'}],
        }
        if _clerk_config.get('billing_enabled'):
            info['plan'] = user.plan or 'free'
            info['features'] = list(user.features)
        return info

    if user_id is None:
        user_id = get_current_user_id()

    if not user_id:
        return None

    sess = _safe_session()

    # Try session first
    if sess.get('user_id') == user_id:
        user_info = {
            'id': user_id,
            'email': sess.get('email', 'user@example.com'),
            'first_name': sess.get('first_name', 'User'),
            'last_name': sess.get('last_name', ''),
            'image_url': sess.get('image_url', ''),
            'email_addresses': [{'email_address': sess.get('email', 'user@example.com')}]
        }

        if _clerk_config.get('billing_enabled'):
            user_info['plan'] = sess.get('plan', 'free')
            user_info['features'] = sess.get('features', [])

        return user_info

    # Fallback to API
    clerk_client = _clerk_config.get('clerk_client')
    if clerk_client:
        try:
            user = clerk_client.users.get(user_id=user_id)
            return {
                'id': user.id,
                'email': user.email_addresses[0].email_address if user.email_addresses else '',
                'first_name': user.first_name or '',
                'last_name': user.last_name or '',
                'image_url': getattr(user, 'image_url', ''),
                'email_addresses': [{'email_address': e.email_address} for e in user.email_addresses],
                'plan': 'free' if _clerk_config.get('billing_enabled') else None,
                'features': [] if _clerk_config.get('billing_enabled') else None
            }
        except Exception as e:
            logger.error(f"Error fetching user: {e}")

    return None


def register_websocket_auth(**kwargs):
    """Dash 4.2+ WebSocket auth — see :func:`dash_clerk_auth._ws.register_websocket_auth`.

    Since v0.9 this is called automatically when ``configure_app`` sets up
    an ASGI backend (disable with ``register_clerk_auth(websocket_auth=False)``).
    Call it explicitly only to customise kwargs — it's idempotent, and the
    FIRST registration wins, so customise before ``configure_app`` runs.

    Defaults to ``on_anonymous="allow"`` (v0.7+ — mixed-traffic safe). Pass
    ``on_anonymous="close"`` to revert to the v0.6 fail-closed behaviour
    (close anonymous WS handshakes with code 4401).

    Always pulls ``session_secret`` from the active config so the WS
    connect hook can verify the ``__dca_identity`` cookie locally before
    falling back to a Clerk roundtrip.
    """
    from ._ws import register_websocket_auth as _impl

    secret = _clerk_config.get('session_secret')
    max_age = _clerk_config.get('session_lifetime_days', 7) * 24 * 60 * 60

    kwargs.setdefault('session_secret', secret)
    kwargs.setdefault('identity_cookie_max_age', max_age)
    kwargs.setdefault(
        'authorized_parties', _clerk_config.get('authorized_parties') or None
    )
    kwargs.setdefault('billing_enabled', bool(_clerk_config.get('billing_enabled')))

    return _impl(**kwargs)


__all__ = [
    # v0.5 surface — unchanged
    'register_clerk_auth',
    'configure_app',
    'create_clerk_menu',
    # v1.0.3: the inline signed-out avatar, exported so an app rendering its
    # own menu gets the same default instead of reaching for an avatar API.
    'AVATAR_DEFAULT_LIGHT',
    'AVATAR_DEFAULT_DARK',
    'get_current_user_id',
    'get_current_user_plan',
    'get_current_user_features',
    'has_plan',
    'has_feature',
    'require_auth',
    'require_plan',
    'require_feature',
    'get_user_info',
    # v0.6 — backend-neutral identity
    'ClerkUser',
    'current_user',
    'callback_user',
    'is_authenticated',
    'detect_backend',
    # v0.6 — layout decorators
    'require_auth_layout',
    'require_role_layout',
    'require_plan_layout',
    'require_feature_layout',
    'default_forbidden_layout',
    # v0.6 — async Clerk surface (main-event-loop only; see sync twins below)
    'get_async_client',
    'averify_request',
    'aget_user_by_id',
    'alist_users_cached',
    # v0.6 — Dash 4.2 WebSocket auth (auto-registered since v0.9)
    'register_websocket_auth',
    # v0.8 — loop-free sync Clerk surface, SAFE inside Dash 4.2 WS callback
    # bodies / job-worker threads (the async twins above bind to one event
    # loop and break under Dash 4.2's per-callback asyncio.run model).
    'get_sync_client',
    'verify_user_sync',
    'get_user_by_id_sync',
    'list_users_sync',
    'set_user_role_sync',
    # v0.9 — email enrichment + WS auth introspection
    'enrich_user_sync',
    'aenrich_user',
    'ws_auth_registered',
]