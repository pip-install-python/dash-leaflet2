# AUTO GENERATED FILE - DO NOT EDIT

import typing  # noqa: F401
from typing_extensions import TypedDict, NotRequired, Literal # noqa: F401
from dash.development.base_component import Component, _explicitize_args

ComponentType = typing.Union[
    str,
    int,
    float,
    Component,
    None,
    typing.Sequence[typing.Union[str, int, float, Component, None]],
]

NumberType = typing.Union[
    typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex
]


class DashEmojiMart(Component):
    """A DashEmojiMart component.


Keyword arguments:

- id (string; optional)

- autoFocus (boolean; default False)

- categories (list; optional)

- categoryIcons (dict; optional)

- custom (list; optional)

- dynamicWidth (boolean; default False)

- emojiButtonColors (list; optional)

- emojiButtonRadius (string; default "100%")

- emojiButtonSize (number; default 36)

- emojiSize (number; default 24)

- emojiVersion (number; default 14)

- exceptEmojis (list; optional)

- icons (string; default "auto")

- locale (string; default "en")

- maxFrequentRows (number; default 4)

- navPosition (string; default "top")

- noCountryFlags (boolean; default False)

- noResultsEmoji (string; default "cry")

- perLine (number; default 9)

- previewEmoji (string; default "point_up")

- previewPosition (string; default "bottom")

- searchPosition (string; default "sticky")

- set (string; default "native")

- skin (number; default 1)

- skinTonePosition (string; default "preview")

- theme (string; default "auto")

- value (string; optional)"""
    _children_props: typing.List[str] = []
    _base_nodes = ['children']
    _namespace = 'dash_emoji_mart'
    _type = 'DashEmojiMart'


    def __init__(
        self,
        id: typing.Optional[typing.Union[str, dict]] = None,
        value: typing.Optional[str] = None,
        custom: typing.Optional[typing.Sequence] = None,
        onEmojiSelect: typing.Optional[typing.Any] = None,
        onClickOutside: typing.Optional[typing.Any] = None,
        onAddCustomEmoji: typing.Optional[typing.Any] = None,
        autoFocus: typing.Optional[bool] = None,
        categories: typing.Optional[typing.Sequence] = None,
        categoryIcons: typing.Optional[dict] = None,
        dynamicWidth: typing.Optional[bool] = None,
        emojiButtonColors: typing.Optional[typing.Sequence] = None,
        emojiButtonRadius: typing.Optional[str] = None,
        emojiButtonSize: typing.Optional[NumberType] = None,
        emojiSize: typing.Optional[NumberType] = None,
        emojiVersion: typing.Optional[NumberType] = None,
        exceptEmojis: typing.Optional[typing.Sequence] = None,
        icons: typing.Optional[str] = None,
        locale: typing.Optional[str] = None,
        maxFrequentRows: typing.Optional[NumberType] = None,
        navPosition: typing.Optional[str] = None,
        noCountryFlags: typing.Optional[bool] = None,
        noResultsEmoji: typing.Optional[str] = None,
        perLine: typing.Optional[NumberType] = None,
        previewEmoji: typing.Optional[str] = None,
        previewPosition: typing.Optional[str] = None,
        searchPosition: typing.Optional[str] = None,
        set: typing.Optional[str] = None,
        skin: typing.Optional[NumberType] = None,
        skinTonePosition: typing.Optional[str] = None,
        theme: typing.Optional[str] = None,
        getSpritesheetURL: typing.Optional[typing.Any] = None,
        **kwargs
    ):
        self._prop_names = ['id', 'autoFocus', 'categories', 'categoryIcons', 'custom', 'dynamicWidth', 'emojiButtonColors', 'emojiButtonRadius', 'emojiButtonSize', 'emojiSize', 'emojiVersion', 'exceptEmojis', 'icons', 'locale', 'maxFrequentRows', 'navPosition', 'noCountryFlags', 'noResultsEmoji', 'perLine', 'previewEmoji', 'previewPosition', 'searchPosition', 'set', 'skin', 'skinTonePosition', 'theme', 'value']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'autoFocus', 'categories', 'categoryIcons', 'custom', 'dynamicWidth', 'emojiButtonColors', 'emojiButtonRadius', 'emojiButtonSize', 'emojiSize', 'emojiVersion', 'exceptEmojis', 'icons', 'locale', 'maxFrequentRows', 'navPosition', 'noCountryFlags', 'noResultsEmoji', 'perLine', 'previewEmoji', 'previewPosition', 'searchPosition', 'set', 'skin', 'skinTonePosition', 'theme', 'value']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(DashEmojiMart, self).__init__(**args)

setattr(DashEmojiMart, "__init__", _explicitize_args(DashEmojiMart.__init__))
