"""Smoke test for the example application.

Imports the multi-page app (`app.py`), which triggers Dash page discovery and
imports every module in `pages/`, then asserts the app and its layout build.
Catches regressions such as stale props (e.g. the removed `apiKey`) or namespace
mistakes after a release, without needing a browser.
"""
from dash.testing.application_runners import import_app


def test_app_imports():
    app = import_app("app")
    assert app is not None
    assert app.layout is not None
